﻿Public Class RequestViewerFull
    Inherits System.Web.UI.Page
    Dim dbaccess As New dbutil
    Private Shared prevPage As String = String.Empty
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Session("Logged_In") Then
            '            Kill Session
            Session.Abandon()
            Response.Cookies.Add(New HttpCookie("ASP.NET_SessionId", ""))
            Response.Redirect("~/Default", False)
            Exit Sub
        ElseIf Session("Logged_In") Then
            Session.Timeout = 30
            If Not Me.IsPostBack Then
                prevPage = Request.UrlReferrer.ToString()
                Dim rh As String = Request.QueryString("request-handler")
                Dim dh As String = Request.QueryString("document-handler")
                If rh IsNot Nothing And dh IsNot Nothing Then
                    GatherInformation(rh, dh)
                End If
            End If
        Else

            If Session("Message") IsNot Nothing Then
                Session("Message") = Nothing
            End If
        End If
    End Sub
    Private Sub GatherInformation(ByVal rh As Integer, ByVal dh As Integer)
        ' FILL THE REQUEST CARD 
        Dim _list As New Request_form_queue
        _list = dbaccess.Get_Req_Queue_By_ID(rh)

        Dim _listPath As New stu_req_uploaded_files
        _listPath = dbaccess.Get_Request_Path_Queue_By_ID(dh)
        '

        Try
            txt_req_id.Text = _list.req_id
            TextBox2.Text = _list.req_type
            txt_message_1.Text = _list.req_details_1
            If _list.re_details_more IsNot Nothing Then
                TextBox1.Text = _list.re_details_more
                TextBox1.Visible = True
            Else
                ' hide the panel
            End If

            Dim myiFrame As HtmlControl = CType(Me.Master.FindControl("MainContent").FindControl("letterURL"), HtmlIframe)
            myiFrame.Attributes("src") = ""
            Dim path = _listPath.path
            path = path & _listPath.filename
            If String.IsNullOrEmpty(path.ToString) = True Then
                ScriptManager.RegisterClientScriptBlock(Me, Me.GetType, "alertMessage", "alert('No PDF Found!')", True)
            Else
                If Not String.IsNullOrEmpty(path.ToString) Then
                    SetIframeURL(path)
                End If
            End If
        Catch ex As Exception

        End Try

        ScriptManager.RegisterStartupScript(Me, Me.GetType, "Pop", "openModal();", True)

        ' GET THE PDF PATH AND FILL THE PDF VIEWER 


    End Sub
    Protected Sub SetIframeURL(ByVal path As String)
        Dim a As String = path.ToString
        Dim requestURL As String = Request.Url.GetLeftPart(UriPartial.Authority) & Request.Url.GetLeftPart(UriPartial.Authority)
        Dim singleURL As String = Request.Url.GetLeftPart(UriPartial.Authority)
        Try
            If Not a Is Nothing Then
                requestURL = Request.Url.GetLeftPart(UriPartial.Authority)
                Dim myiFrame As HtmlControl = CType(Me.Master.FindControl("MainContent").FindControl("letterURL"), HtmlIframe)
                Dim x As String
                If a.ToString.Contains(requestURL) Then
                    x = a
                    myiFrame.Attributes("src") = x
                Else
                    x = a
                    myiFrame.Attributes("src") = x
                End If
                '  PDFOutput = $"{HttpRuntime.AppDomainAppPath}{Session("Generated-Output")}".Replace("/", "\").Replace("\\", "\")
            End If
        Catch ex As Exception
            'Dim newError As New sbc_errors(ex, "")
            'newError.Log()
            ClientScript.RegisterStartupScript(Me.GetType(), "Saved",
                                               "alertify.warning('Setting iFrame - " &
                                               ex.Message.Replace("'", "") & "');", True)
            Exit Sub
        End Try

    End Sub

    Protected Sub btn_close_Click(sender As Object, e As EventArgs) Handles btn_close.Click
        Response.Redirect(prevPage, False)
    End Sub


    Protected Sub GridView2_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView2.RowCommand
        Dim gvr As GridViewRow = CType(CType(e.CommandSource, LinkButton).NamingContainer, GridViewRow)
        Dim id As Integer
        If Not e.CommandName = "New" Then
            id = CType(GridView2.DataKeys(gvr.RowIndex).Value, Integer)
        End If
        If e.CommandName = "Select" Then
            GatherPDF(id)
        End If
    End Sub
    Private Sub GatherPDF(ByVal dh As Integer)
        Dim _listPath As New stu_req_uploaded_files
        _listPath = dbaccess.Get_Request_Path_Queue_By_ID(dh)
        Try
            Dim myiFrame As HtmlControl = CType(Me.Master.FindControl("MainContent").FindControl("letterURL"), HtmlIframe)
            myiFrame.Attributes("src") = ""
            Dim path = _listPath.path
            path = path & _listPath.filename
            If String.IsNullOrEmpty(path.ToString) = True Then
                ScriptManager.RegisterClientScriptBlock(Me, Me.GetType, "alertMessage", "alert('No PDF Found!')", True)
            Else
                If Not String.IsNullOrEmpty(path.ToString) Then
                    SetIframeURL(path)
                End If
            End If
        Catch ex As Exception
        End Try
    End Sub
End Class