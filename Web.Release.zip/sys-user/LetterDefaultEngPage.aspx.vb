﻿Imports System.IO

Public Class LetterDefaultEngPage
    Inherits System.Web.UI.Page

    Dim dbaccess As New dbutil
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Session("Logged_In") Then
            '            Kill Session
            Session.Abandon()
            Response.Cookies.Add(New HttpCookie("ASP.NET_SessionId", ""))
            Response.Redirect("~/Default", False)
            Exit Sub
        ElseIf Session("Logged_In") Then
            If Not Me.IsPostBack Then
                studentFiller()
                Dim objLoginView = Session("LoginView")
                Role_defined_controls()
            End If

        Else

            If Session("Message") IsNot Nothing Then
                Session("Message") = Nothing
            End If
        End If
        If GridView2.Rows.Count > 0 Then
            Button3.Visible = False
        Else
            Button3.Visible = True
        End If


    End Sub
    Protected Sub studentFiller()
        Dim objStudent As New mb_st_details
        objStudent = Session("Student")
        lblprofileno.Text = objStudent.profile_no
        '    txt_full_name.Text = objStudent.stu_full_name
    End Sub
    Protected Sub Role_defined_controls()
        Dim objLoginView As New mb_st_log_sys_view
        objLoginView = Session("LoginView")
        Dim role As String = ""
        Dim entityUser = dbaccess.Get_Role_ID_By_ID(objLoginView.entity_user_id)
        role = entityUser.role_id
        'role_id=1=Student
        'role_id=2=Supervisor
        'role_id=3=Admin
        'role_id=4=Super-admin
        Select Case role
            Case 1
                'student screen
                'student_controls()
                lblrole.Text = "Student"
                student_controls()
            Case 2
                'supervisor screen
                lblrole.Text = "Supervisor"
            Case 3
                'admin 
                lblrole.Text = "Admin"
            Case 4
                lblrole.Text = "Super-Admin"
            Case Else

        End Select

    End Sub
    Protected Sub student_controls()
        LinkButton7.Visible = False
    End Sub
    Private Sub Add_letter()
        Dim _id As Integer = 0
        If txt_letter_body.Text.Length = 0 Then
            Panel2.Visible = True
            ErrorMessage.Text = "Letter Body is empty." + Environment.NewLine
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "Javascript", "<script>alert('Letter Body is empty.')</script>")
            Exit Sub
        End If
        If FileUpload1.HasFile Then
            Dim ext As String = Path.GetExtension(FileUpload1.PostedFile.FileName)
            If ext = ".pdf" Then
                _id = _insert_letter()
                GridView2.DataBind()
                Panel1.Visible = False
                Panel3.Visible = True
            Else
                ErrorMessage.Text = "Only pdf file allowed." + Environment.NewLine
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "Javascript", "<script>alert('Only pdf file allowed.')</script>")
                Exit Sub
            End If
        Else
            _id = _insert_letter()
            GridView2.DataBind()
            Panel1.Visible = False
            Panel3.Visible = True
        End If
    End Sub
    Function _upload_files(ByVal stu_profile_no As Integer, ByVal id As Integer) As Integer
        Dim result As Integer = 0
        Dim savePath As String
        Dim createpath As String
        Dim ExtType As String = Path.GetExtension(FileUpload1.PostedFile.FileName).ToLower()
        Dim strMIME As String = Nothing
        Dim ext As String = Path.GetExtension(FileUpload1.PostedFile.FileName)
        Try
            Dim filename As String = Path.GetFileName(FileUpload1.PostedFile.FileName)
            If ext = ".pdf" Then
                Dim _date As String = Replace(Date.Now.ToShortDateString, "/", "")
                createpath = "~\Uploads\letterUploads\English\" & stu_profile_no.ToString & "\" & id.ToString & "\" & _date.ToString & "\"
                Directory.CreateDirectory(Server.MapPath(createpath))
                FileUpload1.PostedFile.SaveAs(Server.MapPath(createpath & filename))
                savePath = createpath & filename
                ' update the path link 
                Dim updatePath = dbaccess.Update_english_pdf_path(savePath, filename, id)
                result = updatePath
                ErrorMessage.Text = "File Uploaded and updated"
            End If
        Catch ex As Exception
        End Try
        Return result
    End Function


    Function _insert_letter() As Integer
        Dim objStudent As New mb_st_details
        objStudent = Session("Student")
        Dim _id As Integer = 0
        Dim _objletter As New englishletter

        _objletter.profile_no = lblprofileno.Text 'txt_profile_no.Text
        _objletter.lettersubject = txt_letter_subj.Text
        _objletter.letterto = Txt_letter_to.Text
        _objletter.letterdate = Txt_letter_date.Text
        _objletter.lettertext = txt_letter_body.Text
        _objletter.created_by = Session("Login_name")
        ' create the path 
        'Path = "~\Uploads\letterUploads\studentProfile\arablicLetters\Id\Date.Now.ToShortDateString + "\"
        Dim path As String = ""
        _objletter.path = path
        Dim _date As String = Replace(Date.Now.ToShortDateString, "/", "")
        Try
            _id = dbaccess.Insert_english_letter(_objletter, Session("loginUser"))
            If _id > 0 Then
                'up loader 
                _upload_files(_objletter.profile_no, _id)
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "Javascript", "<script>alert('Record saved')</script>")
            Else
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "Javascript", "<script>alert('Record not saved')</script>")
                ErrorMessage.Text = "Not Saved !"
                Panel2.Visible = True
            End If
        Catch ex As Exception
            Dim newError As New logs(ex, "createStudnet")
            newError.Log()
            Debug.Print(ex.Message)
        End Try
        Return _id
    End Function

    Protected Sub LkSave_Click(sender As Object, e As EventArgs) Handles LkSave.Click
        Add_letter()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Panel3.Visible = False
        Panel1.Visible = True
        Button3.Visible = False
        LinkButton7.Visible = False
        LinkButton8.Visible = False
        Lkupdate.Visible = False
        LkSave.Visible = True
    End Sub

    Private Sub LinkButton2_Click(sender As Object, e As EventArgs) Handles LinkButton2.Click
        'Txt_letter_to.Text = "na"
        'Txt_letter_date.Text = Date.MinValue
        Panel1.Visible = False
        Panel3.Visible = True
        pnlframePDF.Visible = False
        pnlframePDF.CssClass = "col-md-2"
        Panel4.CssClass = "col-md-10"
        Dim myiFrame As HtmlControl = CType(Me.Master.FindControl("MainContent").FindControl("letterURL"), HtmlIframe)
        myiFrame.Attributes("src") = ""
    End Sub
    Private Sub LinkButton5_Click(sender As Object, e As EventArgs) Handles LinkButton5.Click
        pnlframePDF.Visible = False
        pnlframePDF.CssClass = "col-md-2"
        Panel4.CssClass = "col-md-10"
    End Sub
    Protected Sub GridView2_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView2.RowCommand
        Dim gvr As GridViewRow = CType(CType(e.CommandSource, LinkButton).NamingContainer, GridViewRow)
        Dim dt As New DataTable
        Dim id As Integer
        If Not e.CommandName = "New" Then
            id = CType(GridView2.DataKeys(gvr.RowIndex).Value, Integer)
            dt = dbaccess.Get_letter_info_By_ID(id, "englishletter")
        End If
        If e.CommandName = "Amend" Or e.CommandName = "Letter" Then
            LinkButton7.Visible = False
            studentFiller()
            Panel3.Visible = False
            Panel1.Visible = True
            pnlframePDF.Visible = False
            pnlframePDF.CssClass = "col-md-2"
            Panel4.CssClass = "col-md-10"
            'file file name
            Dim filename As String = dt.Rows(0)("filename").ToString
            If Not String.IsNullOrEmpty(filename.ToString) Then
                lbl_file_info.Text = filename.ToString
                'LinkButton7.Visible = True
                FileUpload1.Visible = False
            Else
                lbl_file_info.Text = "No upload !"

                'LinkButton7.Visible = False
                FileUpload1.Visible = True
            End If
            LkSave.Visible = False
            Lkupdate.Visible = True
            Txt_letter_to.Text = dt.Rows(0)("letterto").ToString
            Txt_letter_date.Text = dt.Rows(0)("letterdate").ToString
            lblpath.Text = dt.Rows(0)("path").ToString
            txt_letter_subj.Text = dt.Rows(0)("lettersubject").ToString
            txt_letter_body.Text = dt.Rows(0)("lettertext").ToString
            lbllid.Text = id
            If String.IsNullOrEmpty(Txt_letter_date.Text) = False Then Txt_letter_date.Text = Txt_letter_date.Text.Replace("00:00:00", "")

            'LinkButton7.Visible = True
            LinkButton8.Visible = True
            'ElseIf e.CommandName = "Letter" Then
            Dim myiFrame As HtmlControl = CType(Me.Master.FindControl("MainContent").FindControl("letterURL"), HtmlIframe)
            myiFrame.Attributes("src") = ""
            Dim path = dt.Rows(0)("path").ToString
            If String.IsNullOrEmpty(path.ToString) = True Then
                ScriptManager.RegisterClientScriptBlock(Me, Me.GetType, "alertMessage", "alert('No PDF Found!')", True)
            Else
                pdfviewer(path)
            End If

            Panel5.Visible = False

            Dim role As String = lblrole.Text
            Select Case role
                Case "Student"
                    LinkButton7.Visible = False
                Case "Supervisor"
                    'supervisor screen
                Case "Admin"
                    'admin 
                Case "Super-Admin"
                Case Else
            End Select
        ElseIf e.CommandName = "New" Then
            FileUpload1.Visible = True
            studentFiller()
            Panel3.Visible = False
            Panel1.Visible = True
            pnlframePDF.Visible = False
            pnlframePDF.CssClass = "col-md-2"
            Panel4.CssClass = "col-md-10"
            LkSave.Visible = True
            Lkupdate.Visible = False
            clear_txt()

        ElseIf e.CommandName = "Inactive" Then
            'delete method
            _delete_letter(id)
            ScriptManager.RegisterClientScriptBlock(Me, Me.GetType, "alertMessage", "alert('Record Deleted!')", True)
            GridView2.DataBind()
        End If
    End Sub
    Dim PDFOutput As String
    Protected Sub clear_txt()
        Txt_letter_to.Text = ""
        Txt_letter_date.Text = ""
        txt_letter_subj.Text = ""
        txt_letter_body.Text = ""
        lbl_file_info.Text = ""
        LinkButton7.Visible = False
        LinkButton8.Visible = False

    End Sub
    Protected Sub SetIframeURL(ByVal path As String)
        Dim a As String = path.ToString
        Dim requestURL As String = Request.Url.GetLeftPart(UriPartial.Authority) & Request.Url.GetLeftPart(UriPartial.Authority)
        Dim singleURL As String = Request.Url.GetLeftPart(UriPartial.Authority)
        Try
            If Not a Is Nothing Then
                requestURL = Request.Url.GetLeftPart(UriPartial.Authority)
                Dim myiFrame As HtmlControl = CType(Me.Master.FindControl("MainContent").FindControl("letterURL"), HtmlIframe)
                Dim x As String
                If a.ToString.Contains(requestURL) Then
                    x = a
                    myiFrame.Attributes("src") = x
                Else
                    x = a
                    myiFrame.Attributes("src") = x
                End If
                PDFOutput = $"{HttpRuntime.AppDomainAppPath}{Session("Generated-Output")}".Replace("/", "\").Replace("\\", "\")
            End If
        Catch ex As Exception
            'Dim newError As New sbc_errors(ex, "")
            'newError.Log()
            ClientScript.RegisterStartupScript(Me.GetType(), "Saved",
                                               "alertify.warning('Setting iFrame - " &
                                               ex.Message.Replace("'", "") & "');", True)
            Exit Sub
        End Try

    End Sub

    Protected Sub pdfviewer(ByVal path As String)
        pnlframePDF.Visible = True
        pnlframePDF.CssClass = "col-md-6"
        Panel4.CssClass = "col-md-6"

        If Not String.IsNullOrEmpty(path.ToString) Then
            SetIframeURL(path)
        End If
    End Sub
    Private Sub btn_close_Click(sender As Object, e As EventArgs) Handles btn_close.Click
        Response.Redirect("~/Student_Files/StudentForm.aspx", False)
    End Sub

    Protected Sub LinkButton8_Click(sender As Object, e As EventArgs) Handles LinkButton8.Click
        pdfviewer(lblpath.Text)
    End Sub


    Function _update_letter(ByVal id As Integer) As Boolean
        Dim result As Boolean = False
        Dim objStudent As New mb_st_details
        objStudent = Session("Student")
        Dim _id As Integer = 0
        Dim _objletter As New englishletter
        _objletter.profile_no = lblprofileno.Text 'txt_profile_no.Text
        _objletter.lettersubject = txt_letter_subj.Text
        _objletter.letterto = Txt_letter_to.Text
        _objletter.letterdate = Txt_letter_date.Text
        _objletter.lettertext = txt_letter_body.Text
        _objletter.modified_by = Session("Login_name")
        _objletter.englishid = lbllid.Text
        Try
            Dim a = dbaccess.Update_english_letter(_objletter)
            If a = 1 Then
                result = True
            Else
                result = False
            End If
        Catch ex As Exception

        End Try
        Return result
    End Function

    Private Sub Lkupdate_Click(sender As Object, e As EventArgs) Handles Lkupdate.Click
        Dim _id As Integer = Convert.ToInt32(lbllid.Text)
        Dim a = _update_letter(_id)
        ' if file upload has file then upload 
        GridView2.DataBind()
        If FileUpload1.HasFile Then
            Dim ext As String = Path.GetExtension(FileUpload1.PostedFile.FileName)
            If ext = ".pdf" Then
                _upload_files(lblprofileno.Text, _id)
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "Javascript", "<script>alert('Record saved')</script>")
                Panel1.Visible = False
                Panel3.Visible = True
            Else
                ErrorMessage.Text = "Only pdf file allowed." + Environment.NewLine
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "Javascript", "<script>alert('Only pdf file allowed.')</script>")
                Exit Sub
            End If
        Else
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "Javascript", "<script>alert('Record updated')</script>")
            Panel1.Visible = False
            Panel3.Visible = True
        End If
    End Sub

    Function _delete_letter(ByVal id As Integer) As Boolean
        Dim result As Boolean = False
        Dim _id As Integer = 0
        Dim _objletter As New arabicletter
        _objletter.modified_by = Session("Login_name")
        _objletter.arabicid = id
        Try
            Dim a = dbaccess.delete_english_letter(_objletter)
            If a = 1 Then
                result = True
            Else
                result = False
            End If
        Catch ex As Exception

        End Try
        Return result
    End Function


    Private Sub GridView2_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridView2.RowDataBound
        If (e.Row.RowType = DataControlRowType.DataRow) Then
            Dim role As String = lblrole.Text
            Select Case role
                Case "Student"
                    'student screen
                    'student_controls()
                    Dim btnDelete As LinkButton = CType(e.Row.FindControl("LinkButton6"), LinkButton)
                    btnDelete.Visible = False
                Case "Supervisor"
                    'supervisor screen
                Case "Admin"
                    'admin 
                Case "Super-Admin"
                Case Else
            End Select

        End If
        If (e.Row.RowType = DataControlRowType.Footer) Then
            Dim role As String = lblrole.Text
            Select Case role
                Case "Student"
                    'student screen
                    'student_controls()
                    Dim btnAdd As LinkButton = CType(e.Row.FindControl("LinkButton4"), LinkButton)
                    btnAdd.Visible = False
                Case "Supervisor"
                    'supervisor screen
                Case "Admin"
                    'admin 
                Case "Super-Admin"
                Case Else
            End Select

        End If
    End Sub
End Class