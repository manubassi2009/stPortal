﻿Imports System.Net.Mail

Public Class ResetPassword1
    Inherits System.Web.UI.Page
    Dim dbaccess As New dbutil
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Session("Logged_In") Then
            'Kill Session
            Session.Abandon()
            Response.Cookies.Add(New HttpCookie("ASP.NET_SessionId", ""))
            Exit Sub
        ElseIf Session("Logged_In") Then
            ''Make check for new project variable and if not new record check project id has been populated
            'If Not Session("NewProject") = True Then
            '    If Session("Project_ID") Is Nothing Then
            '        Response.Redirect("~/search.aspx", False)
            '        Exit Sub
            '    End If
            'End If
            If Not IsPostBack = True Then
                Try
                    Dim op As String = Request.QueryString("redirectmethod")

                    If op IsNot Nothing Then
                        op = checktoken(op)
                        GatherInformation(op)
                    End If
                Catch ex As Exception
                    'Dim newError As New logs(ex, "")
                    'newError.Log()
                    'Response.Redirect("~/search.aspx", False)
                End Try
            End If
        End If
    End Sub
    'Dim type As String = Session("type")
    'If type IsNot Nothing Then
    '    Response.Redirect("~/Default-DashBoard.aspx?type=" & op & "", False)
    'Else
    '    Response.Redirect("~/Student_Files/StudentDefault.aspx", False)
    'End If

    ''/Default-DashBoard?type=2
#Region "Email"
    Private Sub email_link()
        Dim emailBody As String = ""
        Dim URL As String = ConfigurationManager.AppSettings("URL")
        emailBody = URL + "Register/ResetFormPassword.aspx?reset=" + Session("guid").ToString
        Dim mailMessage As MailMessage = New MailMessage
        mailMessage.From = New MailAddress("manufischer22@hotmail.com")
        mailMessage.Subject = "subject"
        mailMessage.Body = "Click to reset your password <br><br>" & emailBody & " <br><br>Thank you"
        mailMessage.IsBodyHtml = True
        mailMessage.To.Add(New MailAddress("mbassi2010@hotmail.com"))
        Dim smtp As SmtpClient = New SmtpClient
        smtp.Host = ConfigurationManager.AppSettings("Host")
        smtp.EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings("EnableSsl"))
        Dim NetworkCred As System.Net.NetworkCredential = New System.Net.NetworkCredential
        NetworkCred.UserName = ConfigurationManager.AppSettings("UserName")
        NetworkCred.Password = ConfigurationManager.AppSettings("Password")
        smtp.UseDefaultCredentials = True
        smtp.Credentials = NetworkCred
        smtp.Port = Integer.Parse(ConfigurationManager.AppSettings("Port"))
        Try
            smtp.Send(mailMessage)
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "Javascript", "<script>alert('Email Sent.')</script>")
        Catch ex As Exception
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "Javascript", "<script>alert('please confirm client name and try again.')</script>")

        End Try
    End Sub


#End Region

#Region "Self"
    'Function getLoggedUserType() As String
    '    Dim control As String = ""
    '    Dim roleType As String = Session("type")
    '    If UserType = 2 Then Control = "self"
    '    Return True
    'End Function
    Function checktoken(ByVal control As String) As String
        If (control = "ad6a73b9") = True Then
            control = "self"
        ElseIf (control = "4ca4adc0") Then
            control = "other"
        ElseIf (control = "1¬422d9a64499") Then
            control = "admin"
        Else
            Response.Redirect("~/Default.aspx", False)
        End If

        Return control
    End Function
    'Public Const self = "ad6a73b9"
    'Public Const other = "4ca4adc0"
    'Public Const admin = "1422d9a64499"
    Private Sub GatherInformation(ByVal control As String)
        Dim roleType As String = Session("type")
        If roleType = "2" Then control = "self"
        Try
            Select Case control
                Case "self"
                    Panel3.Visible = False
                    Panel4.Visible = False
                    Panel2.Visible = True
                    Button1.Visible = True
                    Button2.Visible = False
                    Button3.Visible = False

                Case "admin"
                    Panel3.Visible = True
                    Panel4.Visible = False
                    Panel2.Visible = False
                    Button1.Visible = False
                    Button2.Visible = True
                    Button3.Visible = False

                Case "other"
                    Panel3.Visible = False
                    Panel4.Visible = True
                    Panel2.Visible = False
                    Button1.Visible = False
                    Button2.Visible = False
                    Button3.Visible = True
                Case Else
                    Response.Redirect("~/Default.aspx", False)
            End Select
        Catch ex As Exception
            Dim newError As New logs(ex, "Reset Password -GatherInformation")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

    End Sub

#End Region

#Region "Other"

#End Region

    Protected Sub DropDownList1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DropDownList1.SelectedIndexChanged
        'need to pick the id 
        'show the next step to choose password
        If DropDownList1.SelectedIndex > 0 Then
            Panel2.Visible = True
            Button1.Visible = False
            Button2.Visible = True
            Button3.Visible = False
            DropDownList1.Enabled = False
        Else
            Panel3.Visible = True
            ErrorMessage.Text = "Select user type"
            errorSpan.Attributes.Remove("class")
            errorSpan.Attributes.Add("class", "alert alert-danger")
        End If
    End Sub

    Function updatePassword(ByVal id As Integer) As Integer
        'Dim id As String = DropDownList1.SelectedValue
        Dim result As Integer = 0
        Dim CiperCode As String = dbaccess.Get_Ciper_code_by_login_id(id)
        Dim hash_pass As String = dbaccess.MD5_Hash(dbaccess.MD5_Hash(ConfirmPassword.Text) & CiperCode)
        Dim a = dbaccess.Update_password_reset(id, hash_pass) 'LCase(ConfirmPassword.Text))
        If a > 0 Then
            '   Response.Redirect("~/Default.aspx", False)
            Span1.Attributes.Remove("class")
            Span1.Attributes.Add("class", "alert alert-success")
            ErrorMessage.Text = "Password updated"
        Else


        End If
        Return result
    End Function



    Private Sub DropDownList1_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles DropDownList1.DataBound
        DropDownList1.Items.Insert(0, New ListItem("Please Select user", "0"))
    End Sub
    Private Sub DropDownList2_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles DropDownList2.DataBound
        DropDownList2.Items.Insert(0, New ListItem("Please Select Student", "0"))
    End Sub

    Private Sub DropDownList2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DropDownList2.SelectedIndexChanged
        'need to pick the id 
        'show the next step to choose password
        If DropDownList2.SelectedIndex > 0 Then
            Panel2.Visible = True
            Button1.Visible = False
            Button2.Visible = False
            Button3.Visible = True
            DropDownList2.Enabled = False
        Else
            Panel3.Visible = True
            ErrorMessage.Text = "Select user type"
            errorSpan.Attributes.Remove("class")
            errorSpan.Attributes.Add("class", "alert alert-danger")
        End If
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim objLogin As New mb_st_log_sys_view
        objLogin = Session("objLogin")
        Dim id As Integer = objLogin.login_id
        updatePassword(id)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim id As Integer = DropDownList1.SelectedValue
        updatePassword(id)

    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim id As Integer = DropDownList2.SelectedValue
        updatePassword(id)
    End Sub

    Structure UserType
        Public Const self = "ad6a73b9"
        Public Const other = "4ca4adc0"
        Public Const admin = "1¬422d9a64499"
    End Structure
End Class