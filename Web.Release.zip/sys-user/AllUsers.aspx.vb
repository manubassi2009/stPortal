﻿Public Class AllUsers
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    'Protected Sub GridView1_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridView1.RowDataBound
    '    'Supervior:1
    '    'Admin:2
    '    If e.Row.RowType = DataControlRowType.DataRow Then
    '        Dim cell As TableCell = e.Row.Cells(4)
    '        Dim val = cell.Text
    '        If StrComp(Trim(cell.Text), "1") = False Then
    '            e.Row.Cells(5).Text = "Supervisor"
    '        ElseIf StrComp(Trim(cell.Text), "2") = False Then
    '            e.Row.Cells(5).Text = "Admin"
    '        End If
    '    End If
    'End Sub
End Class