﻿Imports System.Net.Mail

Public Class Forgot
    Inherits System.Web.UI.Page
    Dim dbaccess As New dbutil
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim a = Perform_stage_1()
        ' check the details and set GUID and send email link to the account

        'show_POP()
    End Sub

    Protected Sub show_POP()
        Try
            ScriptManager.RegisterStartupScript(Me, Me.GetType, "Pop", "Confirm();", True)
        Catch ex As Exception
            Dim newError As New logs(ex, "")
            newError.Log()
            Debug.Print(ex.Message)
        End Try
    End Sub


#Region "User Authentication"
    Function Validate_profile_fields(ByVal profile As String) As Boolean
        Dim result As Boolean
        Dim ProfileAsInt As Integer
        If Integer.TryParse(profile, ProfileAsInt) Then
            result = True

        Else
            result = False
        End If
        Return result
    End Function
    Function Validate_national_field(ByVal national As String) As Boolean
        Dim result As Boolean
        Dim AsInt As Integer
        If Integer.TryParse(national, AsInt) Then
            result = True
        Else
            result = False
        End If
        Return result
    End Function
    Function Perform_stage_1() As Boolean
        Dim result As Boolean
        Dim profileNo As Integer = 0
        Dim email As String = ""
        Dim nationalNo As Integer = 0
        'add validation to check if its not integer

        If Validate_profile_fields(txt_fileNo.Text.ToString) = True Then
            Literal1.Text = ""
            profileNo = txt_fileNo.Text
            result = True
        Else
            errorSpan.Attributes.Remove("class")
            errorSpan.Attributes.Add("class", "alert alert-danger")
            Literal1.Text = "Invalid Information"
            result = False
            Return result
            Exit Function
        End If
        email = LCase(txt_emailaddress.Text)
        'add validation to check if its not integer
        If Validate_profile_fields(txt_national_number.Text.ToString) = True Then
            Literal1.Text = ""
            nationalNo = txt_national_number.Text
            result = True
        Else
            errorSpan.Attributes.Remove("class")
            errorSpan.Attributes.Add("class", "alert alert-danger")
            Literal1.Text = "Invalid Information"
            result = False
            Return result
            Exit Function
        End If

        'Confirm_Student_at_reg
        Dim objStudent As New mb_st_details
        objStudent.profile_no = profileNo
        objStudent.stu_national_number = nationalNo
        objStudent.stu_email_address = email

        Dim confirmStudent = dbaccess.Confirm_Student_for_password(objStudent)
        If confirmStudent > 0 Then
            ' save the guid 
            Dim linkurl = dbaccess.GetOrSet_FORGOT_GUID_PASSWORD(confirmStudent)
            'create link
            Session("guid") = linkurl
            'send email
            'enable guid link
            Dim enable = dbaccess.Active_guid_key_for_password_reset(linkurl)
            'set GUID now and send the email 
            'If enable Then email_link() show_POP()
            'set GUID now and REDIRECT 
            If enable Then email_bypass()
            result = True

        Else
            errorSpan.Attributes.Remove("class")
            errorSpan.Attributes.Add("class", "alert alert-danger")
            Literal1.Text = "Invalid Information"
            result = False
        End If

        Return result
    End Function
    Protected Sub email_bypass()
        Dim URL As String = "" ' ConfigurationManager.AppSettings("URL")
        Dim RedirectURL = URL + "Register/ResetFormPassword.aspx?reset=" + Session("guid").ToString
        Response.Redirect("~/" & RedirectURL)
    End Sub

#End Region

#Region "Email"
    Private Sub email_link()
        Dim emailBody As String = ""
        Dim URL As String = ConfigurationManager.AppSettings("URL")
        emailBody = URL + "Register/ResetFormPassword.aspx?reset=" + Session("guid").ToString
        Dim mailMessage As MailMessage = New MailMessage
        mailMessage.From = New MailAddress("manufischer22@hotmail.com")
        mailMessage.Subject = "subject"
        mailMessage.Body = "Click to reset your password <br><br>" & emailBody & " <br><br>Thank you"
        mailMessage.IsBodyHtml = True
        mailMessage.To.Add(New MailAddress("mbassi2010@hotmail.com"))
        Dim smtp As SmtpClient = New SmtpClient
        smtp.Host = ConfigurationManager.AppSettings("Host")
        smtp.EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings("EnableSsl"))
        Dim NetworkCred As System.Net.NetworkCredential = New System.Net.NetworkCredential
        NetworkCred.UserName = ConfigurationManager.AppSettings("UserName")
        NetworkCred.Password = ConfigurationManager.AppSettings("Password")
        smtp.UseDefaultCredentials = True
        smtp.Credentials = NetworkCred
        smtp.Port = Integer.Parse(ConfigurationManager.AppSettings("Port"))
        Try
            smtp.Send(mailMessage)
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "Javascript", "<script>alert('Email Sent.')</script>")
        Catch ex As Exception
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "Javascript", "<script>alert('Email not Sent.')</script>")
        End Try
    End Sub
#End Region
End Class