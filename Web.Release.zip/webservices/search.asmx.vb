﻿Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.Data.SqlClient

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()>
<System.Web.Services.WebService(Namespace:="http://yourwebsite-adrres.com/")>
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)>
<ToolboxItem(False)>
Public Class search
    Inherits System.Web.Services.WebService
    Private Function GetConnectionString() As String
        Return System.Configuration.ConfigurationManager.ConnectionStrings("DBConnString").ConnectionString
    End Function

    <WebMethod(EnableSession:=True)>
    Public Function SearchUser(ByVal prefixText As String, ByVal count As Integer) As String()

        Dim con As New SqlConnection(Get_NewConn())
        'Dim con As New MySqlConnection(GetConnectionString())

        Dim business_unit As String = Session("region")
        Dim sql As String = "SELECT TOP (100) CONCAT('ID ',[user_id],': ',[full_name]) as SearchUser,[full_name] ,[full_address]      ,[email_address]"
        sql += "  FROM [mb_st_portal].[dbo].[mb_st_user] "
        sql += " where full_name Like '%" & prefixText & "%' AND active=1; "

        Dim Results As New ArrayList()

        Try
            con.Open()
            Dim com As New SqlCommand(sql, con)
            'com.Parameters.AddWithValue("@full_name", prefixText)
            Dim dr As SqlDataReader = com.ExecuteReader()
            Dim i As Integer = 0
            If dr.HasRows Then
                While dr.Read()
                    Dim str As String = dr("SearchUser").ToString()
                    str += " " + dr("full_address").ToString()
                    str += " " + dr("email_address").ToString()
                    Results.Add(str)
                    i += 1
                End While
            End If
            con.Close()
            con.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "")
            newError.Log()
            Debug.Print(ex.Message)
        Finally
            If con.State = ConnectionState.Open Then
                con.Close()
                con.Dispose()
            End If
        End Try

        Return TryCast(Results.ToArray(GetType(String)), String())

    End Function

    <WebMethod(EnableSession:=True)>
    Public Function SearchStudent(ByVal prefixText As String, ByVal count As Integer) As String()

        Dim con As New SqlConnection(Get_NewConn())
        'Dim con As New MySqlConnection(GetConnectionString())

        Dim business_unit As String = Session("region")
        Dim sql As String = "SELECT TOP (100) CONCAT('ID ',[profile_no],': ',[stu_full_name]) as SearchUser,[stu_full_name] "
        sql += "  FROM [mb_st_portal].[dbo].[mb_st_details] "
        sql += " where stu_full_name Like '%" & prefixText & "%' AND active=1; "

        Dim Results As New ArrayList()

        Try
            con.Open()
            Dim com As New SqlCommand(sql, con)
            'com.Parameters.AddWithValue("@full_name", prefixText)
            Dim dr As SqlDataReader = com.ExecuteReader()
            Dim i As Integer = 0
            If dr.HasRows Then
                While dr.Read()
                    Dim str As String = dr("SearchUser").ToString()
                    'str += " " + dr("full_address").ToString()
                    'str += " " + dr("email_address").ToString()
                    Results.Add(str)
                    i += 1
                End While
            End If
            con.Close()
            con.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "")
            newError.Log()
            Debug.Print(ex.Message)
        Finally
            If con.State = ConnectionState.Open Then
                con.Close()
                con.Dispose()
            End If
        End Try

        Return TryCast(Results.ToArray(GetType(String)), String())

    End Function

    <WebMethod(EnableSession:=True)>
    Public Function SearchStudentFiltered(ByVal prefixText As String, ByVal count As Integer) As String()
        Dim type As Integer = 0
        If String.IsNullOrWhiteSpace(Session("type")) = False Then type = Session("type")

        Dim con As New SqlConnection(Get_NewConn())
        'Dim con As New MySqlConnection(GetConnectionString())

        Dim business_unit As String = Session("region")
        Dim sql As String = ""
        sql += " SELECT  "
        sql += " CONCAT('ID ',mb_st_details.profile_no,': ',mb_st_details.stu_full_name) as SearchUser, "
        'sql += "       mb_st_details.stu_last_name, mb_st_details.stu_dob, mb_st_details.stu_gender, "
        'sql += "       mb_st_details.stu_national_number, mb_st_details.stu_passport_no, mb_st_details.st_visa_expiry_date, "
        'sql += "       mb_st_details.degree_name, mb_st_details.university_name, mb_st_details.course_name, mb_st_details.stu_address_1, "
        'sql += "        mb_st_details.stu_address_2, mb_st_details.stu_city, mb_st_details.county, mb_st_details.stu_postcode, mb_st_details.stu_country, "
        'sql += "        mb_st_details.stu_full_address, mb_st_details.stu_email_address, mb_st_details.isRegistered, "
        '   sql += "        mb_st_details.active AS student_active, entity_users.user_id AS Supervisor_id, mb_st_user.full_name FROM entity_users "
        sql += "  mb_st_details.active from  entity_users"
        sql += "        LEFT OUTER JOIN mb_st_user On entity_users.user_id = mb_st_user.user_id "
        sql += "            RIGHT OUTER JOIN mb_st_details ON entity_users.stu_id = mb_st_details.stu_id "
        sql += " where mb_st_details.stu_full_name Like '%" & prefixText & "%' AND mb_st_details.active=1 "
        If type = 2 Then
            sql += "  AND dbo.mb_st_user.user_id='" & Session("userID") & "'; "
        Else
            sql += " ; "
        End If




        Dim Results As New ArrayList()

        Try
            con.Open()
            Dim com As New SqlCommand(sql, con)
            'com.Parameters.AddWithValue("@full_name", prefixText)
            Dim dr As SqlDataReader = com.ExecuteReader()
            Dim i As Integer = 0
            If dr.HasRows Then
                While dr.Read()
                    Dim str As String = dr("SearchUser").ToString()
                    'str += " " + dr("full_address").ToString()
                    'str += " " + dr("email_address").ToString()
                    Results.Add(str)
                    i += 1
                End While
            End If
            con.Close()
            con.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "")
            newError.Log()
            Debug.Print(ex.Message)
        Finally
            If con.State = ConnectionState.Open Then
                con.Close()
                con.Dispose()
            End If
        End Try

        Return TryCast(Results.ToArray(GetType(String)), String())

    End Function




End Class