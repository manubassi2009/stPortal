﻿Public Class SupervisorList
    Inherits System.Web.UI.Page
    Dim dbaccess As New dbutil
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Session("Logged_In") Then
            'Kill Session
            Session.Abandon()
            Response.Cookies.Add(New HttpCookie("ASP.NET_SessionId", ""))
            Exit Sub
        ElseIf Session("Logged_In") Then
            ''Make check for new project variable and if not new record check project id has been populated
            'If Not Session("NewProject") = True Then
            '    If Session("Project_ID") Is Nothing Then
            '        Response.Redirect("~/search.aspx", False)
            '        Exit Sub
            '    End If
            'End If
            If Not IsPostBack = True Then
                Try
                    Dim op As String = Request.QueryString("user")
                    If op IsNot Nothing Then
                        GatherInformation(op)
                    End If
                Catch ex As Exception
                    'Dim newError As New logs(ex, "")
                    'newError.Log()
                    'Response.Redirect("~/search.aspx", False)
                End Try
            End If
        End If
    End Sub
    Protected Sub gridbind(Optional userID As Integer = 0, Optional roleID As Integer = 0)
        Try
            'Dim id As Integer = 3 '-admin 2 '- supervisor
            Dim dt As DataTable = dbaccess.Bind_All_Users(userID, roleID)
            GridView1.DataSource = dt
            GridView1.DataBind()
        Catch ex As Exception
            Dim newError As New logs(ex, "")
            newError.Log()
            Debug.Print(ex.Message)
        Finally
        End Try
    End Sub

    'Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
    '    pnl_search.Visible = True
    'End Sub


    Protected Sub hdnValue_ValueChanged(ByVal sender As Object, ByVal e As EventArgs) Handles hdnValueUser.ValueChanged
        If String.IsNullOrEmpty(txtSearch.Text) Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "Javascript", "<script>alert('Enter Employee Name')</script>")
        Else
            Dim getSearchString As String = txtSearch.Text
            Dim getUserId As Integer = dbaccess.StrBetween(getSearchString)
            gridbind(getUserId, 0)
            txtSearch.Text = ""
            Exit Sub
        End If

    End Sub
    Private Sub GatherInformation(ByVal control As String)
        Try
            Select Case control
                Case "admin"
                    Dim id As Integer = 2 '-admin 2 '- supervisor
                    gridbind(0, id)
                    Literal1.Text = control
                Case "supervisor"
                    Dim id As Integer = 1
                    gridbind(0, id)
                    Literal1.Text = control
            End Select
        Catch ex As Exception

            Dim newError As New logs(ex, "search.vb - GetProjectInformation_Search()")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

    End Sub

    Protected Sub GridView1_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView1.RowCommand
        Dim gvr As GridViewRow = CType(CType(e.CommandSource, LinkButton).NamingContainer, GridViewRow)
        Dim dt As New DataTable
        Dim id As Integer
        If Not e.CommandName = "New" Then
            id = CType(GridView1.DataKeys(gvr.RowIndex).Value, Integer)
        End If
        If e.CommandName = "Select" Then
            Dim op As String = Request.QueryString("user")
            If op = "admin" Then
                Response.Redirect("../Account/Create-User.aspx?user=admin&token=2&element=" & id, False)
            ElseIf op = "supervisor" Then
                Response.Redirect("../Account/Create-User.aspx?user=supervisor&token=2&element=" & id, False)
            End If

        End If
    End Sub


End Class