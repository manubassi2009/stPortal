﻿$(window).on('resize', function () {
    if ($(window).width() < 600) {
    //maincontent-box-middle" class="col-sm-10
        $('#maincontent-box-middle').addClass('col-sm-12');
        $('#maincontent-box-middle').removeClass('col-sm-10');

    } else {
        $('#maincontent-box-middle').addClass('col-sm-10');
        $('#maincontent-box-middle').removeClass('col-sm-12');
    }
})
