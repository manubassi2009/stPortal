﻿Public Class ResetFormPassword
    Inherits System.Web.UI.Page


    Dim dbaccess As New dbutil
    Protected Property StatusMessage() As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not String.IsNullOrEmpty(Request.QueryString("reset").ToString) Then
            Dim GUIDid = dbaccess.Get_FORGOT_GUID_PASSWORD(Request.QueryString("reset"))
            If GUIDid Then
                Try
                    If Not String.IsNullOrEmpty(Request.QueryString("reset").ToString) Then
                        'show the password div

                    Else
                        Response.Redirect("~/Default.aspx", False)
                    End If
                Catch ex As Exception
                    Dim newError As New logs(ex, "")
                    newError.Log()
                    Response.Redirect("~/Default.aspx", False)
                End Try
            Else
                Panel1.Visible = False
                Dim myStringVariable = "Token expired"
                ClientScript.RegisterStartupScript(Me.GetType, "myalert", ("alert('" _
                + (myStringVariable + "');")), True)
                '                Response.Redirect("~/Default.aspx", False)
            End If

        Else
            Response.Redirect("~/Default.aspx", False)
        End If
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim CiperCode As String = dbaccess.Get_Ciper_codeValue(Request.QueryString("reset")) ' dbaccess.Get_Ciper_code(Request.QueryString("reset"))
        ' validate password 
        Dim ValidatePass As Boolean = False
        ValidatePass = Validate_password(Password.Text, ConfirmPassword.Text)
        If ValidatePass = False Then
            Span1.Attributes.Remove("class")
            Span1.Attributes.Add("class", "alert alert-danger")
            Literal2.Text = "Password doesn't match! &nbsp;&nbsp;&nbsp;"
            Exit Sub
        Else
            ' save password &   'send email 
            Span1.Attributes.Remove("class")
            Literal2.Text = ""
            Dim GUIDid = dbaccess.Get_FORGOT_GUID_PASSWORD(Request.QueryString("reset"))
            Dim hash_pass As String = dbaccess.MD5_Hash(dbaccess.MD5_Hash(ConfirmPassword.Text) & CiperCode)
            Dim var As String = ""
            If GUIDid Then var = Request.QueryString("reset")

            If Not String.IsNullOrEmpty(var) Then
                Dim a = dbaccess.Update_guid_After_password_reset(var, hash_pass) 'LCase(ConfirmPassword.Text))
                If a > 0 Then
                    Response.Redirect("~/Default.aspx", False)
                Else

                End If
            End If


        End If





    End Sub

#Region "Password"
    Protected Sub NewVerify(sender As Object, e As CommandEventArgs)
        Dim ValidatePass As Boolean = False
        ValidatePass = Validate_password(Password.Text, ConfirmPassword.Text)
        If ValidatePass = False Then
            errorSpan.Attributes.Remove("class")
            errorSpan.Attributes.Add("class", "alert alert-danger")
            Literal2.Text = "Password doesn't match! "
            '  LinkButton1_ModalPopupExtender.Show()
            Exit Sub
        End If
    End Sub

    Function Validate_password(ByVal var1 As String, ByVal var2 As String) As Boolean
        Dim result As Boolean
        If var1 = var2 Then
            result = True
        Else
            result = False
        End If
        Return result
    End Function
#End Region


End Class