﻿Public Class Register1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            'CreateUserAccount()
        Catch ex As Exception
            Dim newError As New logs(ex, "create_user")
            newError.Log()

            If Session("Message") = "" Then
                Session("Message") = ex.Message
            End If
            Exit Sub

        End Try

    End Sub

    'Private Sub CreateUserAccount()
    '    'Check Username, Firstname and lastname against existing records for select business unit
    '    Dim Count As Integer
    '    Using con As New SqlConnection(Get_NewConn())
    '        Dim temp As New DataTable
    '        Using cmd As New SqlCommand("SELECT Count(username) FROM sbc_user_login Where LOWER(username) = ?username and active = 1;")
    '            cmd.CommandType = CommandType.Text
    '            cmd.Parameters.AddWithValue("?username", LTrim(RTrim(LCase(txtUsername.Text))))
    '            cmd.Connection = con
    '            con.Open()
    '            Count = Integer.Parse(cmd.ExecuteScalar())
    '            con.Close()
    '            con.Dispose()
    '        End Using
    '        If Count > 0 Then

    '            Session("Message") = "Username already exists."
    '            ClientScript.RegisterStartupScript(Me.GetType(), "Saved", "alertify.success('" & Session("Message") & "');", True)
    '            'Response.Redirect("~/admin/users/create-user")
    '            Exit Sub

    '        End If
    '    End Using

    '    'Check business unit and region selected
    '    If cboBusinessUnit.SelectedIndex = 0 Or cboRegion.SelectedIndex = 0 Then

    '        Session("Message") = "Please check selections for business unit and region before proceeding."
    '        ClientScript.RegisterStartupScript(Me.GetType(), "Saved", "alertify.success('" & Session("Message") & "');", True)
    '        'Response.Redirect("~/admin/users/create-user")
    '        Exit Sub

    '    End If

    '    'Check email address
    '    If txtEmail.Text.Length = 0 Then

    '        Session("Message") = "A valid email address has not been provided."
    '        ClientScript.RegisterStartupScript(Me.GetType(), "Saved", "alertify.success('" & Session("Message") & "');", True)
    '        'Response.Redirect("~/admin/users/create-user")
    '        Exit Sub

    '    ElseIf Not txtEmail.Text.Contains("@") Then

    '        Session("Message") = "A valid email address has not been provided."
    '        ClientScript.RegisterStartupScript(Me.GetType(), "Saved", "alertify.success('" & Session("Message") & "');", True)
    '        'Response.Redirect("~/admin/users/create-user")
    '        Exit Sub

    '    End If

    '    'check if username is being used already?
    '    Count = 0
    '    Using con As New MySqlConnection(Get_NewConn())
    '        Dim temp As New DataTable
    '        Using cmd As New MySqlCommand("SELECT Count(email_address_1) FROM sbc_user Where LOWER(email_address_1) = ?email and active = 1;")
    '            cmd.CommandType = CommandType.Text
    '            cmd.Parameters.AddWithValue("?email", LTrim(RTrim(LCase(txtEmail.Text))))
    '            cmd.Connection = con
    '            con.Open()
    '            Count = Integer.Parse(cmd.ExecuteScalar())
    '            con.Close()
    '            con.Dispose()
    '        End Using
    '        If Count > 0 Then

    '            Session("Message") = "Email address is already in use, please change and try again."
    '            ClientScript.RegisterStartupScript(Me.GetType(), "Saved", "alertify.success('" & Session("Message") & "');", True)

    '            'Response.Redirect("~/admin/users/create-user")
    '            Exit Sub

    '        End If
    '    End Using

    '    'Check Username populated
    '    If txtUsername.Text.Length = 0 Then

    '        Session("Message") = "A username has not been provided."
    '        ClientScript.RegisterStartupScript(Me.GetType(), "Saved", "alertify.success('" & Session("Message") & "');", True)
    '        'Response.Redirect("~/admin/users/create-user")
    '        Exit Sub

    '    End If

    '    'Check Password Length
    '    If txtPassword.Text.Length <= 7 Then

    '        Session("Message") = "Passwords needs to be at least 8 characters long."
    '        ClientScript.RegisterStartupScript(Me.GetType(), "Saved", "alertify.success('" & Session("Message") & "');", True)
    '        'Response.Redirect("~/admin/users/create-user")
    '        Exit Sub

    '    End If

    '    'Check passwords match
    '    If txtPassword.Text <> txtPassword_Confirm.Text Then

    '        Session("Message") = "Passwords do not match, please check and try again."
    '        ClientScript.RegisterStartupScript(Me.GetType(), "Saved", "alertify.success('" & Session("Message") & "');", True)
    '        'Response.Redirect("~/admin/users/create-user")
    '        Exit Sub

    '    End If
    '    Dim latitude = 0.0
    '    Dim longitude = 0.0
    '    'Query bing maps for long and lat coordinates...
    '    Dim newBingMaps As New BingMaps(LTrim(RTrim(txtAddressLine1.Text)), LTrim(RTrim(txtAddressLine2.Text)), LTrim(RTrim(UCase(txtCity.Text))), LTrim(RTrim(txtPostcode.Text)))
    '    If newBingMaps.Process() Then
    '        longitude = newBingMaps.Longitude
    '        latitude = newBingMaps.Latitude
    '    End If
    '    Dim jobtitle = txtjobtitle.Text
    '    Dim qualification = txtqualification.Text
    '    'Create User Record
    '    Dim user_id As Integer = 0
    '    Using con As New MySqlConnection(Get_NewConn())
    '        Using cmd As New MySqlCommand("INSERT INTO sbc_user (business_unit_id, region_id, title, firstname, lastname, email_address_1, telephone_1, " _
    '                                      & "address_line_1, address_line_2, address_line_3, address_line_4, city, county, postcode, created_by, created_date,latitude, longitude, jobtitle, qualification) " _
    '                                      & "VALUES (?business_unit_id, ?region_id, ?salutation, ?firstname, ?lastname, ?email, ?tel1, " _
    '                                      & "?add1, ?add2, ?add3, ?add4, ?city, ?county, ?postcode, ?created_by, ?created_date, ?latitude, ?longitude,?jobtitle,?qualification); SELECT LAST_INSERT_ID()")
    '            cmd.CommandType = CommandType.Text
    '            cmd.Parameters.AddWithValue("?business_unit_id", cboBusinessUnit.SelectedValue)
    '            cmd.Parameters.AddWithValue("?region_id", cboRegion.SelectedValue)
    '            cmd.Parameters.AddWithValue("?salutation", LTrim(RTrim(txtSalutation.Text)))
    '            cmd.Parameters.AddWithValue("?firstname", LTrim(RTrim(txtFirstname.Text)))
    '            cmd.Parameters.AddWithValue("?lastname", LTrim(RTrim(txtLastname.Text)))
    '            cmd.Parameters.AddWithValue("?email", LTrim(RTrim(txtEmail.Text)))
    '            cmd.Parameters.AddWithValue("?tel1", LTrim(RTrim(txtTelephone1.Text)))
    '            cmd.Parameters.AddWithValue("?add1", LTrim(RTrim(txtAddressLine1.Text)))
    '            cmd.Parameters.AddWithValue("?add2", LTrim(RTrim(txtAddressLine2.Text)))
    '            cmd.Parameters.AddWithValue("?add3", LTrim(RTrim(txtAddressLine3.Text)))
    '            cmd.Parameters.AddWithValue("?add4", LTrim(RTrim(txtAddressLine4.Text)))
    '            cmd.Parameters.AddWithValue("?city", LTrim(RTrim(UCase(txtCity.Text))))
    '            cmd.Parameters.AddWithValue("?county", LTrim(RTrim(txtCounty.Text)))
    '            cmd.Parameters.AddWithValue("?postcode", LTrim(RTrim(txtPostcode.Text)))
    '            cmd.Parameters.AddWithValue("?latitude", latitude)
    '            cmd.Parameters.AddWithValue("?longitude", longitude)
    '            cmd.Parameters.AddWithValue("?jobtitle", jobtitle)
    '            cmd.Parameters.AddWithValue("?qualification", qualification)
    '            cmd.Parameters.AddWithValue("?created_by", "System")
    '            cmd.Parameters.AddWithValue("?created_date", DateTime.Now)
    '            cmd.Connection = con
    '            con.Open()
    '            Try
    '                user_id = CInt(cmd.ExecuteScalar())
    '            Catch ex As Exception
    '                Dim newError As New sbc_errors(ex, "")
    '                newError.Log()
    '            End Try
    '            con.Close()
    '            con.Dispose()
    '        End Using
    '    End Using
    '    If user_id > 0 Then

    '        'Hash and Salt Passwords, store in the login table
    '        Dim salt As String = GenerateSalt()
    '        Dim hash_pass As String = MD5_Hash(MD5_Hash(txtPassword.Text) & salt)
    '        Dim hash_pass_verified As String = MD5_Hash(MD5_Hash(txtPassword_Confirm.Text) & salt)

    '        If hash_pass = hash_pass_verified Then

    '            'Create Salt for User
    '            Dim salt_id As Integer = 0
    '            Using con As New MySqlConnection(Get_NewConn())
    '                Using cmd As New MySqlCommand("INSERT INTO sbc_user_salt (user_id, salt, created_by, created_date) " _
    '                                              & "VALUES (?user_id, ?salt, ?created_by, ?created_date); SELECT LAST_INSERT_ID()")
    '                    cmd.CommandType = CommandType.Text
    '                    cmd.Parameters.AddWithValue("?user_id", user_id)
    '                    cmd.Parameters.AddWithValue("?salt", salt)
    '                    cmd.Parameters.AddWithValue("?created_by", "System")
    '                    cmd.Parameters.AddWithValue("?created_date", DateTime.Now)
    '                    cmd.Connection = con
    '                    con.Open()
    '                    salt_id = CInt(cmd.ExecuteScalar())
    '                    con.Close()
    '                    con.Dispose()
    '                End Using
    '            End Using
    '            If salt_id > 0 Then

    '                'Create Login Record
    '                Dim login_id As Integer = 0
    '                Using con As New MySqlConnection(Get_NewConn())
    '                    Using cmd As New MySqlCommand("INSERT INTO sbc_user_login (user_id, username, password, created_by, created_date) " _
    '                                                  & "VALUES (?user_id, ?username, ?password, ?created_by, ?created_date); SELECT LAST_INSERT_ID()")
    '                        cmd.CommandType = CommandType.Text
    '                        cmd.Parameters.AddWithValue("?user_id", user_id)
    '                        cmd.Parameters.AddWithValue("?username", LTrim(RTrim(txtUsername.Text)))
    '                        cmd.Parameters.AddWithValue("?password", hash_pass)
    '                        cmd.Parameters.AddWithValue("?created_by", "System")
    '                        cmd.Parameters.AddWithValue("?created_date", Date.Today)
    '                        cmd.Connection = con
    '                        con.Open()
    '                        login_id = CInt(cmd.ExecuteScalar())
    '                        con.Close()
    '                        con.Dispose()
    '                    End Using
    '                End Using
    '                If login_id > 0 Then

    '                    'Send user email with instructions for accessing the system, using the mailserver details from the business unit table

    '                    'UI alert to notify successfull account creation
    '                    'Session("Message") = "User account created successfully."
    '                    'Response.Redirect("~/admin/users/create-user")

    '                    'Response.Redirect("~/admin/users/create-user")
    '                    Session("Message") = "User account created successfully."
    '                    ClientScript.RegisterStartupScript(Me.GetType(), "Saved", "alertify.success('" & Session("Message") & "');", True)

    '                    Response.Redirect("~/admin/users/create-user", False)
    '                    Exit Sub

    '                End If
    '            End If
    '        Else

    '            Session("Message") = "Passwords do not match, please check and try again."
    '            ClientScript.RegisterStartupScript(Me.GetType(), "Saved", "alertify.success('" & Session("Message") & "');", True)
    '            'Response.Redirect("~/admin/users/create-user")
    '            Exit Sub

    '        End If

    '    End If

    'End Sub
End Class