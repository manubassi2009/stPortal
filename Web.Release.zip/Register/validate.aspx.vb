﻿Imports System.Data.SqlClient

Public Class validate
    Inherits System.Web.UI.Page
    Dim dbaccess As New dbutil
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Perform_stage_1()
        'show_POP()
    End Sub

    Protected Sub show_POP()
        Try
            ScriptManager.RegisterStartupScript(Me, Me.GetType, "Pop", "Confirm();", True)
        Catch ex As Exception
            Dim newError As New logs(ex, "")
            newError.Log()
            Debug.Print(ex.Message)
        End Try
    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ' validate password 
        Dim ValidatePass As Boolean = False
        ValidatePass = Validate_password(password.Text, confirmPassword.Text)
        If ValidatePass = False Then
            Span1.Attributes.Remove("class")
            Span1.Attributes.Add("class", "alert alert-danger")
            Literal2.Text = "Password doesn't match! &nbsp;&nbsp;&nbsp;"
            show_POP()
            Exit Sub
        Else
            ' save password &   'send email 
            Span1.Attributes.Remove("class")
            Literal2.Text = ""
            CreateUserAccount()
        End If





    End Sub


#Region "User Authentication"
    Function Validate_profile_fields(ByVal profile As String) As Boolean
        Dim result As Boolean
        Dim ProfileAsInt As Integer
        If Integer.TryParse(profile, ProfileAsInt) Then
            result = True

        Else

            result = False
        End If
        Return result
    End Function
    Function Validate_national_field(ByVal national As String) As Boolean
        Dim result As Boolean
        Dim AsInt As Integer
        If Integer.TryParse(national, AsInt) Then
            result = True
        Else
            result = False
        End If
        Return result
    End Function
    Protected Sub Perform_stage_1()
        Dim profileNo As Integer = 0
        Dim email As String = ""
        Dim nationalNo As Integer = 0
        'add validation to check if its not integer

        If Validate_profile_fields(txt_fileNo.Text.ToString) = True Then
            Literal1.Text = ""
            profileNo = txt_fileNo.Text
        Else
            errorSpan.Attributes.Remove("class")
            errorSpan.Attributes.Add("class", "alert alert-danger")
            Literal1.Text = "Invalid Information"
            Exit Sub
        End If
        email = LCase(txt_emailaddress.Text)
        'add validation to check if its not integer
        If Validate_profile_fields(txt_national_number.Text.ToString) = True Then
            Literal1.Text = ""
            nationalNo = txt_national_number.Text
        Else
            errorSpan.Attributes.Remove("class")
            errorSpan.Attributes.Add("class", "alert alert-danger")
            Literal1.Text = "Invalid Information"
            Exit Sub
        End If

        'Confirm_Student_at_reg
        Dim objStudent As New mb_st_details
        objStudent.profile_no = profileNo
        objStudent.stu_national_number = nationalNo
        objStudent.stu_email_address = email

        Dim confirmStudnet = dbaccess.Confirm_Student_at_reg(objStudent)
        If confirmStudnet Then
            show_POP()
        Else
            errorSpan.Attributes.Remove("class")
            errorSpan.Attributes.Add("class", "alert alert-danger")
            Literal1.Text = "Invalid Information"
        End If
    End Sub
#End Region

#Region "add"
    Private Sub CreateUserAccount()
        '  Dim Count As Integer = 0
        Dim email As String = txt_emailaddress.Text.Trim
        Dim confirmUserEmailExitinLogin = dbaccess.Confirm_User_Already_Registered(email)
        If confirmUserEmailExitinLogin = True Then
            Span1.Attributes.Remove("class")
            Span1.Attributes.Add("class", "alert alert-danger")
            Literal2.Text = "This Email address is already registered."
            show_POP()
            Button3.Visible = True
            Exit Sub
        Else
        End If
        'insert user
        Dim objstudent As New mb_st_details
        objstudent = dbaccess.Get_Student_details_Byemail(email)
        'check if the student is already registered
        If objstudent.isRegistered = True Then
            Span1.Attributes.Remove("class")
            Span1.Attributes.Add("class", "alert alert-danger")
            Literal2.Text = "User already registered ! Cannot re-register this account !"
            show_POP()
            Exit Sub
        Else
        End If
        If objstudent.stu_id > 0 Then
            'get the entity_id 
            Dim objEntity As New entity_users
            objEntity = dbaccess.Get_Entity_ID_For_Student_By_ID(objstudent.stu_id)
            'Hash and Salt the Passwords, 
            Dim CiperCode As String = dbaccess.GenerateSalt()
            Dim hash_pass As String = dbaccess.MD5_Hash(dbaccess.MD5_Hash(confirmPassword.Text) & CiperCode)
            Dim hash_pass_verified As String = dbaccess.MD5_Hash(dbaccess.MD5_Hash(confirmPassword.Text) & CiperCode)
            'To do change the line above
            If hash_pass = hash_pass_verified Then
                'Create Salt for User
                Dim salt_id As Integer = dbaccess.Create_User_Ciper(objEntity.entity_user_id, CiperCode)
                If salt_id > 0 Then
                    'Create Login Record
                    Dim login_id As Integer = dbaccess.Insert_Login(objEntity.entity_user_id, txt_emailaddress.Text, hash_pass) 'confirmPassword.Text)
                    If login_id > 0 Then
                        ' update the student table that is registered 
                        Dim reg = dbaccess.Update_Student_isRegestered(objstudent.stu_id, 1)
                        'Send user email with instructions for accessing the system,using the mailserver details from the business unit table
                        ' send email part to do after the login save 

                        Span1.Attributes.Remove("class")
                        Span1.Attributes.Add("class", "alert alert-success")
                        Literal2.Text = "User account created successfully."
                        Button3.Visible = True
                    Else
                        Span1.Attributes.Remove("class")
                        Span1.Attributes.Add("class", "alert alert-danger")
                        Literal2.Text = "error! "
                        show_POP()

                        Exit Sub

                    End If
                End If
            Else
                errorSpan.Attributes.Remove("class")
                errorSpan.Attributes.Add("class", "alert alert-success")
                Literal2.Text = "User account created successfully."
                Exit Sub

            End If

        End If

    End Sub





#End Region


#Region "Password"
    Protected Sub NewVerify(sender As Object, e As CommandEventArgs)
        Dim ValidatePass As Boolean = False
        ValidatePass = Validate_password(password.Text, confirmPassword.Text)
        If ValidatePass = False Then
            errorSpan.Attributes.Remove("class")
            errorSpan.Attributes.Add("class", "alert alert-danger")
            Literal2.Text = "Password doesn't match! "
            '  LinkButton1_ModalPopupExtender.Show()
            Exit Sub
        End If
    End Sub

    Function Validate_password(ByVal var1 As String, ByVal var2 As String) As Boolean
        Dim result As Boolean
        If var1 = var2 Then
            result = True
        Else
            result = False
        End If
        Return result
    End Function
#End Region

End Class