﻿Imports System.Data
Imports System.Data.SqlClient
Imports mb_sd_portal
'Imports mb_sd_portal

Public Class _Default
    Inherits System.Web.UI.Page
    Dim dbaccess As New dbutil
    Dim SALT_KEY As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Session("Logged_In") Then
        '    'Kill Session
        '    Session.Abandon()
        '    Response.Cookies.Add(New HttpCookie("ASP.NET_SessionId", ""))
        '    Exit Sub
        'End If
        If Not Me.IsPostBack Then
            Session.Abandon()
            Response.Cookies.Add(New HttpCookie("ASP.NET_SessionId", ""))
            Session.Clear()
            'clear session
            Session.Abandon()
            'Abandon session
            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1))
            Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Response.Cache.SetNoStore()

            If Session("Message") IsNot Nothing Then
                Session("Message") = Nothing
            End If

        Else
            If Session("Message") IsNot Nothing Then
                Session("Message") = Nothing
                Session.Abandon()
                Response.Cookies.Add(New HttpCookie("ASP.NET_SessionId", ""))
            End If
        End If
    End Sub


    Protected Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        Authenticate()

    End Sub

#Region "Forgot Password"

    'Protected Sub ForgotPassword_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    '    Dim da As New MySqlDataAdapter
    '    Dim dt As New DataTable

    '    Dim email As String = LCase(txtPassReset.Text)

    '    'Get list of Users from the existing DB
    '    Using con As New MySqlConnection(Get_NewConn())
    '        Using _
    '            cmd As _
    '                New MySqlCommand(
    '                    "SELECT u.user_id, u.business_unit_id, u.firstname, u.email_address_1, ul.username, us.salt FROM sbc_user u INNER JOIN sbc_user_login ul on u.user_id = ul.user_id " _
    '                    & "INNER JOIN sbc_user_salt us on u.user_id = us.user_id WHERE LOWER(u.email_address_1) = '" &
    '                    email & "' AND u.active = 1;", con)

    '            Try
    '                con.Open()
    '                da = New MySqlDataAdapter(cmd)
    '                da.Fill(dt)
    '                con.Close()
    '                con.Dispose()
    '            Catch ex As Exception
    '                Dim newError As New sbc_errors(ex, "login.vb - ForgotPassword_Click()")
    '                newError.Log()

    '                Debug.WriteLine(ex.Message)
    '                con.Close()
    '                con.Dispose()
    '                Exit Sub

    '            End Try

    '        End Using
    '    End Using

    '    If dt.Rows.Count > 0 Then
    '        If dt.Rows.Count = 1 Then
    '            'Reset and send email to the user
    '            For Each row As DataRow In dt.Rows
    '                Dim bu_id As Integer = 4 'Send from stroma exchange
    '                Dim user_id As Integer = row.Item("user_id")
    '                Dim firstname As String = row.Item("firstname")
    '                Dim salt As String = row.Item("salt")
    '                Dim NewPassword As String = CreateRandomPassword(12)
    '                Dim hash_pass As String = MD5_Hash(MD5_Hash(NewPassword) & salt)
    '                'Update the password on the DB
    '                Try
    '                    Using con As New MySqlConnection(Get_NewConn())
    '                        Using _
    '                            cmd As _
    '                                New MySqlCommand(
    '                                    "Update sbc_user_login Set password = ?pass, modified_by = ?modified_by, modified_date = ?modified_date Where user_id = ?user_id;")
    '                            cmd.CommandType = CommandType.Text
    '                            cmd.Parameters.AddWithValue("?user_id", user_id)
    '                            cmd.Parameters.AddWithValue("?pass", hash_pass)
    '                            cmd.Parameters.AddWithValue("?modified_by", "System")
    '                            cmd.Parameters.AddWithValue("?modified_date", DateTime.Now)
    '                            cmd.Connection = con
    '                            con.Open()
    '                            cmd.ExecuteNonQuery()
    '                            con.Close()
    '                            con.Dispose()
    '                        End Using
    '                    End Using

    '                    Dim _
    '                        SendEmail As _
    '                            New Thread(Sub() SendEmailNotification(bu_id, NewPassword, email, firstname)) With {
    '                            .IsBackground = True,
    '                            .Priority = ThreadPriority.Lowest
    '                            }
    '                    SendEmail.Start()

    '                    'UI alert to notify successfull account creation
    '                    Session("Message") = "A notification email has been sent to the email address provided."

    '                    Response.Redirect("~/Default", False)
    '                    Exit Sub
    '                Catch ex As Exception
    '                    Dim newError As New sbc_errors(ex, "login.vb - ForgotPassword_Click()")
    '                    newError.Log()
    '                    'UI alert to notify successfull account creation
    '                    'Session("Message") = ""

    '                    Response.Redirect("~/Default", False)
    '                    Exit Sub

    '                End Try

    '            Next
    '        ElseIf dt.Rows.Count > 1 Then
    '            'Send email to the service desk requesting they contact the users individually to see who is trying to reset their password

    '            'UI alert to notify successfull account creation
    '            'Session("Message") = ""

    '            Response.Redirect("~/Default", False)
    '            Exit Sub

    '        End If

    '        'UI alert to notify successfull account creation
    '        'Session("Message") = ""

    '        Response.Redirect("~/Default", False)
    '        Exit Sub

    '    End If
    'End Sub

    'Protected Sub SendEmailNotification(ByVal _bu_id As Integer, ByRef _NewPassword As String, ByRef _email As String,
    '                                    ByRef _firstname As String)

    '    Dim da As New MySqlDataAdapter
    '    Dim dt As New DataTable

    '    Using con As New MySqlConnection(Get_NewConn())
    '        Using _
    '            cmd As _
    '                New MySqlCommand(
    '                    "SELECT * FROM sbc_business_unit_smtp WHERE business_unit_id = " & _bu_id & " AND active = 1;",
    '                    con)

    '            Try
    '                con.Open()
    '                da = New MySqlDataAdapter(cmd)
    '                da.Fill(dt)
    '                con.Close()
    '                con.Dispose()
    '            Catch ex As Exception
    '                Dim newError As New sbc_errors(ex, "login.vb - SendEmailNotification()")
    '                newError.Log()

    '                Debug.WriteLine(ex.Message)
    '                con.Close()
    '                con.Dispose()
    '                Exit Sub

    '            End Try

    '        End Using
    '    End Using

    '    If dt.Rows.Count = 1 Then
    '        With dt.Rows(0)

    '            Try

    '                Dim smtp_server As New SmtpClient
    '                Dim email As New MailMessage()

    '                Dim outbound_user As String = .Item("outbound_username")
    '                Dim outbound_pass As String = .Item("outbound_password")

    '                smtp_server.UseDefaultCredentials = False
    '                smtp_server.Credentials = New Net.NetworkCredential(outbound_user, outbound_pass)
    '                smtp_server.Port = .Item("outbound_port")
    '                smtp_server.EnableSsl = .Item("enable_ssl")
    '                smtp_server.Host = .Item("outbound_hostname")

    '                Dim emBody As String = ""

    '                emBody += "Dear " & _firstname & ", <br /><br />"
    '                emBody += "A request was made from the Data Management System, to reset your password. <br /><br />"
    '                emBody += "Please find below your new password; <br /><br />"
    '                emBody += "&emsp; &emsp; <strong>" & _NewPassword & "</strong> <br /><br />"
    '                emBody +=
    '                    "If you have recieved this in error or are unsure about the request, please contact the service desk for more information. <br /><br />"
    '                emBody +=
    '                    "Email: <a href='mailto:servicedesk@stroma.com?Subject=DMS%20Password%20Reset%20Query' target='_top'>servicedesk@stroma.com</a> <br /><br />"
    '                emBody += "Kind regards <br /><br />"
    '                emBody += "The Servicedesk Team <br />"
    '                emBody += "Stroma Group"

    '                email = New MailMessage()
    '                email.From = New MailAddress(.Item("from_address"))
    '                email.To.Add(_email)
    '                email.Subject = "Stroma Building Control: Password Reset Request"
    '                email.IsBodyHtml = True
    '                email.Body = emBody

    '                smtp_server.Send(email)
    '            Catch ex As Exception
    '                Dim newError As New sbc_errors(ex, "login.vb - SendEmailNotification()")
    '                newError.Log()

    '                Debug.WriteLine(ex.Message)

    '            End Try

    '        End With
    '    End If
    'End Sub

    'Public Function CreateRandomPassword(ByVal PasswordLength As Integer) As String
    '    Dim _allowedChars As String = "abcdefghijkmnopqrstuvwxyz!?#$+-*&?:ABCDEFGHJKLMNOPQRSTUVWXYZ0123456789"
    '    Dim randomNumber As New Random()
    '    Dim chars(PasswordLength - 1) As Char
    '    Dim allowedCharCount As Integer = _allowedChars.Length
    '    For i As Integer = 0 To PasswordLength - 1
    '        chars(i) = _allowedChars.Chars(CInt(Fix((_allowedChars.Length) * randomNumber.NextDouble())))
    '    Next i
    '    Return New String(chars)
    'End Function

    'Function MD5_Hash(ByVal SourceText As String) As String
    '    Try
    '        Dim MD5 As New System.Security.Cryptography.MD5CryptoServiceProvider
    '        Dim rawBytes As Byte() = System.Text.ASCIIEncoding.ASCII.GetBytes(SourceText)
    '        Dim myHash As Byte() = MD5.ComputeHash(rawBytes)
    '        Dim Capacity As Integer = (myHash.Length * 2 + (myHash.Length / 8))
    '        Dim result As New System.Text.StringBuilder(Capacity)
    '        Dim i As Integer
    '        For i = 0 To myHash.Length - 1
    '            result.Append(BitConverter.ToString(myHash, i, 1))
    '        Next i
    '        Return result.ToString().TrimEnd(New Char() {" "c}).ToLower
    '        Return "0"
    '    Catch ex As Exception
    '        Dim newError As New sbc_errors(ex, "login.vb - MD5_Hash()")
    '        newError.Log()
    '        Return "0"
    '    End Try
    'End Function

#End Region

#Region "User Authentication"

    Protected Sub Authenticate()
        errorSpan.Attributes.Remove("class")
        Dim da As New SqlDataAdapter
        Dim dt As New DataTable
        Dim username As String = LCase(txt_sd_us.Value)
        Dim password As String = txt_sd_ps.Value
        dt = dbaccess.Get_log_details_Byemail(username)
        'Get salt
        If dt.Rows.Count = 1 Then
            With dt.Rows(0)
                Dim objLogin As New mb_st_log_sys_view
                objLogin = dbutil.DataTableToList(Of mb_st_log_sys_view)(dt)
                Dim objstLogin As New mb_st_log
                objstLogin = dbutil.DataTableToList(Of mb_st_log)(dt)
                Dim verify_pass As String = objLogin.password
                Dim SALT = dbaccess.Get_Ciper_code_by_ENTITY_id(objstLogin.entity_user_id)
                Dim Entered_Pass As String = dbaccess.MD5_Hash(dbaccess.MD5_Hash(password) & SALT)
                'Check passwords match
                If verify_pass = Entered_Pass Then
                    'Set Session variables
                    Session.Timeout = 30
                    Session("Logged_In") = True
                    Session("LoginView") = objLogin
                    'Update last access
                    Dim a = dbaccess.UpdateLastLogin(objLogin.login_id)
                    'Permissions
                    If Request.Browser.IsMobileDevice Then
                        'Response.Redirect("~/mobile/search", False)
                        Response.Redirect("~/Default-DashBoard.aspx", False)
                        Exit Sub
                    Else
                        'Or v.IsMatch(Left(u, 4))
                        Dim u As String = Request.ServerVariables("HTTP_USER_AGENT")
                        'Dim u As String = "Mozilla/5.0 (Linux; Android 6.0; SAMSUNG SM-G930F Build/MMB29K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/4.0 Chrome/44.0.2403.133 Mobile Safari/537.36"
                        Dim _
                                    b As _
                                        New Regex(
                                            "(android|bb\d+|meego).+mobile|avantgo|Samsung|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino",
                                            RegexOptions.IgnoreCase)
                        Dim _
                                    v As _
                                        New Regex(
                                            "1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-",
                                            RegexOptions.IgnoreCase)
                        If b.IsMatch(u) Or v.IsMatch(Left(u, 4)) Or u.ToString.Contains("Samsung") Or
                                   u.ToString.Contains("SM-") Then
                            'for mobile
                            Response.Redirect("~/Default-DashBoard.aspx", False)
                            Exit Sub
                        Else
                            'TO DO: temp
                            Session("objLogin") = objLogin
                            ' TO DO FINISHED 
                            If (objLogin.role_id = 1) Then
                                ' student
                                Dim objStudentGetName = dbaccess.Get_StudentInfo_ByID(objLogin.stu_id)
                                Session("Student") = objStudentGetName
                                Session("Login_name") = objStudentGetName.stu_full_name
                                Session("avatar") = objStudentGetName.stu_first_name.Substring(0, 1) & "" & objStudentGetName.stu_last_name.Substring(0, 1)
                                Response.Redirect("~/Student_Files/StudentDefault.aspx", False)

                            ElseIf (objLogin.role_id = 4) Then
                                'super-admin
                                Dim objUserGetName = dbaccess.Get_UserInfo_ByID(objLogin.user_id)
                                Session("Login_name") = objUserGetName.full_name
                                Session("type") = "4"
                                Session("avatar") = objUserGetName.first_name.Substring(0, 1) & "" & objUserGetName.last_name.Substring(0, 1)
                                Response.Redirect("~/Default-DashBoard.aspx?type=4", False)
                            ElseIf (objLogin.role_id = 2) Then
                                'supervisor 
                                Dim objUserGetName = dbaccess.Get_UserInfo_ByID(objLogin.user_id)
                                Session("Login_name") = objUserGetName.full_name
                                Session("type") = "2"
                                Session("avatar") = objUserGetName.first_name.Substring(0, 1) & "" & objUserGetName.last_name.Substring(0, 1)
                                Response.Redirect("~/Default-DashBoard.aspx?type=2", False)

                            ElseIf (objLogin.role_id = 3) Then
                                'admin 
                                Dim objUserGetName = dbaccess.Get_UserInfo_ByID(objLogin.user_id)
                                Session("Login_name") = objUserGetName.full_name
                                Session("type") = "3"
                                Session("avatar") = objUserGetName.first_name.Substring(0, 1) & "" & objUserGetName.last_name.Substring(0, 1)
                                Response.Redirect("~/Default-DashBoard.aspx?type=3", False)
                            End If

                            Exit Sub
                        End If
                    End If
                Else
                    errorSpan.Attributes.Remove("class")
                    errorSpan.Attributes.Add("class", "alert alert-danger")

                    Literal1.Text = "Invalid Login details !"
                End If

            End With
        Else
            dt = New DataTable
            'Check External Access
        End If
    End Sub
#End Region
End Class