﻿
Public Module includes

    'Get Connection String for Connection to DB
    'Public Function Get_OldConn() As String
    '    Return System.Configuration.ConfigurationManager.ConnectionStrings("DBConnString").ConnectionString
    'End Function

    Public Function Get_NewConn() As String
        Return System.Configuration.ConfigurationManager.ConnectionStrings("DefaultConnection").ConnectionString
    End Function

    'Public _SRV As String = "DESKTOP-RJ1I6MG"
    'Public _DB As String = "db-name"
    'Public _UID As String = "mb_st_portal"
    'Public _PWD As String = "Password" 'integrated

    Public _SRV As String = "localhost"
    Public _DB As String = "mb_st_portal"
    Public _UID As String = "admin"
    Public _PWD As String = "27drFz0?"

    Public AbsPath_DEV As String = "X:\Production\"

End Module
