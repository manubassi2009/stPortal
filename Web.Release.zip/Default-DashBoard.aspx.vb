﻿Public Class Default_DashBoard
    Inherits System.Web.UI.Page
    Dim dbaccess As New dbutil
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Session("Logged_In") Then
            'Kill Session
            Session.Abandon()
            Response.Cookies.Add(New HttpCookie("ASP.NET_SessionId", ""))
            Response.Redirect("~/Default", False)
            Exit Sub
        Else
            Session.Timeout = 30
            If Not Me.IsPostBack Then
                'Bind request details
                '  Fn_Get_No_of_requests()
                Dim op As String = Request.QueryString("type")
                If op = "find" Then
                    op = Session("type")
                    If op IsNot Nothing Then
                        Response.Redirect("~/Default-DashBoard.aspx?type=" & op & "", False)
                    Else
                        Response.Redirect("~/Student_Files/StudentDefault.aspx", False)
                    End If

                End If

                If op IsNot Nothing Then

                    GatherInformation(op)
                End If
                Dim objLogin As New mb_st_log_sys_view
                objLogin = Session("objLogin")
                'get supervisor id 
                If op = 2 Then
                    ' get the supervisor if 
                    Dim objUser As New mb_st_user
                    objUser = dbaccess.Get_User_ID_By_Entity_ID(objLogin.entity_user_id)
                    Session("objUser") = objUser
                    Session("userID") = objUser.user_id
                End If

            End If
        End If

    End Sub
    Private Sub GatherInformation(ByVal control As String)
        Dim objLogin As New mb_st_log_sys_view
        objLogin = Session("objLogin")
        'get userid from entity
        Dim objUser As New mb_st_user
        objUser = dbaccess.Get_User_ID_By_Entity_ID(objLogin.entity_user_id)
        Dim objRequestView_DT As New DataTable
        Try
            Select Case control
                Case "2" 'supervisor
                    'Dim id As Integer = 2
                    'gridbind(0, id)
                    objRequestView_DT = dbaccess.Bind_Request_form(0, 0, objUser.user_id)
                    GridView1.DataSource = objRequestView_DT
                    GridView1.DataBind()
                    Fn_Get_Pending_requests(objRequestView_DT)
                    Fn_Get_total_of_requests(objRequestView_DT)
                    count_student_by_supervisor(objUser.user_id, 0, 0)
                Case "3" 'admin
                    objRequestView_DT = dbaccess.Bind_Request_form(0, 0, 0)
                    GridView1.DataSource = objRequestView_DT
                    GridView1.DataBind()
                    Fn_Get_Pending_requests(objRequestView_DT)
                    Fn_Get_total_of_requests(objRequestView_DT)

                Case "4" 'super-admin
                    objRequestView_DT = dbaccess.Bind_Request_form(0, 0, 0)
                    GridView1.DataSource = objRequestView_DT
                    GridView1.DataBind()
                    Fn_Get_Pending_requests(objRequestView_DT)
                    Fn_Get_total_of_requests(objRequestView_DT)

            End Select
        Catch ex As Exception

            Dim newError As New logs(ex, "search.vb - GetProjectInformation_Search()")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

    End Sub

    Private Sub GatherPendingInformation(ByVal control As String)
        Dim objLogin As New mb_st_log_sys_view
        objLogin = Session("objLogin")
        'get userid from entity
        Dim objUser As New mb_st_user
        objUser = dbaccess.Get_User_ID_By_Entity_ID(objLogin.entity_user_id)
        Dim objRequestView_DT As New DataTable
        Try
            Select Case control
                Case "2" 'supervisor
                    objRequestView_DT = dbaccess.Bind_Request_form(0, 0, objUser.user_id)

                    Fn_GridBind_Pending_requests(objRequestView_DT)
                Case "3" 'admin
                    objRequestView_DT = dbaccess.Bind_Request_form(0, 0, 0)
                    Fn_GridBind_Pending_requests(objRequestView_DT)
                Case "4" 'super-admin
                    objRequestView_DT = dbaccess.Bind_Request_form(0, 0, 0)
                    Fn_GridBind_Pending_requests(objRequestView_DT)
            End Select
        Catch ex As Exception
            Dim newError As New logs(ex, "gather pending")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

    End Sub

    Protected Sub gridbind(Optional userID As Integer = 0, Optional roleID As Integer = 0)
        Try
            'Dim id As Integer = 3 '-admin 2 '- supervisor
            Dim dt As DataTable = dbaccess.Bind_All_Users(userID, roleID)
            GridView1.DataSource = dt
            GridView1.DataBind()
        Catch ex As Exception
            Dim newError As New logs(ex, "")
            newError.Log()
            Debug.Print(ex.Message)
        Finally
        End Try
    End Sub
    Protected Sub count_student_by_supervisor(Optional userID As Integer = 0, Optional entity_user_id As Integer = 0, Optional stu_id As Integer = 0)
        Try
            Dim dt As DataTable = dbaccess.Get_List_of_student_By_Supervisor_ID(userID, entity_user_id, stu_id)
            Dim objList As New List(Of vw_supervisor_student)
            objList = dbutil.DataTableTo_Multi_List(Of vw_supervisor_student)(dt)
            lk_no_of_students.Text = (From r In objList
                                      Select r).Count().ToString
        Catch ex As Exception
            Dim newError As New logs(ex, "")
            newError.Log()
            Debug.Print(ex.Message)
        Finally
        End Try
    End Sub

    Protected Sub Fn_Get_No_of_requests(ByVal _dt As DataTable)
        'Dim objRequestView_DT As New DataTable
        'objRequestView_DT = dbaccess.Bind_Request_form(0, 0, 0)
        Dim objReqQueue_ As New List(Of Request_form_queue)
        If _dt.Rows.Count > 0 Then
            objReqQueue_ = dbutil.DataTableTo_Multi_List(Of Request_form_queue)(_dt)
            Session("objReqQueue_List") = objReqQueue_
            ' get the number of rows of total requests
            Lk_Req_all.Text = _dt.Rows.Count.ToString
            'pending check, count where status=0 from the list
            Lk_pending.Text = (From r In objReqQueue_
                               Where r.status = 0
                               Select r).Count().ToString

        End If

    End Sub

    Protected Sub Fn_Get_Pending_requests(ByVal _dt As DataTable)
        Dim objReqQueue_ As New List(Of Request_form_queue)
        If _dt.Rows.Count > 0 Then
            objReqQueue_ = dbutil.DataTableTo_Multi_List(Of Request_form_queue)(_dt)
            Session("objReqQueue_List") = objReqQueue_
            'pending check, count where status=0 from the list
            Lk_pending.Text = (From r In objReqQueue_
                               Where r.status = 0
                               Select r).Count().ToString
        End If
    End Sub
    Protected Sub Fn_GridBind_Pending_requests(ByVal _dt As DataTable)
        Dim objReqQueue_ As New List(Of Request_form_queue)
        If _dt.Rows.Count > 0 Then
            objReqQueue_ = dbutil.DataTableTo_Multi_List(Of Request_form_queue)(_dt)
            Session("objReqQueue_List") = objReqQueue_
            'pending check, count where status=0 from the list
            'Dim dt As New DataTable
            Dim qry = From r In objReqQueue_
                      Where r.status = 0
                      Select r
            GridView1.DataSource = qry
            GridView1.DataBind()
        End If
    End Sub

    Protected Sub Fn_Get_total_of_requests(ByVal _dt As DataTable)
        Dim objReqQueue_ As New List(Of Request_form_queue)
        If _dt.Rows.Count > 0 Then
            objReqQueue_ = dbutil.DataTableTo_Multi_List(Of Request_form_queue)(_dt)
            Session("objReqQueue_List") = objReqQueue_
            ' get the number of rows of total requests
            Lk_Req_all.Text = _dt.Rows.Count.ToString
        End If

    End Sub

    Protected Sub GridView1_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim cell As TableCell = e.Row.Cells(7)
            Dim val = cell.Text
            If StrComp(Trim(cell.Text), "0") = False Then
                e.Row.Cells(7).Text = "n"
                e.Row.Cells(7).ForeColor = System.Drawing.ColorTranslator.FromHtml("#E34234")
            Else
                e.Row.Cells(7).Text = "n"
                e.Row.Cells(7).ForeColor = System.Drawing.ColorTranslator.FromHtml("#A4C639")
            End If
        End If
    End Sub

    Protected Sub GridView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridView1.SelectedIndexChanged
        Dim row As GridViewRow = GridView1.SelectedRow
        Dim _id As New Label
        _id.Text = row.Cells(1).Text
        Dim i As Integer = Convert.ToInt32(_id.Text)
        Dim _list As New Request_form_queue
        _list = dbaccess.Get_Req_Queue_By_ID(i)
        Try
            txt_req_id.Text = _list.req_id
            TextBox2.Text = _list.req_type
            txt_message_1.Text = _list.req_details_1
            If _list.re_details_more IsNot Nothing Then
                TextBox1.Text = _list.re_details_more
                TextBox1.Visible = True
            Else
                ' hide the panel
            End If
        Catch ex As Exception

        End Try

        ScriptManager.RegisterStartupScript(Me, Me.GetType, "Pop", "openModal();", True)
    End Sub

    Protected Sub CheckBox1_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs)
        Dim chkSelect As CheckBox = TryCast(sender, CheckBox)
        Dim row As GridViewRow = TryCast(chkSelect.NamingContainer, GridViewRow)
        'GridView1.SelectedIndex = row.RowIndex
        Dim id = row.Cells(1).Text

        Dim status = dbaccess.Update_Req_status(id)
        If status Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "Javascript", "<script>alert('Updated')</script>")
            Response.Redirect(Request.RawUrl)
        End If
        '   updateSageImportkey()

        'ClientScript.RegisterStartupScript([GetType](), "Load", "<script type='text/javascript'>window.parent.location.href = 'invoice_request_Pending_day.aspx'; </script>")
        'ClientScript.RegisterStartupScript([GetType](), "Load", "<script type='text/javascript'>window.parent.location.href = '../Admin_Reports_folder/invoice_request_report.aspx'; </script>")
        'invoice_request_Pending_day
    End Sub

    Private Sub Lk_Req_all_Click(sender As Object, e As EventArgs) Handles Lk_Req_all.Click
        Response.Redirect(Request.RawUrl)
    End Sub

    Private Sub Lk_pending_Click(sender As Object, e As EventArgs) Handles Lk_pending.Click
        Dim op As String = Request.QueryString("type")
        If op IsNot Nothing Then
            GatherPendingInformation(op)
        End If
    End Sub

    Protected Sub GridView2_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView2.RowCommand
        ' req id and upload id 
        Dim gvr As GridViewRow = CType(CType(e.CommandSource, LinkButton).NamingContainer, GridViewRow)
        Dim requesthandler As Integer
        Dim documenthandler As Integer
        documenthandler = CType(GridView2.DataKeys(gvr.RowIndex).Value, Integer)
        requesthandler = txt_req_id.Text
        If e.CommandName = "Select" Then
            Dim url As String = "~/sys-user/RequestViewerFull.aspx?request-handler=" & requesthandler & "&document-handler=" & documenthandler & ""
            Response.Redirect(url, False)
        End If
    End Sub

    Private Sub Default_DashBoard_PreInit(sender As Object, e As EventArgs) Handles Me.PreInit
        Dim op As String = Request.QueryString("type")
        If op = "find" Then
            op = Session("type")
            Response.Redirect("~/Default-DashBoard.aspx?type=" & op & "", False)
        End If
    End Sub

    Protected Sub lk_no_of_students_Click(sender As Object, e As EventArgs) Handles lk_no_of_students.Click
        Dim no As Integer = Convert.ToInt32(lk_no_of_students.Text)
        If no > 0 Then
            Response.Redirect("~/Student_Files/StudentFiles-Search", False)
        End If
    End Sub
End Class