﻿Public Class Student_Add
    Inherits System.Web.UI.Page
    Dim dbaccess As New dbutil
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub LkSave_Click(sender As Object, e As EventArgs) Handles LkSave.Click
        AddStudent()
    End Sub

    Private Sub AddStudent()
        If txt_email_address.Text.Length = 0 Then
            ErrorMessage.Text = "A valid email address has not been provided." + Environment.NewLine
            Exit Sub
        ElseIf Not txt_email_address.Text.Contains("@") Then
            ErrorMessage.Text = "Email address not valid" + Environment.NewLine
            Exit Sub
        End If
        txtFullName.Text = txt_Title.Text & " " & txt_First_Name.Text & " " & txt_Last_Name.Text & " "

        ' check the profile no should be unique
        If dbaccess.Confirm_User_ProfileNo_Not_Exit(Txt_Student_profile_no.Text) Then
            Panel3.Visible = True
            errorSpan.Attributes.Remove("class")
            errorSpan.Attributes.Add("class", "alert alert-danger")
            ErrorMessage.Text = "This profile is already registered."
            Exit Sub
        Else
            'insert user
            Dim user_id As Integer = 0
            user_id = insert_User()
        End If
    End Sub
    Function insert_User() As Integer
        Dim objstudent As New mb_st_details
        'Create User Record
        Dim user_id As Integer = 0
        objstudent.role_id = 1 'DropDownList1.SelectedIndex
        If Not String.IsNullOrWhiteSpace(Txt_Student_profile_no.Text) Then objstudent.profile_no = Txt_Student_profile_no.Text
        If Not String.IsNullOrWhiteSpace(txt_Title.Text) Then objstudent.stu_title = txt_Title.Text
        If Not String.IsNullOrWhiteSpace(txt_First_Name.Text) Then objstudent.stu_first_name = txt_First_Name.Text
        If Not String.IsNullOrWhiteSpace(txt_Last_Name.Text) Then objstudent.stu_last_name = txt_Last_Name.Text
        objstudent.stu_full_name = txt_Title.Text & " " & txt_First_Name.Text & " " & txt_Last_Name.Text
        objstudent.stu_full_name = dbaccess.CompressSpaces(objstudent.stu_full_name)


        If Not String.IsNullOrWhiteSpace(txt_nat_number.Text) Then objstudent.stu_national_number = txt_nat_number.Text
        'If Not String.IsNullOrWhiteSpace(txt_Passport_No.Text) Then objstudent.stu_passport_no = txt_Passport_No.Text
        If Not String.IsNullOrWhiteSpace(txt_email_address.Text) Then objstudent.stu_email_address = txt_email_address.Text

        objstudent.created_by = Session("loginUser")
        Try
            user_id = dbaccess.Insert_Sh_Student(objstudent, Session("loginUser"))
            If user_id > 0 Then
                ErrorMessage.Text = "Record Saved successfully"
                Dim objStudentGetName = dbaccess.Get_Student_by_profile_no(objstudent.profile_no)
                Session("Student") = objStudentGetName
                Response.Redirect("~/Student_Files/StudentForm.aspx", False)

            Else
                ErrorMessage.Text = "Record Not Saved successfully"
            End If
        Catch ex As Exception
            Dim newError As New logs(ex, "createStudent")
            newError.Log()
            Debug.Print(ex.Message)
        End Try
        Return user_id
    End Function



End Class