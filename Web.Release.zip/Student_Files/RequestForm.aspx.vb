﻿Imports System.IO
Imports System.Net.Mail
Imports AjaxControlToolkit

Public Class RequestForm
    Inherits System.Web.UI.Page
    Dim dbaccess As New dbutil
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Dim objStudentGetName = dbaccess.Get_StudentInfo_ByID(objLogin.stu_id)
        'Session("Student") = objStudentGetName

        If Not Session("Logged_In") Then
            '            Kill Session
            Session.Abandon()
            Response.Cookies.Add(New HttpCookie("ASP.NET_SessionId", ""))
            Response.Redirect("~/Default", False)
            Exit Sub
        ElseIf Session("Logged_In") Then
            'If Session("Message") IsNot Nothing Then

            '    ClientScript.RegisterStartupScript(Me.GetType(), "Saved", "alertify.success('" & Session("Message") & "');", True)
            '    Session("Message") = Nothing

            'End If

            If Not Me.IsPostBack Then
                Panel2.Visible = False
                'errorSpan.Attributes.Remove("class")
                'ErrorMessage.Text = ""
                'bind_list()
                Dim objStudent As New mb_st_details
                objStudent = Session("Student")
                ' If Not String.IsNullOrEmpty(Session("Student")) Then
                fill_student_info_in_req_form()
                ' End If
                Fn_Get_No_of_requests()

            End If
        Else

            If Session("Message") IsNot Nothing Then
                Session("Message") = Nothing
            End If
        End If

        ' add feature when role is admin on this page

    End Sub
    Protected Sub fill_student_info_in_req_form()
        Dim objStudent As New mb_st_details
        objStudent = Session("Student")
        txt_profile_no.Text = objStudent.profile_no
        txt_full_name.Text = objStudent.stu_full_name
        txt_full_address.Text = objStudent.stu_full_address
        txt_passport_no.Text = objStudent.stu_passport_no
        txt_nat_no.Text = objStudent.stu_national_number
        txt_email_adress.Text = objStudent.stu_email_address
        txt_visa_expiry_date.Text = objStudent.st_visa_expiry_date
        txt_mobile_no.Text = objStudent.stu_mobile_1

    End Sub

    Protected Sub Fn_Get_No_of_requests()
        Dim objStudent As New mb_st_details
        objStudent = Session("Student")


        Dim objRequestView_DT As New DataTable
        objRequestView_DT = dbaccess.Bind_Request_form(objStudent.profile_no, objStudent.stu_id, 0)
        Dim objReqQueue_ As New List(Of Request_form_queue)

        If objRequestView_DT.Rows.Count > 0 Then
            objReqQueue_ = dbutil.DataTableTo_Multi_List(Of Request_form_queue)(objRequestView_DT)
            Session("objReqQueue_List") = objReqQueue_
            ' get the number of rows of total requests
            Lk_Req_all.Text = objRequestView_DT.Rows.Count.ToString
            'pending check, count where status=0 from the list

            Lk_pending.Text = (From r In objReqQueue_
                               Where r.status = 0
                               Select r).Count().ToString
        End If

    End Sub
    Protected Sub Save_btn_Click(sender As Object, e As EventArgs) Handles Save_btn.Click
        If TextBox2.Text.Length = 0 Then
            Panel2.Visible = True
            ErrorMessage.Text = "Request Type missing ." + Environment.NewLine
            DivError.Attributes.Remove("class")
            DivError.Attributes.Add("class", "alert alert-danger")
            Exit Sub
        ElseIf txt_message_1.Text.Length = 0 Then
            Panel2.Visible = True
            ErrorMessage.Text = "Details Missing" + Environment.NewLine
            divError.Attributes.Remove("class")
            divError.Attributes.Add("class", "alert alert-danger")
            Exit Sub
        Else
            Panel2.Visible = False
            'ClientScript.RegisterClientScriptBlock(Me.GetType(), "Javascript", "<script>alert('Please confirm client name and try again.')</script>")
            Add_Req()
        End If

    End Sub

    Private Sub Add_Req()
        If txt_message_1.Text.Length = 0 Then
            'ErrorMessage.Text = "A valid email address has not been provided." + Environment.NewLine
            Exit Sub
            'ElseIf Not txt_email_address.Text.Contains("@") Then
            '    ErrorMessage.Text = "Email address not valid" + Environment.NewLine
            '    Exit Sub
        End If
        'insert request
        Dim req_id As Integer = 0
        Session("Current_req_id") = ""
        req_id = insert_req()
        'req_id = 6
        If req_id > 0 Then
            Session("Current_req_id") = req_id.ToString
            'TO DO 
            'show the picture Uploader 
            Panel3.Visible = True
            'lock the insert button
            Save_btn.Visible = False
            Button2.Visible = True
        Else
        End If

    End Sub
    Function insert_req() As Integer
        Dim objStudent As New mb_st_details
        objStudent = Session("Student")
        Dim _id As Integer = 0
        Dim objRequestForm As New mb_req_form
        ' get the entity user details 
        Dim objEntity As New entity_users
        objEntity = dbaccess.Get_Entity_ID_For_Student_By_ID(objStudent.stu_id)

        objRequestForm.stu_id = objStudent.stu_id
        objRequestForm.entity_user_id = objEntity.entity_user_id
        objRequestForm.user_id = objEntity.user_id

        objRequestForm.req_type = TextBox2.Text
        If Not String.IsNullOrWhiteSpace(txt_message_1.Text) Then objRequestForm.req_details_1 = txt_message_1.Text
        If Not String.IsNullOrWhiteSpace(TextBox1.Text) Then objRequestForm.re_details_more = TextBox1.Text
        objRequestForm.created_by = Session("loginUser")
        Try
            _id = dbaccess.Insert_Req_Student(objRequestForm, Session("loginUser"))
            If _id > 0 Then
                Panel2.Visible = True
                ErrorMessage.Text = "Request saved, Please upload files"
            Else
                ErrorMessage.Text = "Request not sent !"
                Panel2.Visible = True
            End If
        Catch ex As Exception
            Dim newError As New logs(ex, "createStudnet")
            newError.Log()
            Debug.Print(ex.Message)
        End Try
        Return _id
    End Function

    Protected Sub add_more_lk_Click(sender As Object, e As EventArgs) Handles add_more_lk.Click
        Panel1.Visible = True
    End Sub

    Private Function DivToHtml(ByVal hgc As HtmlGenericControl) As String
        Dim sb As New StringBuilder()
        Dim sw As New StringWriter(sb)
        Dim hw As New HtmlTextWriter(sw)
        hgc.RenderControl(hw)
        Return sb.ToString()
    End Function
    Private Sub email_usingwebconfig()
        Dim mailMessage As MailMessage = New MailMessage
        mailMessage.From = New MailAddress("fromemailaddress")
        mailMessage.Subject = "subject"
        mailMessage.Body = DivToHtml(regForm)
        mailMessage.IsBodyHtml = True
        mailMessage.To.Add(New MailAddress("send to email address"))
        Dim smtp As SmtpClient = New SmtpClient
        smtp.Host = ConfigurationManager.AppSettings("Host")
        smtp.EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings("EnableSsl"))
        Dim NetworkCred As System.Net.NetworkCredential = New System.Net.NetworkCredential
        NetworkCred.UserName = ConfigurationManager.AppSettings("UserName")
        NetworkCred.Password = ConfigurationManager.AppSettings("Password")
        smtp.UseDefaultCredentials = True
        smtp.Credentials = NetworkCred
        smtp.Port = Integer.Parse(ConfigurationManager.AppSettings("Port"))
        Try
            smtp.Send(mailMessage)
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "Javascript", "<script>alert('Email Sent.')</script>")
        Catch ex As Exception
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "Javascript", "<script>alert('Please confirm client name and try again.')</script>")

        End Try
    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        email_usingwebconfig()
    End Sub
    Dim createpath As String
    Protected Sub OnUploadComplete(sender As Object, e As AjaxFileUploadEventArgs)
        Dim objStudent As New mb_st_details
        objStudent = Session("Student")
        Dim fileName As String = Path.GetFileName(e.FileName)
        Dim _date As String = Replace(Date.Now.ToShortDateString, "/", "")
        'Path = "~\Uploads\reqUploads\studentProfile\requestId\Date.Now.ToShortDateString + "\"
        createpath = "~\Uploads\reqUploads\" & objStudent.profile_no & "\" & Session("Current_req_id").ToString & "\" & _date.ToString & "\"
        Directory.CreateDirectory(Server.MapPath(createpath))
        Dim saveingas As String = createpath & fileName
        AjaxFileUpload1.SaveAs(Server.MapPath(createpath & fileName))
        'run the insert to save path 
        System.Threading.Thread.Sleep(500)
        Dim filesave = insert_upload_filess(createpath, fileName)
        If filesave = False Then
            Exit Sub
        End If
    End Sub
    Function insert_upload_filess(ByVal path As String, ByVal filename As String) As Boolean
        Dim objStudent As New mb_st_details
        objStudent = Session("Student")
        Dim filesaved As Boolean = False
        Dim objFiles As New stu_req_uploaded_files
        objFiles.profileno = objStudent.profile_no
        objFiles.req_id = Session("Current_req_id")
        objFiles.filename = filename
        objFiles.path = path

        objFiles.created_by = Session("loginUser")
        Dim result As Integer = 0
        result = dbaccess.InsertFilesOnRequest(objFiles)
        If result > 0 Then
            filesaved = True
        Else
            filesaved = False
        End If
        Return filesaved
    End Function
    Protected Sub Submit(ByVal sender As Object, ByVal e As EventArgs)
        Response.Redirect("~/Student_Files/StudentDefault.aspx", False)
    End Sub
End Class