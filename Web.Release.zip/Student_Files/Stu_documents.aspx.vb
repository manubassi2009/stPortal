﻿Imports System.IO
Imports System.Net.Mail
Imports AjaxControlToolkit

Public Class Stu_documents
    Inherits System.Web.UI.Page
    Dim dbaccess As New dbutil
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Session("Logged_In") Then
            '            Kill Session
            Session.Abandon()
            Response.Cookies.Add(New HttpCookie("ASP.NET_SessionId", ""))
            Response.Redirect("~/Default", False)
            Exit Sub
        ElseIf Session("Logged_In") Then
            'If Session("Message") IsNot Nothing Then
            '    ClientScript.RegisterStartupScript(Me.GetType(), "Saved", "alertify.success('" & Session("Message") & "');", True)
            '    Session("Message") = Nothing
            'End If
            If Not Me.IsPostBack Then
                Dim objStudent As New mb_st_details
                objStudent = Session("Student")
                Label1.Text = objStudent.profile_no
            End If
        Else

            If Session("Message") IsNot Nothing Then
                Session("Message") = Nothing
            End If
        End If

    End Sub
    Dim createpath As String
    Protected Sub OnUploadComplete(sender As Object, e As AjaxFileUploadEventArgs)
        Dim objStudent As New mb_st_details
        objStudent = Session("Student")
        Dim fileName As String = Path.GetFileName(e.FileName)
        Dim _date As String = Replace(Date.Now.ToShortDateString, "/", "")
        'Path = "~\Uploads\reqUploads\studentProfile\requestId\Date.Now.ToShortDateString + "\" TYPE1
        'Path = "~\Uploads\reqUploads\studentProfile\Date.Now.ToShortDateString + "\" TYPE2

        createpath = "~\Uploads\reqUploads\" & objStudent.profile_no & "\" & _date.ToString & "\"
        Directory.CreateDirectory(Server.MapPath(createpath))
        Dim saveingas As String = createpath & fileName
        AjaxFileUpload1.SaveAs(Server.MapPath(createpath & fileName))
        'run the insert to save path 
        System.Threading.Thread.Sleep(100)
        Dim filesave = insert_upload_filess(createpath, fileName)
        If filesave = False Then
            Exit Sub
        End If
    End Sub
    Function insert_upload_filess(ByVal path As String, ByVal filename As String) As Boolean
        Dim objStudent As New mb_st_details
        objStudent = Session("Student")
        Dim filesaved As Boolean = False
        Dim objFiles As New stu_req_uploaded_files
        objFiles.profileno = objStudent.profile_no
        objFiles.req_id = Session("Current_req_id")
        objFiles.filename = filename
        objFiles.path = path

        objFiles.created_by = Session("loginUser")
        Dim result As Integer = 0
        result = dbaccess.InsertFilesOnRequest(objFiles)
        If result > 0 Then
            filesaved = True
            GridView1.DataBind()
        Else
            filesaved = False
        End If
        Return filesaved
    End Function

    'Private Sub Stu_documents_Init(sender As Object, e As EventArgs) Handles Me.Init
    '    Dim objLoginView As mb_st_log_sys_view = Session("LoginView")
    '    Dim role As New mb_st_roles
    '    role = dbaccess.Get_permissions_By_role_id(objLoginView.role_id)
    '    If role.permissions = 1 Or
    '        role.permissions = 2 Or
    '        role.permissions = 4 Then
    '        Me.MasterPageFile = "~/Master/SdDashBoardDefault.master"
    '    End If

    'End Sub

End Class