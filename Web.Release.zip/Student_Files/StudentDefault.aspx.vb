﻿Public Class StudentDefault
    Inherits System.Web.UI.Page

    Dim dbaccess As New dbutil
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Session("Logged_In") Then
            '            Kill Session
            Session.Abandon()
            Response.Cookies.Add(New HttpCookie("ASP.NET_SessionId", ""))
            Response.Redirect("~/Default", False)
            Exit Sub
        ElseIf Session("Logged_In") Then
            'If Session("Message") IsNot Nothing Then

            '    ClientScript.RegisterStartupScript(Me.GetType(), "Saved", "alertify.success('" & Session("Message") & "');", True)
            '    Session("Message") = Nothing

            'End If

            If Not Me.IsPostBack Then
                'fill student
                fill_student_info_in_req_form()
                'Bind no of request raised 
                Fn_Get_No_of_requests()
                'Get the status of first request

            End If
        Else

            If Session("Message") IsNot Nothing Then
                Session("Message") = Nothing
            End If
        End If

    End Sub

    Protected Sub fill_student_info_in_req_form()
        Dim objStudent As New mb_st_details
        objStudent = Session("Student")
        If Not String.IsNullOrEmpty(objStudent.profileimg) Then
            Image1.ImageUrl = objStudent.profileimg
        End If
        If Not String.IsNullOrEmpty(objStudent.profileimg) Then
            Image1.ImageUrl = objStudent.profileimg
        End If
    End Sub


    Protected Sub Fn_Get_No_of_requests()
        Dim objStudent As New mb_st_details
        objStudent = Session("Student")


        Dim objRequestView_DT As New DataTable
        objRequestView_DT = dbaccess.Bind_Request_form(objStudent.profile_no, objStudent.stu_id, 0)
        Dim objReqQueue_ As New List(Of Request_form_queue)

        If objRequestView_DT.Rows.Count > 0 Then
            objReqQueue_ = dbutil.DataTableTo_Multi_List(Of Request_form_queue)(objRequestView_DT)
            Session("objReqQueue_List") = objReqQueue_
            ' get the number of rows of total requests
            Lk_Req_all.Text = objRequestView_DT.Rows.Count.ToString
            'pending check, count where status=0 from the list

            Lk_pending.Text = (From r In objReqQueue_
                               Where r.status = 0
                               Select r).Count().ToString
        End If

    End Sub

    Protected Sub Lk_pending_Click(sender As Object, e As EventArgs) Handles Lk_pending.Click
        Panel1.Visible = False

        Dim val As Integer = Convert.ToInt16(Lk_pending.Text)
        If val > 0 Then
            'show active request
            Panel2.Visible = True
            Panel3.Visible = False
            Dim objReqQueue_ As List(Of Request_form_queue) = Session("objReqQueue_List")
            Dim _list = (From r In objReqQueue_
                         Where r.status = 0
                         Select r)

            Try
                GridView1_pendingList.DataSource = _list
                GridView1_pendingList.DataBind()
            Catch ex As Exception

            End Try
        Else
            'show message >> No request 

        End If


    End Sub

    Protected Sub Lk_Req_all_Click(sender As Object, e As EventArgs) Handles Lk_Req_all.Click
        Panel1.Visible = False

        Dim val As Integer = Convert.ToInt16(Lk_pending.Text)
        If val > 0 Then
            'show all request
            Panel2.Visible = False
            Panel3.Visible = True
            Dim objReqQueue_ As List(Of Request_form_queue) = Session("objReqQueue_List")
            Try
                GridView1.DataSource = objReqQueue_
                GridView1.DataBind()
            Catch ex As Exception

            End Try
        Else
            'show message >> No request 

        End If

    End Sub

    Protected Sub GridView1_pendingList_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridView1_pendingList.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim cell As TableCell = e.Row.Cells(4)
            Dim val = cell.Text
            If StrComp(Trim(cell.Text), "0") = False Then
                e.Row.Cells(4).Text = "n"
                e.Row.Cells(4).ForeColor = System.Drawing.ColorTranslator.FromHtml("#E34234")
            Else
                e.Row.Cells(4).Text = "n"
                e.Row.Cells(4).ForeColor = System.Drawing.ColorTranslator.FromHtml("#A4C639")
            End If
        End If
    End Sub

    Protected Sub GridView1_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim cell As TableCell = e.Row.Cells(4)
            Dim val = cell.Text
            If StrComp(Trim(cell.Text), "0") = False Then
                e.Row.Cells(4).Text = "n"
                e.Row.Cells(4).ForeColor = System.Drawing.ColorTranslator.FromHtml("#E34234")
            Else
                e.Row.Cells(4).Text = "n"
                e.Row.Cells(4).ForeColor = System.Drawing.ColorTranslator.FromHtml("#A4C639")
            End If
        End If
    End Sub

    Protected Sub GridView1_pendingList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridView1_pendingList.SelectedIndexChanged
        Dim row As GridViewRow = GridView1_pendingList.SelectedRow
        Dim _id As New Label
        _id.Text = row.Cells(1).Text
        Dim i As Integer = Convert.ToInt32(_id.Text)
        Dim _list As New Request_form_queue
        _list = dbaccess.Get_Req_Queue_By_ID(i)
        Try
            txt_req_id.Text = _list.req_id
            TextBox2.Text = _list.req_type
            txt_message_1.Text = _list.req_details_1
            If _list.re_details_more IsNot Nothing Then
                TextBox1.Text = _list.re_details_more
            Else
                ' hide the panel
            End If
        Catch ex As Exception

        End Try

        ScriptManager.RegisterStartupScript(Me, Me.GetType, "Pop", "openModal();", True)
    End Sub


    Protected Sub GridView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridView1.SelectedIndexChanged
        Dim row As GridViewRow = GridView1.SelectedRow
        Dim _id As New Label
        _id.Text = row.Cells(1).Text
        Dim i As Integer = Convert.ToInt32(_id.Text)
        Dim _list As New Request_form_queue
        _list = dbaccess.Get_Req_Queue_By_ID(i)
        Try
            txt_req_id.Text = _list.req_id
            TextBox2.Text = _list.req_type
            txt_message_1.Text = _list.req_details_1
            If _list.re_details_more IsNot Nothing Then
                TextBox1.Text = _list.re_details_more
            Else
                ' hide the panel
            End If
        Catch ex As Exception

        End Try

        ScriptManager.RegisterStartupScript(Me, Me.GetType, "Pop", "openModal();", True)
    End Sub



    Protected Sub LinkButton2_Click(sender As Object, e As EventArgs) Handles LinkButton2.Click
        Panel1.Visible = True
        Panel2.Visible = False
        Panel3.Visible = False

    End Sub

    Protected Sub LinkButton1_Click(sender As Object, e As EventArgs) Handles LinkButton1.Click
        Panel1.Visible = True
        Panel2.Visible = False
        Panel3.Visible = False

    End Sub
End Class