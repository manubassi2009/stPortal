﻿Imports System.IO

Public Class StudentForm
    Inherits System.Web.UI.Page

    Dim dbaccess As New dbutil
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Session("Logged_In") Then
            '            Kill Session
            Session.Abandon()
            Response.Cookies.Add(New HttpCookie("ASP.NET_SessionId", ""))
            Response.Redirect("~/Default", False)
            Exit Sub
        ElseIf Session("Logged_In") Then
            'If Session("Message") IsNot Nothing Then
            '    ClientScript.RegisterStartupScript(Me.GetType(), "Saved", "alertify.success('" & Session("Message") & "');", True)
            '    Session("Message") = Nothing
            'End If
            If Not Me.IsPostBack Then
                'Bind student details
                fill_student_info_in_req_form()
                'Get the status of first request
                'check who has logged in 
                ''Dim objLogin As New mb_st_log_sys_view=Session("LoginView")
                'Dim objLoginView = Session("LoginView")
                '  Pnl_Family_Tabs.Visible = False
                Role_defined_controls()

                Dim op As String = Request.QueryString("family")
                If op = "View" Then
                    PnlStudent.Visible = False
                    Pnl_Family.Visible = True
                    Pnl_family_form.Visible = False
                End If

                'If op IsNot Nothing Then
                '    '    GatherInformation(op)
                '    If op = 2 Then
                '        SearchAnything1.ServiceMethod = "SearchStudentFiltered"
                '        'SearchAnything1.ServicePath = "../webservices/search.asmx"
                '    Else
                '        SearchAnything1.ServiceMethod = "SearchStudent"
                '        'SearchAnything1.ServicePath = "../webservices/search.asmx"
                '    End If
                'End If


            End If
        Else

            If Session("Message") IsNot Nothing Then
                Session("Message") = Nothing
            End If
        End If
        Calendar1.SelectedDate = Today
        Admin_panels()
    End Sub

    Protected Sub fill_student_info_in_req_form()
        Dim objStudent As New mb_st_details
        objStudent = Session("Student")

        If Not String.IsNullOrEmpty(objStudent.profileimg) Then
            Image1.ImageUrl = objStudent.profileimg
        End If

        TxtStudentFile.Text = objStudent.profile_no
        If objStudent.stu_full_name Is Nothing Then
            txtFullName.Text = Trim(objStudent.stu_title) & " " & Trim(objStudent.stu_first_name) & " " & Trim(objStudent.stu_last_name)
        Else
            txtFullName.Text = objStudent.stu_full_name
        End If

        txt_Title.Text = objStudent.stu_title
        txt_First_Name.Text = objStudent.stu_first_name
        txt_Last_Name.Text = objStudent.stu_last_name
        If objStudent.stu_dob > Date.MinValue = True Then txt_dob.Text = objStudent.stu_dob

        If String.IsNullOrWhiteSpace(objStudent.stu_gender) = False Then DDL_gender.SelectedValue = objStudent.stu_gender

        txt_address_1.Text = objStudent.stu_address_1
        txt_address_2.Text = objStudent.stu_address_2
        txt_City.Text = objStudent.stu_city
        txt_country.Text = objStudent.stu_country
        txt_county.Text = objStudent.stu_county
        txt_postcode.Text = objStudent.stu_postcode
        txt_Passport_No.Text = objStudent.stu_passport_no
        txt_nat_number.Text = objStudent.stu_national_number
        If objStudent.st_visa_expiry_date > Date.MinValue = True Then txtVisaExpiryDate.Text = objStudent.st_visa_expiry_date
        txt_email_address.Text = objStudent.stu_email_address
        txt_alt_email_address.Text = objStudent.stu_alt_email_address
        txt_mobile.Text = objStudent.stu_mobile_1
        txt_mobile1.Text = objStudent.stu_mobile_2
        ' get the supervisor details using stu id
        Dim objEntity As New entity_users
        objEntity = dbaccess.Get_Entity_ID_For_Student_By_ID(objStudent.stu_id)
        Dim objUserGetName = dbaccess.Get_UserInfo_ByID(objEntity.user_id)
        ltr_supervisor.Text = objUserGetName.full_name
        If objUserGetName.full_name IsNot Nothing Then DropDownList2.Visible = False


    End Sub

    Protected Sub btnRunEmail_ServerClick(sender As Object, e As EventArgs)
        'email
    End Sub

    Protected Sub LkStuUpdate_Click(sender As Object, e As EventArgs) Handles LkStuUpdate.Click
        'update
        'ErrorMessage.Text = "Check what student can update- disabled rest of the fields "
        If FileUpload1.HasFile Then _upload_files(TxtStudentFile.Text)
        Update_student_details()

    End Sub

    Function _upload_files(ByVal stu_profile_no As Integer) As Integer
        Dim result As Integer = 0
        Dim savePath As String
        Dim createpath As String
        Dim ExtType As String = Path.GetExtension(FileUpload1.PostedFile.FileName).ToLower()
        Dim strMIME As String = Nothing
        Dim ext As String = Path.GetExtension(FileUpload1.PostedFile.FileName)
        Try
            Dim filename As String = Path.GetFileName(FileUpload1.PostedFile.FileName)
            If ext = ".jpg" Or ext = ".png" Then
                Dim _date As String = Replace(Date.Now.ToShortDateString, "/", "")
                createpath = "~\Uploads\letterUploads\Student\" & stu_profile_no.ToString & "\image\"
                Directory.CreateDirectory(Server.MapPath(createpath))
                FileUpload1.PostedFile.SaveAs(Server.MapPath(createpath & filename))
                savePath = createpath & filename
                Dim updatePath = dbaccess.Update_student_picture_path(stu_profile_no, savePath)
                result = updatePath
                ErrorMessage.Text = "File Uploaded and updated"
                Image1.ImageUrl = savePath
                errorSpan.Attributes.Remove("class")
                errorSpan.Attributes.Add("class", "alert alert-success")
                Panel1.Visible = True
            End If
        Catch ex As Exception
        End Try
        Return result
    End Function
    Protected Sub Update_student_details()
        Dim objStudent As New mb_st_details
        objStudent = Session("Student")
        If String.IsNullOrEmpty(txtFullName.Text) = False Then objStudent.stu_full_name = txtFullName.Text
        If String.IsNullOrEmpty(txt_Title.Text) = False Then objStudent.stu_title = txt_Title.Text
        If String.IsNullOrEmpty(txt_First_Name.Text) = False Then objStudent.stu_first_name = txt_First_Name.Text
        If String.IsNullOrEmpty(txt_Last_Name.Text) = False Then objStudent.stu_last_name = txt_Last_Name.Text
        If String.IsNullOrEmpty(txt_dob.Text) = False Then objStudent.stu_dob = txt_dob.Text
        If String.IsNullOrEmpty(txt_Passport_No.Text) = False Then objStudent.stu_passport_no = txt_Passport_No.Text
        If DDL_gender.SelectedIndex > 0 Then objStudent.stu_gender = DDL_gender.SelectedItem.ToString
        If String.IsNullOrEmpty(txtQualification.Text) = False Then objStudent.degree_name = txtQualification.Text
        If String.IsNullOrEmpty(Txt_Course.Text) = False Then objStudent.course_name = Txt_Course.Text
        If String.IsNullOrEmpty(txt_Institute.Text) = False Then objStudent.university_name = txt_Institute.Text

        If String.IsNullOrEmpty(txt_address_1.Text) = False Then objStudent.stu_address_1 = txt_address_1.Text
        If String.IsNullOrEmpty(txt_address_2.Text) = False Then objStudent.stu_address_2 = txt_address_2.Text
        If String.IsNullOrEmpty(txt_City.Text) = False Then objStudent.stu_city = txt_City.Text
        If String.IsNullOrEmpty(txt_county.Text) = False Then objStudent.stu_county = txt_county.Text
        If String.IsNullOrEmpty(txt_country.Text) = False Then objStudent.stu_country = txt_country.Text
        If String.IsNullOrEmpty(txt_postcode.Text) = False Then objStudent.stu_postcode = txt_postcode.Text
        If String.IsNullOrEmpty(txtVisaExpiryDate.Text) = False Then objStudent.st_visa_expiry_date = txtVisaExpiryDate.Text

        If String.IsNullOrEmpty(txt_email_address.Text) = False Then objStudent.stu_email_address = txt_email_address.Text
        If String.IsNullOrEmpty(txt_alt_email_address.Text) = False Then objStudent.stu_alt_email_address = txt_alt_email_address.Text

        If String.IsNullOrEmpty(txt_mobile.Text) = False Then objStudent.stu_mobile_1 = txt_mobile.Text
        If String.IsNullOrEmpty(txt_mobile1.Text) = False Then objStudent.stu_mobile_2 = txt_mobile1.Text
        objStudent.modified_by = Session("Login_name")
        objStudent.modified_date = Date.Now()
        Dim a = dbaccess.Update_Student_Full(objStudent)
        If a > 0 Then
            ErrorMessage.Text = "Updated "
            Panel1.Visible = True
            errorSpan.Attributes.Remove("class")
            errorSpan.Attributes.Add("class", "alert alert-success")
        End If

    End Sub

    Private Sub StudentForm_PreInit(sender As Object, e As EventArgs) Handles Me.PreInit
        Dim objLoginView As mb_st_log_sys_view = Session("LoginView")
        Dim role As New mb_st_roles
        role = dbaccess.Get_permissions_By_role_id(objLoginView.role_id)
        If role.permissions = 1 Or
            role.permissions = 2 Or
            role.permissions = 4 Then
            Me.MasterPageFile = "~/Master/SdDashBoardDefault.master"
        End If

    End Sub

    Protected Sub Admin_panels()
        Dim objLoginView As mb_st_log_sys_view = Session("LoginView")
        Dim role As New mb_st_roles
        role = dbaccess.Get_permissions_By_role_id(objLoginView.role_id)
        If role.permissions = 1 Or
            role.permissions = 2 Or
            role.permissions = 4 Then
            Calendar1.Visible = False
            btnRunEmail.Visible = False
            'Lk_family.Text = "Family [+]"
            extra.Visible = True
            LinkButton1.Visible = False
            If String.IsNullOrEmpty(ltr_supervisor.Text.ToString) Then
                ltr_supervisor_lbl.Text = "Not Assigned"
            End If
            Panel2.Visible = True
            LkEdit_super.Visible = True
            DropDownList2.Visible = True

        End If

    End Sub

    Protected Sub DropDownList2_DataBound(sender As Object, e As EventArgs) Handles DropDownList2.DataBound
        DropDownList2.Items.Insert(0, New ListItem("Select Supervisor", "0"))
    End Sub

    Protected Sub LkEdit_super_Click(sender As Object, e As EventArgs) Handles LkEdit_super.Click
        Panel4.Visible = True
    End Sub

    Protected Sub DropDownList2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DropDownList2.SelectedIndexChanged
        ' allocate supervisor to student
        If DropDownList2.SelectedIndex > 0 Then
            Dim objStudent As New mb_st_details
            objStudent = Session("Student")
            'Update
            Dim a = dbaccess.UpdateAllocatesupervisorStudent(DropDownList2.SelectedValue, objStudent.stu_id, Session("Login_name"))
            If a > 0 Then
                '  ErrorMessage.Text = "Supervisor allocated "
                Response.Redirect(Request.RawUrl)
            End If

        End If
    End Sub

    Private Sub Lk_family_Click(sender As Object, e As EventArgs) Handles Lk_family.Click
        PnlStudent.Visible = False
        Pnl_Family.Visible = True
        Pnl_family_form.Visible = False

    End Sub



#Region "familyAddition"
    Private Sub L_btn_family_save_Click(sender As Object, e As EventArgs) Handles L_btn_family_save.Click
        _Add()
    End Sub

    Private Sub _Add()
        If txt_email_address.Text.Length = 0 Then
            Panel1.Visible = True
            ErrorMessage.Text = "A valid email address has not been provided." + Environment.NewLine
            Exit Sub
        ElseIf Not txt_email_address.Text.Contains("@") Then
            Panel1.Visible = True
            ErrorMessage.Text = "Email address not valid" + Environment.NewLine
            Exit Sub
        End If
        'insert
        Dim _id As Integer = 0
        _id = _insert()
        If _id > 0 Then
            'show family button
            Pnl_family_form.Visible = False
            ddl_txt_relation.Enabled = True
            PnlGrid.Visible = True
            GridView2.DataBind()
            cleartext()
        Else


        End If

    End Sub

    Function _insert() As Integer
        Dim objStudent As New mb_st_details
        objStudent = Session("Student")

        Dim objFamily As New mb_st_family_details
        'Create User Record
        Dim user_id As Integer = 0
        objFamily.stu_id = objStudent.stu_id
        objFamily.family_relation_student = ddl_txt_relation.Text
        objFamily.stu_profile_no = TxtStudentFile.Text
        If Not String.IsNullOrWhiteSpace(txt_family_full_name_arabic.Text) Then objFamily.family_full_name_arabic = txt_family_full_name_arabic.Text
        If Not String.IsNullOrWhiteSpace(txt_family_title.Text) Then objFamily.family_title = txt_family_title.Text
        If Not String.IsNullOrWhiteSpace(txt_family_fname.Text) Then objFamily.family_first_name = txt_family_fname.Text
        If Not String.IsNullOrWhiteSpace(txt_family_lname.Text) Then objFamily.family_last_name = txt_family_lname.Text
        objFamily.family_full_name = txt_family_title.Text & " " & txt_family_fname.Text & " " & txt_family_lname.Text
        objFamily.family_full_name = dbaccess.CompressSpaces(objFamily.family_full_name)


        If Not String.IsNullOrWhiteSpace(txt_family_national_no.Text) Then objFamily.family_national_number = txt_family_national_no.Text
        If Not String.IsNullOrWhiteSpace(txt_family_passport_no.Text) Then objFamily.family_passport_number = txt_family_passport_no.Text
        If Not String.IsNullOrWhiteSpace(txt_family_email.Text) Then objFamily.family_email_address = txt_family_email.Text
        If Not String.IsNullOrWhiteSpace(txt_family_dob.Text) Then objFamily.family_dob = txt_family_dob.Text
        If ddl_family_gender.SelectedIndex > 0 Then objFamily.family_gender = ddl_family_gender.SelectedValue
        If Not String.IsNullOrWhiteSpace(txt_family_degree_name.Text) Then objFamily.family_degree_name = txt_family_degree_name.Text
        If Not String.IsNullOrWhiteSpace(txt_family_course_name.Text) Then objFamily.family_course_name = txt_family_course_name.Text
        If Not String.IsNullOrWhiteSpace(txt_family_college_uni_name.Text) Then objFamily.family_college_uni_name = txt_family_college_uni_name.Text
        If Not String.IsNullOrWhiteSpace(txt_family_visa_expiry_date.Text) Then objFamily.visa_expiry_date = txt_family_visa_expiry_date.Text
        If Not String.IsNullOrWhiteSpace(txt_family_mobile1.Text) Then objFamily.family_mobile_1 = txt_family_mobile1.Text
        If Not String.IsNullOrWhiteSpace(txt_family_mobile2.Text) Then objFamily.family_mobile_2 = txt_family_mobile2.Text
        objFamily.created_by = Session("Login_name") 'Session("loginUser")
        Try
            user_id = dbaccess.Insert_family_Sh_Student(objFamily, Session("Login_name"))
            If user_id > 0 Then
                Panel1.Visible = True
                ErrorMessage.Text = "Record Saved successfully"
                errorSpan.Attributes.Remove("class")
                errorSpan.Attributes.Add("class", "alert alert-success")
            Else
                Panel1.Visible = True
                ErrorMessage.Text = "Record Not Saved successfully"
                errorSpan.Attributes.Remove("class")
                errorSpan.Attributes.Add("class", "alert alert-danger")
            End If
        Catch ex As Exception
            Dim newError As New logs(ex, "createStudnet")
            newError.Log()
            Debug.Print(ex.Message)
        End Try
        Return user_id
    End Function

    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If ddl_txt_relation.SelectedIndex > 0 Then
            Label1.Visible = False
            Pnl_family_form.Visible = True
            ddl_txt_relation.Enabled = False
            PnlGrid.Visible = False
            L_btn_family_save.Visible = True
            L_btn_family_update.Visible = False
        Else
            ddl_txt_relation.Focus()
            Label1.Visible = True
        End If

    End Sub

    Protected Sub cleartext()
        ddl_txt_relation.SelectedIndex = 0
        txt_family_full_name_arabic.Text = ""
        txt_family_fullname.Text = ""
        txt_family_title.Text = ""
        txt_family_fname.Text = ""
        txt_family_lname.Text = ""
        txt_family_dob.Text = ""
        ddl_family_gender.SelectedIndex = 0
        txt_family_national_no.Text = ""
        txt_family_passport_no.Text = ""
        txt_family_degree_name.Text = ""
        txt_family_course_name.Text = ""
        txt_family_college_uni_name.Text = ""
        txt_family_visa_expiry_date.Text = ""
        txt_family_email.Text = ""
        txt_family_mobile1.Text = ""
        txt_family_mobile2.Text = ""

    End Sub


    Protected Sub formbind(ByVal userID As Integer)
        Try
            Dim dt As DataTable = dbaccess.Get_family_info_By_ID(userID)
            '   FormView1.DataSource = dt
            '   FormView1.DataBind()
            '  TabPanel1.HeaderText = dt.Rows(0)("family_relation_student").ToString

            txt_family_full_name_arabic.Text = dt.Rows(0)("family_full_name_arabic").ToString
            txt_family_title.Text = dt.Rows(0)("family_title").ToString
            txt_family_fname.Text = dt.Rows(0)("family_first_name").ToString
            txt_family_lname.Text = dt.Rows(0)("family_last_name").ToString
            txt_family_fullname.Text = dt.Rows(0)("family_full_name").ToString
            txt_family_national_no.Text = dt.Rows(0)("family_national_number").ToString
            txt_family_passport_no.Text = dt.Rows(0)("family_passport_number").ToString
            txt_family_email.Text = dt.Rows(0)("family_email_address").ToString
            txt_family_dob.Text = dt.Rows(0)("family_dob").ToString
            ddl_family_gender.SelectedValue = dt.Rows(0)("family_gender").ToString
            txt_family_degree_name.Text = dt.Rows(0)("family_degree_name").ToString
            txt_family_course_name.Text = dt.Rows(0)("family_course_name").ToString
            txt_family_college_uni_name.Text = dt.Rows(0)("family_college_uni_name").ToString
            txt_family_visa_expiry_date.Text = dt.Rows(0)("visa_expiry_date").ToString
            txt_family_mobile1.Text = dt.Rows(0)("family_mobile_1").ToString
            txt_family_mobile2.Text = dt.Rows(0)("family_mobile_2").ToString

            If String.IsNullOrEmpty(txt_family_dob.Text) = False Then txt_family_dob.Text = txt_family_dob.Text.Replace("00:00:00", "")
            If String.IsNullOrEmpty(txt_family_visa_expiry_date.Text) = False Then txt_family_visa_expiry_date.Text = txt_family_visa_expiry_date.Text.Replace("00:00:00", "")


        Catch ex As Exception
            Dim newError As New logs(ex, "")
            newError.Log()
            Debug.Print(ex.Message)
        Finally
        End Try
    End Sub
    Protected Sub GridView2_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView2.RowCommand
        Dim gvr As GridViewRow = CType(CType(e.CommandSource, LinkButton).NamingContainer, GridViewRow)
        Dim id As Integer
        id = CType(GridView2.DataKeys(gvr.RowIndex).Value, Integer)

        If e.CommandName = "Select" Then
            Dim i As Integer = Convert.ToInt32(id)
            formbind(i)
            'Pnl_Family_Tabs.Visible = False
            Pnl_family_form.Visible = True
            L_btn_family_save.Visible = False
            L_btn_family_update.Visible = True
            Pnl_Family.Visible = False
            Pnl_family_form.Visible = True
        End If
    End Sub
    Private Sub L_btn_letters_arabic_Click(sender As Object, e As EventArgs) Handles L_btn_letters_arabic.Click
        Response.Redirect("~/sys-user/LettersDefaultPage.aspx", False)
    End Sub

    'Private Sub btn_docs_Click(sender As Object, e As EventArgs) Handles btn_docs.Click
    '    Response.Redirect("~/Student_Files/Stu_documents.aspx", False)
    'End Sub

    Function _update() As Integer
        Dim objStudent As New mb_st_details
        objStudent = Session("Student")

        Dim objFamily As New mb_st_family_details
        'Create User Record
        Dim user_id As Integer = 0
        objFamily.stu_id = objStudent.stu_id
        objFamily.stu_profile_no = objStudent.profile_no
        objFamily.family_relation_student = ddl_txt_relation.Text
        objFamily.stu_profile_no = TxtStudentFile.Text
        If Not String.IsNullOrWhiteSpace(txt_family_full_name_arabic.Text) Then objFamily.family_full_name_arabic = txt_family_full_name_arabic.Text
        If Not String.IsNullOrWhiteSpace(txt_family_title.Text) Then objFamily.family_title = txt_family_title.Text
        If Not String.IsNullOrWhiteSpace(txt_family_fname.Text) Then objFamily.family_first_name = txt_family_fname.Text
        If Not String.IsNullOrWhiteSpace(txt_family_lname.Text) Then objFamily.family_last_name = txt_family_lname.Text
        objFamily.family_full_name = txt_family_title.Text & " " & txt_family_fname.Text & " " & txt_family_lname.Text
        objFamily.family_full_name = dbaccess.CompressSpaces(objFamily.family_full_name)


        If Not String.IsNullOrWhiteSpace(txt_family_national_no.Text) Then objFamily.family_national_number = txt_family_national_no.Text
        If Not String.IsNullOrWhiteSpace(txt_family_passport_no.Text) Then objFamily.family_passport_number = txt_family_passport_no.Text
        If Not String.IsNullOrWhiteSpace(txt_family_email.Text) Then objFamily.family_email_address = txt_family_email.Text
        If Not String.IsNullOrWhiteSpace(txt_family_dob.Text) Then objFamily.family_dob = txt_family_dob.Text
        If ddl_family_gender.SelectedIndex > 0 Then objFamily.family_gender = ddl_family_gender.SelectedValue
        'If objFamily.family_full_address IsNot Nothing Then objFamily.family_full_address = txt_family_postcode.Text
        If Not String.IsNullOrWhiteSpace(txt_family_degree_name.Text) Then objFamily.family_degree_name = txt_family_degree_name.Text
        If Not String.IsNullOrWhiteSpace(txt_family_course_name.Text) Then objFamily.family_course_name = txt_family_course_name.Text
        If Not String.IsNullOrWhiteSpace(txt_family_college_uni_name.Text) Then objFamily.family_college_uni_name = txt_family_college_uni_name.Text
        If Not String.IsNullOrWhiteSpace(txt_family_visa_expiry_date.Text) Then objFamily.visa_expiry_date = txt_family_visa_expiry_date.Text
        If Not String.IsNullOrWhiteSpace(txt_family_mobile1.Text) Then objFamily.family_mobile_1 = txt_family_mobile1.Text
        If Not String.IsNullOrWhiteSpace(txt_family_mobile2.Text) Then objFamily.family_mobile_2 = txt_family_mobile2.Text


        objFamily.created_by = Session("loginUser")
        Try
            user_id = dbaccess.Update_family_Sh_Student(objFamily, Session("loginUser"))
            Panel1.Visible = True
            ErrorMessage.Text = "Record Saved successfully"
            errorSpan.Attributes.Remove("class")
            errorSpan.Attributes.Add("class", "alert alert-success")
        Catch ex As Exception
            Dim newError As New logs(ex, "createStudent")
            newError.Log()
            Debug.Print(ex.Message)
        End Try
        Return user_id
    End Function

    Private Sub L_btn_family_update_Click(sender As Object, e As EventArgs) Handles L_btn_family_update.Click
        _update()
    End Sub

    Private Sub L_btn_letters_eng_Click(sender As Object, e As EventArgs) Handles L_btn_letters_eng.Click
        Response.Redirect("~/sys-user/LetterDefaultEngPage.aspx", False)
    End Sub

    Private Sub L_btn_letters_spon_Click(sender As Object, e As EventArgs) Handles L_btn_letters_spon.Click
        Response.Redirect("~/sys-user/LetterDefaultSponPage.aspx", False)
    End Sub

    Private Sub btn_close_Click(sender As Object, e As EventArgs) Handles btn_close.Click
        PnlStudent.Visible = True
        Pnl_Family.Visible = False
        Pnl_family_form.Visible = False

    End Sub

    Private Sub LinkButton8_Click(sender As Object, e As EventArgs) Handles LinkButton8.Click
        Response.Redirect(Request.RawUrl)
    End Sub

    Protected Sub student_controls()
        LkEdit_super.Visible = False
        TxtStudentFile.Enabled = False
        txt_Title.Enabled = False
        txt_First_Name.Enabled = False
        txt_Last_Name.Enabled = False
        txt_dob.Enabled = False
        txt_Passport_No.Enabled = False
        txt_nat_number.Enabled = False
        DDL_gender.Enabled = False
        DropDownList2.Visible = False
    End Sub

    Protected Sub Role_defined_controls()
        Dim objLoginView As New mb_st_log_sys_view
        objLoginView = Session("LoginView")
        Dim role As String = ""
        Dim entityUser = dbaccess.Get_Role_ID_By_ID(objLoginView.entity_user_id)
        role = entityUser.role_id
        'role_id=1=Student
        'role_id=2=Supervisor
        'role_id=3=Admin
        'role_id=4=Super-admin
        Select Case role
            Case 1
                'student screen
                student_controls()
            Case 2
                'supervisor screen
                LinkButton1.Visible = False
            Case 3 Or 4
                'admin or supervisor screen
                LinkButton1.Visible = False
            Case Else

        End Select

    End Sub
#End Region

End Class