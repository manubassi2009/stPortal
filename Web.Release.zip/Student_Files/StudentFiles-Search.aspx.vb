﻿Public Class StudentFiles_Search
    Inherits System.Web.UI.Page

    Dim dbaccess As New dbutil
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Session("Logged_In") Then
            'Kill Session
            Session.Abandon()
            Response.Cookies.Add(New HttpCookie("ASP.NET_SessionId", ""))
            Response.Redirect("~/Default", False)
            Exit Sub
        Else
            Session.Timeout = 30
            If Not Me.IsPostBack Then
                'Dim objLogin As New mb_st_log_sys_view=Session("LoginView")
                Dim objLoginView = Session("LoginView")
                Dim op As String = Request.QueryString("type")
                If op = "find" Then
                    op = Session("type")
                    Response.Redirect("~/Student_Files/StudentFiles-Search?type=" & op & "", False)
                End If

                If op Is Nothing Then
                    GatherInformation()
                    'If op = 2 Then
                    '    SearchAnything1.ServiceMethod = "SearchStudentFiltered"
                    '    'SearchAnything1.ServicePath = "../webservices/search.asmx"
                    'Else
                    '    SearchAnything1.ServiceMethod = "SearchStudent"
                    '    'SearchAnything1.ServicePath = "../webservices/search.asmx"
                    'End If
                End If

            End If
        End If

    End Sub



    Protected Sub GridView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridView1.SelectedIndexChanged
        Dim row As GridViewRow = GridView1.SelectedRow
        Dim _id As New Label
        _id.Text = row.Cells(1).Text
        Dim i As Integer = Convert.ToInt32(_id.Text)
        Dim _list As New Request_form_queue
        _list = dbaccess.Get_Req_Queue_By_ID(i)
        Try
            Dim objStudentGetName = dbaccess.Get_Student_by_profile_no(i)
            Session("Student") = objStudentGetName
            Response.Redirect("~/Student_Files/StudentForm.aspx", False)
        Catch ex As Exception

        End Try
        ScriptManager.RegisterStartupScript(Me, Me.GetType, "Pop", "openModal();", True)
    End Sub

    Protected Sub hdnValueUser_ValueChanged(sender As Object, e As EventArgs)
        Dim val = hdnValueUser.Value
        Try
            If String.IsNullOrWhiteSpace(val) = False Then
                val = val.Replace("ID ", "")
                Dim temparr = val.Split(":")
                If temparr.Length >= 1 Then
                    Dim _id = temparr(0)
                    Try
                        Dim objStudentGetName = dbaccess.Get_Student_by_profile_no(_id)
                        Session("Student") = objStudentGetName
                        Response.Redirect("~/Student_Files/StudentForm.aspx", False)
                    Catch ex As Exception

                    End Try
                End If
            End If
        Catch ex As Exception
            '   Dim newError As New sbc_errors(ex, "")
            '  newError.Log()
            Dim ee = ex.Message.ToString
        End Try
    End Sub


    Private Sub GatherInformation()
        Dim type As Integer = 0
        If String.IsNullOrWhiteSpace(Session("type")) = False Then type = Session("type")
        Dim objLogin As New mb_st_log_sys_view
        objLogin = Session("objLogin")
        'get userid from entity
        Dim objUser As New mb_st_user
        objUser = dbaccess.Get_User_ID_By_Entity_ID(objLogin.entity_user_id)
        Dim _DT As New DataTable
        Try
            Select Case type
                Case "2" 'supervisor
                    _DT = dbaccess.Bind_Student_List(objUser.user_id)
                    GridView1.DataSource = _DT
                    GridView1.DataBind()

                Case "3" 'admin
                    _DT = dbaccess.Bind_Student_List(0)
                    GridView1.DataSource = _DT
                    GridView1.DataBind()

                Case "4" 'super-admin
                    _DT = dbaccess.Bind_Student_List(0)
                    GridView1.DataSource = _DT
                    GridView1.DataBind()
            End Select
        Catch ex As Exception
            Dim newError As New logs(ex, "GetProjectInformation_Search()")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

    End Sub

End Class