﻿Public Class Student_Reset_Password
    Inherits System.Web.UI.Page

    Dim dbaccess As New dbutil
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Session("objLogin") = objLogin
        If Not Session("Logged_In") Then
            'Kill Session
            Session.Abandon()
            Response.Cookies.Add(New HttpCookie("ASP.NET_SessionId", ""))
            Response.Redirect("~/Default", False)
            Exit Sub
        Else
            Session.Timeout = 30
            If Not Me.IsPostBack Then

            End If
        End If

    End Sub

#Region "Reset"
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim objLogin As New mb_st_log_sys_view
        objLogin = Session("objLogin")

        Dim CiperCode As String = dbaccess.Get_Ciper_code_by_login_id(objLogin.login_id)
        ' Dim GUIDid = dbaccess.Get_FORGOT_GUID_PASSWORD(Request.QueryString("reset"))
        Dim hash_pass As String = dbaccess.MD5_Hash(dbaccess.MD5_Hash(ConfirmPassword.Text) & objLogin.saltkey)

        Dim a = dbaccess.Update_password_reset(objLogin.login_id, hash_pass) 'LCase(ConfirmPassword.Text))
        If a > 0 Then
            '   Response.Redirect("~/Default.aspx", False)
            ErrorMessage.Text = "Password updated"
            Panel3.Visible = True
        Else


        End If
    End Sub
#End Region

End Class