﻿Imports System
Imports System.Linq
Imports System.Web
Imports Microsoft.AspNet.Identity
Imports Microsoft.AspNet.Identity.EntityFramework
Imports Microsoft.AspNet.Identity.Owin
Imports Owin

Partial Public Class ResetPassword
    Inherits System.Web.UI.Page

    Dim dbaccess As New dbutil
    Protected Property StatusMessage() As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not String.IsNullOrEmpty(Request.QueryString("reset").ToString) Then
            Dim GUIDid = dbaccess.Get_FORGOT_GUID_PASSWORD(Request.QueryString("reset"))
            If GUIDid Then
                Try
                    If Not String.IsNullOrEmpty(Request.QueryString("reset").ToString) Then
                        'show the password div

                    Else
                        Response.Redirect("~/Default.aspx", False)
                    End If
                Catch ex As Exception
                    Dim newError As New logs(ex, "")
                    newError.Log()
                    Response.Redirect("~/Default.aspx", False)
                End Try
            Else
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "Javascript", "<script>alert('INVALID LOGIN.')</script>")
            End If

        Else
            Response.Redirect("~/Default.aspx", False)
        End If
    End Sub
End Class