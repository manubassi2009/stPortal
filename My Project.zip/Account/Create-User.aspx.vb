﻿Imports System.Data.SqlClient

Public Class Create_User
    Inherits System.Web.UI.Page
    Dim dbaccess As New dbutil


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Session("Logged_In") Then
            '            Kill Session
            Session.Abandon()
            Response.Cookies.Add(New HttpCookie("ASP.NET_SessionId", ""))
            Response.Redirect("~/Default", False)
            Exit Sub
        ElseIf Session("Logged_In") Then
            If Session("Message") IsNot Nothing Then
                ClientScript.RegisterStartupScript(Me.GetType(), "Saved", "alertify.success('" & Session("Message") & "');", True)
                Session("Message") = Nothing
            End If
            If Not Me.IsPostBack Then
                divError.Attributes.Remove("class")
                'divError.Attributes.Add("class", "alert alert-danger")
                ErrorMessage.Text = ""
                '  bind_list()
                Dim op As String = Request.QueryString("type")
                If op = "admin" Then
                    DropDownList1.SelectedIndex = 3

                ElseIf op = "supervisor" Then
                    DropDownList1.SelectedIndex = 2

                End If

                Dim op2 As String = Request.QueryString("token")
                If op2 = "2" Then
                    LkUpdate.Visible = True
                    LkSave.Visible = False
                    Dim userID As String = Request.QueryString("element")
                    formbind(userID)
                    Dim op3 As String = Request.QueryString("user")
                    Literal1.Text = op3.ToUpper
                    DropDownList1.Visible = False
                Else
                    LkUpdate.Visible = False
                    LkSave.Visible = True
                    Panel1.Visible = True
                    Panel2.Visible = False
                End If

            End If
        Else

            If Session("Message") IsNot Nothing Then
                Session("Message") = Nothing
            End If
        End If

    End Sub


    'Protected Sub bind_list()
    '    Dim dt As New DataTable()
    '    dt = dbaccess.Get_roles_datatable_users
    '    If dt.Rows.Count > 0 Then
    '        DropDownList1.DataSource = dt
    '        DropDownList1.DataBind()
    '    End If
    'End Sub
    Private Sub DropDownList1_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles DropDownList1.DataBound
        DropDownList1.Items.Insert(0, New ListItem("Please Select", "0"))
    End Sub

    Protected Sub LkSave_Click(sender As Object, e As EventArgs) Handles LkSave.Click
        If DropDownList1.SelectedIndex > 0 Then
            CreateUserAccount()

        Else
            Panel3.Visible = True
            divError.Attributes.Remove("class")
            divError.Attributes.Add("class", "alert alert-danger")
            ErrorMessage.Text = "Select user type"
            Exit Sub
        End If



    End Sub


    Private Sub CreateUserAccount()
        Dim Count As Integer = 0
        Dim email As String = txt_email_address.Text.Trim
        Dim objEntity As New entity_users
        'objUser = dbaccess.Get_UserInfo_Byemail(email)
        Dim confirmUserEmailExit = dbaccess.Confirm_User_Exit_Byemail(email)
        If confirmUserEmailExit = True Then
            Panel3.Visible = True
            divError.Attributes.Remove("class")
            divError.Attributes.Add("class", "alert alert-danger")
            ErrorMessage.Text = "User name already exists"
            Exit Sub
        Else
        End If
        'Check email address
        If txt_email_address.Text.Length = 0 Then
            Panel3.Visible = True
            divError.Attributes.Remove("class")
            divError.Attributes.Add("class", "alert alert-danger")
            ErrorMessage.Text = "A valid email address has not been provided " + Environment.NewLine
            Exit Sub
        ElseIf Not txt_email_address.Text.Contains("@") Then
            Panel3.Visible = True
            divError.Attributes.Remove("class")
            divError.Attributes.Add("class", "alert alert-danger")
            ErrorMessage.Text = "Email address not valid" + Environment.NewLine
            Exit Sub
        End If


        'insert user
        Dim user_id As Integer = 0
        user_id = insert_User()
        If user_id > 0 Then
            ''       >     ' need to get the entity user id 
            objEntity = dbaccess.Get_Entity_ID_By_User_ID(user_id)

            ''      >      'entity user id to be saved in the the ciper and login page

            'Hash and Salt Passwords, store in the login table
            Dim CiperCode As String = dbaccess.GenerateSalt()
            Dim hash_pass As String = dbaccess.MD5_Hash(dbaccess.MD5_Hash(txt_password.Text) & CiperCode)
            Dim hash_pass_verified As String = dbaccess.MD5_Hash(dbaccess.MD5_Hash(txt_password.Text) & CiperCode)
            'To do change the line above
            If hash_pass = hash_pass_verified Then
                'Create Salt for User
                Dim salt_id As Integer = Create_User_Ciper(objEntity.entity_user_id, CiperCode)
                If salt_id > 0 Then
                    'Create Login Record
                    ' get the entity user id
                    Dim login_id As Integer = Insert_Login(objEntity.entity_user_id, txt_email_address.Text, hash_pass)
                    If login_id > 0 Then
                        'UI alert to notify successfull account creation
                        'Session("Message") = "User account created successfully."
                        divError.Attributes.Remove("class")
                        divError.Attributes.Add("class", "alert alert-danger")
                        ErrorMessage.Text = "User account created successfully."
                        ClientScript.RegisterClientScriptBlock(Me.GetType(), "Javascript", "<script>alert('Saved....')</script>")
                        Exit Sub

                    End If
                End If
            Else
                Exit Sub

            End If

        End If

    End Sub
    Function insert_User() As Integer
        Dim objUser As New mb_st_user
        'Create User Record
        Dim user_id As Integer = 0
        objUser.role_id = DropDownList1.SelectedValue
        If Not String.IsNullOrWhiteSpace(txt_Title.Text) Then objUser.title = txt_Title.Text
        If Not String.IsNullOrWhiteSpace(txt_First_Name.Text) Then objUser.first_name = txt_First_Name.Text
        If Not String.IsNullOrWhiteSpace(txt_Middle_Name.Text) Then objUser.middle_name = txt_Middle_Name.Text
        If Not String.IsNullOrWhiteSpace(txt_Last_Name.Text) Then objUser.last_name = txt_Last_Name.Text
        objUser.full_name = txt_Title.Text & " " & txt_First_Name.Text & " " & txt_Middle_Name.Text & " " & txt_Last_Name.Text
        objUser.full_name = dbaccess.CompressSpaces(objUser.full_name)
        If Not String.IsNullOrWhiteSpace(txt_dob.Text) Then objUser.dob = txt_dob.Text
        If DDL_gender.SelectedIndex > 0 Then objUser.gender = DDL_gender.SelectedItem.Text
        If Not String.IsNullOrWhiteSpace(txt_email_address.Text) Then objUser.email_address = txt_email_address.Text
        If Not String.IsNullOrWhiteSpace(txt_address_1.Text) Then objUser.address_1 = txt_address_1.Text
        If Not String.IsNullOrWhiteSpace(txt_address_2.Text) Then objUser.address_2 = txt_address_2.Text
        If Not String.IsNullOrWhiteSpace(txt_City.Text) Then objUser.city = txt_City.Text
        If Not String.IsNullOrWhiteSpace(txt_county.Text) Then objUser.county = txt_county.Text
        If Not String.IsNullOrWhiteSpace(txt_country.Text) Then objUser.country = txt_county.Text
        If Not String.IsNullOrWhiteSpace(txt_postcode.Text) Then objUser.postcode = txt_postcode.Text
        objUser.full_address = txt_address_1.Text & " " & txt_address_2.Text & " " & txt_City.Text & " " & txt_county.Text & " " & txt_postcode.Text & " " & txt_county.Text & " "
        objUser.full_address = dbaccess.CompressSpaces(objUser.full_address)
        If Not String.IsNullOrWhiteSpace(txt_mobile.Text) Then objUser.mobile_1 = txt_mobile.Text
        If Not String.IsNullOrWhiteSpace(txt_mobile1.Text) Then objUser.mobile_2 = txt_mobile1.Text
        'If CheckBox1.Checked = True Then
        '    objUser.mobile_1_primary = True
        'Else
        '    objUser.mobile_1_primary = False
        'End If
        'If CheckBox2.Checked = True Then
        '    objUser.mobile_2_primary = True
        'Else
        '    objUser.mobile_2_primary = False
        'End If
        objUser.created_by = Session("Login_name") '  "System" ' Session("loginUser")
        Try
            user_id = dbaccess.InsertUser(objUser, Session("Login_name")) 'Session("loginUser"))
            If user_id > 0 Then
                ErrorMessage.Text = "Record Saved successfully"
            Else
                ErrorMessage.Text = "Record Not Saved successfully"
            End If
        Catch ex As Exception
            Dim newError As New logs(ex, Session("Login_name"))
            newError.Log()
            Debug.Print(ex.Message)
        End Try
        Return user_id
    End Function

    Function Create_User_Ciper(ByVal userid As Integer, ByVal code As String) As Integer
        Dim objciper As New mb_st_ciper
        'Create User Record
        Dim resultID As Integer = 0
        If Not String.IsNullOrWhiteSpace(userid) Then objciper.entity_user_id = userid
        If Not String.IsNullOrWhiteSpace(code) Then objciper.saltkey = code
        objciper.created_by = "Demo-system" 'Session("UserName")
        Try
            resultID = dbaccess.InsertCiper(objciper, "Demo-system")
            If resultID > 0 Then
                ErrorMessage.Text = "Record Saved successfully"
            Else
                ErrorMessage.Text = "Record Not Saved successfully"
            End If


        Catch ex As Exception
            Dim newError As New logs(ex, "createuser")
            newError.Log()
            Debug.Print(ex.Message)
        End Try
        Return resultID
    End Function

    Function Insert_Login(ByVal userid As Integer, ByVal username As String, ByVal password As String) As Integer
        Dim objlogin As New mb_st_log
        'Create User Record
        Dim resultID As Integer = 0
        If Not String.IsNullOrWhiteSpace(userid) Then objlogin.entity_user_id = userid
        If Not String.IsNullOrWhiteSpace(username) Then objlogin.username = LCase(username)
        If Not String.IsNullOrWhiteSpace(password) Then objlogin.password = password
        objlogin.created_by = "Demo-system" 'Session("UserName")
        Try
            resultID = dbaccess.Insert_mb_st_log(objlogin, "Demo-system")
            If resultID > 0 Then
                ErrorMessage.Text = "Record Saved successfully"
            Else
                ErrorMessage.Text = "Record Not Saved successfully"
            End If
        Catch ex As Exception
            Dim newError As New logs(ex, "createlogin")
            newError.Log()
            Debug.Print(ex.Message)
        End Try
        Return resultID
    End Function

    Protected Sub formbind(ByVal userID As Integer)
        Try
            Dim objUser As New mb_st_user
            objUser = dbaccess.Get_UserInfo_ByID(userID)

            txt_Title.Text = objUser.title
            txt_First_Name.Text = objUser.first_name
            txt_Middle_Name.Text = objUser.middle_name
            txt_Last_Name.Text = objUser.last_name
            If objUser.dob > Date.MinValue Then txt_dob.Text = objUser.dob
            DDL_gender.SelectedValue = objUser.gender

            txt_mobile.Text = objUser.mobile_1
            txt_mobile1.Text = objUser.mobile_2
            txt_address_1.Text = objUser.address_1
            txt_address_2.Text = objUser.address_2
            txt_City.Text = objUser.city
            txt_county.Text = objUser.county
            txt_country.Text = objUser.country
            txt_postcode.Text = objUser.postcode
            If objUser.active = 1 Then
                CheckBox1.Checked = False
                Panel2.Visible = True
                Panel5.Visible = True
                CheckBox1.Enabled = True
            Else
                CheckBox1.Checked = True
                CheckBox1.Enabled = False
                Panel2.Visible = True
                Panel5.Visible = True
            End If


            Panel1.Visible = False
            Panel2.Visible = True

        Catch ex As Exception
            Dim newError As New logs(ex, "")
            newError.Log()
            Debug.Print(ex.Message)
        Finally
        End Try
    End Sub

    Protected Sub _update()
        Dim objUser As New mb_st_user
        'Create User Record
        Dim userID As Integer = Request.QueryString("element")
        objUser.user_id = userID

        If Not String.IsNullOrWhiteSpace(txt_Title.Text) Then objUser.title = txt_Title.Text
        If Not String.IsNullOrWhiteSpace(txt_First_Name.Text) Then objUser.first_name = txt_First_Name.Text
        If Not String.IsNullOrWhiteSpace(txt_Middle_Name.Text) Then objUser.middle_name = txt_Middle_Name.Text
        If Not String.IsNullOrWhiteSpace(txt_Last_Name.Text) Then objUser.last_name = txt_Last_Name.Text
        objUser.full_name = txt_Title.Text & " " & txt_First_Name.Text & " " & txt_Middle_Name.Text & " " & txt_Last_Name.Text
        objUser.full_name = dbaccess.CompressSpaces(objUser.full_name)

        If Not String.IsNullOrWhiteSpace(txt_address_1.Text) Then objUser.address_1 = txt_address_1.Text
        If Not String.IsNullOrWhiteSpace(txt_address_2.Text) Then objUser.address_2 = txt_address_2.Text
        If Not String.IsNullOrWhiteSpace(txt_City.Text) Then objUser.city = txt_City.Text
        If Not String.IsNullOrWhiteSpace(txt_county.Text) Then objUser.county = txt_county.Text
        If Not String.IsNullOrWhiteSpace(txt_country.Text) Then objUser.county = txt_country.Text

        If Not String.IsNullOrWhiteSpace(txt_dob.Text) Then objUser.dob = txt_dob.Text
        If DDL_gender.SelectedIndex > 0 Then objUser.gender = DDL_gender.SelectedValue

        If Not String.IsNullOrWhiteSpace(txt_mobile.Text) Then objUser.mobile_1 = txt_mobile.Text
        If Not String.IsNullOrWhiteSpace(txt_mobile1.Text) Then objUser.mobile_2 = txt_mobile1.Text
        If CheckBox1.Checked = True Then
            objUser.active = 0
        Else
            objUser.active = 1
        End If

        objUser.modified_by = Session("Login_name") 'Session("loginUser")
        objUser.modified_date = Date.Now
        Try
            Dim update = dbaccess.Update_User(objUser)
            ErrorMessage.Text = "Record updated"

            If CheckBox1.Checked = True Then
                ' make active 0 -> entity_users  -> entity_user_id
                ' get entity_user_id 
                Dim _objentity As New entity_users
                _objentity = dbaccess.Get_Entity_ID_By_User_ID(objUser.user_id)
                ' make active 0 -> mb_st_log --> login_id
                ' get login id 
                Dim _objlogin As New mb_st_log
                _objlogin = dbaccess.Get_login_id_By_Entity_ID(_objentity.entity_user_id)
                ' make active 0 -> mb_st_user id-> user_id
                'sat start from here 
                'To Do: make login active=1 and entityuser active =0  as well
                ' write the update method to make all three active 0 
                Dim deactive = dbaccess.make_user_deactive(_objlogin.login_id, _objentity.entity_user_id, objUser.user_id, objUser.active)
            End If
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "Javascript", "<script>alert('updated.')</script>")
            Panel1.Visible = True
            ErrorMessage.Text = "Record Saved successfully"
            divError.Attributes.Remove("class")
            divError.Attributes.Add("class", "alert alert-danger")
        Catch ex As Exception
            Dim newError As New logs(ex, "createStudent")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

    End Sub

    Private Sub LkUpdate_Click(sender As Object, e As EventArgs) Handles LkUpdate.Click
        _update()

    End Sub

    Protected Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked = True Then
            _update2()
        End If


    End Sub

    Protected Sub _update2()
        Dim objUser As New mb_st_user
        'Create User Record
        Dim userID As Integer = Request.QueryString("element")
        objUser.user_id = userID
        Try

            If CheckBox2.Checked = True Then
                ' make active 0 -> entity_users  -> entity_user_id
                ' get entity_user_id 
                Dim _objentity As New entity_users
                _objentity = dbaccess.Get_Entity_ID_By_User_ID_0(objUser.user_id)
                ' make active 0 -> mb_st_log --> login_id
                ' get login id 
                Dim _objlogin As New mb_st_log
                _objlogin = dbaccess.Get_login_id_By_Entity_ID_0(_objentity.entity_user_id)
                ' make active 0 -> mb_st_user id-> user_id
                'sat start from here 
                'To Do: make login active=1 and entityuser active =0  as well
                ' write the update method to make all three active 0 
                Dim deactive = dbaccess.make_user_deactive(_objlogin.login_id, _objentity.entity_user_id, objUser.user_id, 1)
            End If
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "Javascript", "<script>alert('updated.')</script>")
            Panel1.Visible = True
            ErrorMessage.Text = "Record Saved successfully"
            divError.Attributes.Remove("class")
            divError.Attributes.Add("class", "alert alert-danger")
        Catch ex As Exception
            Dim newError As New logs(ex, "createStudent")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

    End Sub


    Private Sub Create_User_LoadComplete(sender As Object, e As EventArgs) Handles Me.LoadComplete
        Dim op As String = Request.QueryString("type")
        If op = "admin" Then
            DropDownList1.DataSource = SqlDataSource2
            DropDownList1.DataBind()
            DropDownList1.SelectedIndex = 3
            DropDownList1.Enabled = False
            DropDownList1.Attributes.Add("class", "form-control is-invalid")
        ElseIf op = "supervisor" Then
            DropDownList1.DataSource = SqlDataSource2
            DropDownList1.DataBind()
            DropDownList1.SelectedIndex = 2
            DropDownList1.Enabled = False
            DropDownList1.Attributes.Add("class", "form-control is-invalid")
        End If
    End Sub
End Class