﻿Public Class sdStudentDBMaster
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'mb_st_log_sys_view
        'Session("LoginView") = objLogin
        If Not Session("Logged_In") Then
            'Kill Session
            Session.Abandon()
            Response.Cookies.Add(New HttpCookie("ASP.NET_SessionId", ""))
            Response.Redirect("~/Default", False)
            Exit Sub
        Else
            Session.Timeout = 30
            lbl_login_name.Text = Session("Login_name")
            lblname.Text = Session("Login_name")
            Session("loginUser") = Session("Login_name")
            lblinitial.Text = Session("avatar")
        End If

        'AppSettings()
        'UI_Permissions()

    End Sub

    Protected Sub lklogout_Click(sender As Object, e As EventArgs) Handles lklogout.Click
        Session.Clear()
        'clear session
        Session.Abandon()
        'Abandon session
        Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1))
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetNoStore()
        Response.Redirect("~/Default.aspx", False)
    End Sub
End Class