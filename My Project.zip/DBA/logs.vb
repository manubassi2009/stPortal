﻿Imports System.Reflection
Imports System.Web

Public Class logs
    Public Property id As Integer
    Public Property message As String
    Public Property stack_trace As String
    Public Property inner_exception As String
    Public Property date_by As DateTime
    Public Property by_user As String
    Public Property location As String
    Public Property resolved As Boolean
    Public Property date_resolved As DateTime
    Public Property active As Boolean

    Public Sub New(exc As Exception, location As String)
        Try
            active = True
            message = If(String.IsNullOrEmpty(exc.Message), "", exc.Message)
            stack_trace = If(String.IsNullOrEmpty(exc.StackTrace), "", exc.StackTrace)
            Dim inner = If(exc.InnerException IsNot Nothing, exc.InnerException.Message, "")
            inner_exception = If(String.IsNullOrEmpty(inner), "", inner)
            Me.date_by = Now

            Dim currentSession = HttpContext.Current.Session
            Dim user As String = currentSession("Login_name")
            If user Is Nothing Then user = ""

            Me.by_user = If(String.IsNullOrEmpty(user), "", user)
            Me.location = ""

            Dim st = New StackTrace()
            Dim sf As StackFrame = st.GetFrame(1)
            Dim mb As MethodBase = sf.GetMethod()

            Me.location = $"{mb.Name}"
        Catch ex As Exception
        End Try
    End Sub

    Public Sub Log()
        Dim dbaccess = New dbutil
        dbaccess.InsertError(Me)
    End Sub
End Class