﻿Public Class stu_req_uploaded_files
    Public Property uploadID As Integer
    Public Property profileno As Integer
    Public Property req_id As Integer
    Public Property filename As String
    Public Property path As String
    Public Property status As Integer
    Public Property active As Boolean
    Public Property created_by As String
    Public Property created_date As DateTime

End Class
