﻿Public Class sponsorletter
    Public Property sponsorid As Integer
    Public Property profile_no As Integer
    Public Property letterdate As DateTime
    Public Property lettername As String
    Public Property lettersubject As String
    Public Property study_year As String

    Public Property study_start_date As DateTime
    Public Property academic_year As String

    Public Property academic_year_end_date As DateTime

    Public Property course_amount As Decimal
    Public Property noofweeks As Decimal

    Public Property letterto As String

    Public Property lettertext As String
    Public Property path As String
    Public Property created_by As String
    Public Property created_date As DateTime
    Public Property modified_by As String
    Public Property modified_date As DateTime
    Public Property active As Boolean
End Class
