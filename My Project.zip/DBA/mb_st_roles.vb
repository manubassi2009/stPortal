﻿Public Class mb_st_roles

    Public Property role_id As Integer
    Public Property type As String
    Public Property permissions As Byte
    Public Property created_by As String
    Public Property created_date As DateTime
    Public Property modified_by As String
    Public Property modified_date As DateTime
    Public Property active As Byte
End Class
