﻿Public Class mb_st_institute

    Public Property institute_id As Integer
    Public Property name As String
    Public Property address_line_1 As String
    Public Property address_line_2 As String
    Public Property city As String
    Public Property county As String
    Public Property postcode As String
    Public Property country As String
    Public Property created_by As String
    Public Property created_date As DateTime
    Public Property modified_by As String
    Public Property modified_date As DateTime
    Public Property active As Byte
End Class
