﻿Public Class mb_st_family_details

    Public Property st_family_id As Integer
    Public Property stu_profile_no As Integer
    Public Property stu_id As Integer
    Public Property family_profile_no As Integer
    Public Property family_full_name As String
    Public Property family_full_name_arabic As String
    Public Property family_title As String
    Public Property family_first_name As String
    Public Property family_last_name As String
    Public Property family_dob As Date
    Public Property family_gender As String
    Public Property family_national_number As String
    Public Property family_passport_number As String
    Public Property passport_id As Integer
    Public Property course_id As Integer
    Public Property institute_id As Integer
    Public Property qualification_id As Integer
    Public Property family_relation_student As String
    Public Property family_degree_name As String
    Public Property family_course_name As String
    Public Property family_college_uni_name As String
    Public Property family_address_1 As String
    Public Property family_address_2 As String
    Public Property family_city As String
    Public Property family_postcode As String
    Public Property family_county As String
    Public Property family_country As String
    Public Property family_full_address As String
    Public Property family_email_address As String
    Public Property family_mobile_1 As String
    Public Property family_mobile_2 As String
    Public Property visa_expiry_date As Date
    Public Property other_latitude As Decimal
    Public Property other_longitude As Decimal
    Public Property active As Byte
    Public Property created_by As String
    Public Property created_date As DateTime
    Public Property modified_by As String
    Public Property modified_date As DateTime

End Class
