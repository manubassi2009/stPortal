﻿Public Class mb_sys_files

    Public Property sys_file_id As Integer
    Public Property stu_id As Integer
    Public Property user_id As Integer
    Public Property created_by As String
    Public Property created_date As DateTime
    Public Property modified_by As String
    Public Property modified_date As DateTime
    Public Property active As Byte
End Class
