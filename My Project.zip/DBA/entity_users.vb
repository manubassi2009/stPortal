﻿Public Class entity_users

    Public Property entity_user_id As Integer
    Public Property stu_id As Integer
    Public Property user_id As Integer
    Public Property role_id As Integer
    Public Property category_id As Integer
    Public Property created_by As String
    Public Property created_date As DateTime
    Public Property modified_by As String
    Public Property modified_date As DateTime
    Public Property active As Byte
End Class
