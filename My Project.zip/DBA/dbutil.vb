﻿Imports System.Data.SqlClient
Imports System.Reflection

Public Class dbutil
    Structure UserType
        Public Const self = "ad6a73b9"
        Public Const other = "4ca4adc0"
        Public Const admin = "1422d9a64499"
    End Structure
    Public Function GetOrSet_FORGOT_GUID_PASSWORD(ByVal LOGIN_ID As Integer) As String
        Dim result As String = ""
        Dim UserNameDT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter

        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select guid_ID from mb_st_log where login_id=@id and active=1"
        myCommand.Parameters.Add(New SqlParameter("@id", LOGIN_ID))
        myAdapter = New SqlDataAdapter(myCommand)
        myAdapter.Fill(UserNameDT)
        Try
            If UserNameDT.Rows.Count > 0 Then

                If Convert.IsDBNull(UserNameDT.Rows(0).Item("GUID_ID")) = False Then
                    result = UserNameDT.Rows(0).Item("GUID_ID")
                End If

            End If
        Catch ex As Exception
            Dim newError As New logs(ex, "forgotpasswordguid")
            newError.Log()
            Dim er = ex.Message.ToString
        End Try
        If myConnection.State = ConnectionState.Open Then myConnection.Close()
        If String.IsNullOrWhiteSpace(result) = True Then
            Dim LinkedID As Integer = 0
            Try
                Dim sqlCon As New SqlConnection(Get_NewConn())
                sqlCon.Open()

                Dim Qry As String = ""

                Qry = Qry & " update mb_st_log set guid_ID=@GUID_ID , guidActive=@guidActive "
                Qry = Qry & " where login_id=@id and active=1"

                Dim command As New SqlCommand(Qry, sqlCon)
                Dim tempguide = Guid.NewGuid.ToString
                result = tempguide
                command.Parameters.AddWithValue("@GUID_ID", tempguide)
                command.Parameters.AddWithValue("@guidActive", 1)
                command.Parameters.AddWithValue("@id", LOGIN_ID)
                command.ExecuteNonQuery()
                sqlCon.Close()
                sqlCon.Dispose()
                result = tempguide
            Catch ex As Exception
                Dim newError As New logs(ex, "DBUtilExtended")
                newError.Log()
                Dim er = ex.Message
                result = ""
            End Try
        End If

        Return result
    End Function
    Public Function Active_guid_key_for_password_reset(ByVal guidid As String) As Boolean
        Dim result As Boolean = False
        Dim UserNameDT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim LinkedID As Integer = 0
        Try
                Dim sqlCon As New SqlConnection(Get_NewConn())
                sqlCon.Open()
                Dim Qry As String = ""
                Qry = Qry & " update mb_st_log set guidActive=@guidActive "
                Qry = Qry & " where guid_ID=@id and active=1"
                Dim command As New SqlCommand(Qry, sqlCon)
                command.Parameters.AddWithValue("@guidActive", 1)
                command.Parameters.AddWithValue("@id", guidid)
                Dim i As Integer = command.ExecuteNonQuery()
                If i > 0 Then result = True
                sqlCon.Close()
                sqlCon.Dispose()
            Catch ex As Exception
                Dim newError As New logs(ex, "activate guid")
                newError.Log()
                Dim er = ex.Message
                result = False
            End Try
        Return result
    End Function
    Public Function Update_guid_After_password_reset(ByVal guidid As String, ByVal pass As String) As String
        Dim result As String = ""
        Dim UserNameDT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        If String.IsNullOrWhiteSpace(result) = True Then
            Dim LinkedID As Integer = 0
            Try
                Dim sqlCon As New SqlConnection(Get_NewConn())
                sqlCon.Open()

                Dim Qry As String = ""

                Qry = Qry & " update mb_st_log set password=@pass, guidActive=@guidActive "
                Qry = Qry & " where guid_ID=@id and active=1"

                Dim command As New SqlCommand(Qry, sqlCon)
                command.Parameters.AddWithValue("@pass", pass)
                command.Parameters.AddWithValue("@guidActive", 0)
                command.Parameters.AddWithValue("@id", guidid)
                result = command.ExecuteNonQuery()

                sqlCon.Close()
                sqlCon.Dispose()
            Catch ex As Exception
                Dim newError As New logs(ex, "inactivate guid")
                newError.Log()
                Dim er = ex.Message
                result = ""
            End Try
        End If

        Return result
    End Function

    Public Function Update_password_reset(ByVal id As Integer, ByVal pass As String) As String
        Dim result As String = ""
        Dim UserNameDT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        If String.IsNullOrWhiteSpace(result) = True Then
            Dim LinkedID As Integer = 0
            Try
                Dim sqlCon As New SqlConnection(Get_NewConn())
                sqlCon.Open()

                Dim Qry As String = ""

                Qry = Qry & " update mb_st_log set password=@pass"
                Qry = Qry & " where login_ID=@id and active=1"

                Dim command As New SqlCommand(Qry, sqlCon)
                command.Parameters.AddWithValue("@pass", pass)
                command.Parameters.AddWithValue("@id", id)
                result = command.ExecuteNonQuery()

                sqlCon.Close()
                sqlCon.Dispose()
            Catch ex As Exception
                Dim newError As New logs(ex, "update password")
                newError.Log()
                Dim er = ex.Message
                result = ""
            End Try
        End If

        Return result
    End Function

    Public Function Get_FORGOT_GUID_PASSWORD(ByVal ID As String) As Boolean
        Dim result As Boolean = False
        Dim UserNameDT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter

        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select guid_ID from mb_st_log where guid_id=@id and guidActive=1"
        myCommand.Parameters.Add(New SqlParameter("@id", ID))
        myAdapter = New SqlDataAdapter(myCommand)
        myAdapter.Fill(UserNameDT)
        Try
            If UserNameDT.Rows.Count > 0 Then
                If Convert.IsDBNull(UserNameDT.Rows(0).Item("GUID_ID")) = False Then
                    result = True
                End If
            End If
        Catch ex As Exception
            Dim newError As New logs(ex, "get guid ")
            newError.Log()
            Dim er = ex.Message.ToString
        End Try
        If myConnection.State = ConnectionState.Open Then myConnection.Close()

        Return result
    End Function

    Public Function Confirm_User_ProfileNo_Not_Exit(ByVal profileno As String) As Boolean
        Dim result As Boolean = False
        Dim user_DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myConnection.Open()
        myCommand.Connection = myConnection
        myCommand.CommandText = "select profile_no from mb_st_details where profile_no=@param1 and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@param1", SqlDbType.VarChar).Value = profileno
        myAdapter.Fill(user_DT)
        Dim myDataReader As SqlDataReader = myCommand.ExecuteReader()
        If myDataReader.HasRows Then
            result = True
        Else
            result = False
        End If
        If myConnection.State = ConnectionState.Open Then
            myConnection.Close()
            myConnection.Dispose()
        End If
        Return result
    End Function
    Public Function Get_Ciper_codeValue(ByVal ID As String) As String
        Dim result As String = ""
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter

        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select entity_user_id,saltkey from mb_st_login_sys_view where guid_id=@id and active=1"
        myCommand.Parameters.Add(New SqlParameter("@id", ID))
        myAdapter = New SqlDataAdapter(myCommand)
        myAdapter.Fill(_DT)
        Try
            If _DT.Rows.Count > 0 Then
                If Convert.IsDBNull(_DT.Rows(0).Item("saltkey")) = False Then
                    result = _DT.Rows(0).Item("saltkey")
                End If
            End If
        Catch ex As Exception
            Dim newError As New logs(ex, "get ciper ")
            newError.Log()
            Dim er = ex.Message.ToString
        End Try
        If myConnection.State = ConnectionState.Open Then myConnection.Close()

        Return result
    End Function

    Public Function Get_Ciper_code(ByVal ID As String) As Boolean
        Dim result As Boolean = False
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter

        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select entity_user_id,saltkey from mb_st_login_sys_view where guid_id=@id and active=1"
        myCommand.Parameters.Add(New SqlParameter("@id", ID))
        myAdapter = New SqlDataAdapter(myCommand)
        myAdapter.Fill(_DT)
        Try
            If _DT.Rows.Count > 0 Then
                If Convert.IsDBNull(_DT.Rows(0).Item("saltkey")) = False Then
                    result = True
                End If
            End If
        Catch ex As Exception
            Dim newError As New logs(ex, "get ciper ")
            newError.Log()
            Dim er = ex.Message.ToString
        End Try
        If myConnection.State = ConnectionState.Open Then myConnection.Close()

        Return result
    End Function

    Public Function Get_Ciper_code_by_login_id(ByVal ID As String) As String
        Dim result As String = ""
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter

        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select entity_user_id,saltkey from mb_st_s_login_view where login_id=@id and active=1"
        myCommand.Parameters.Add(New SqlParameter("@id", ID))
        myAdapter = New SqlDataAdapter(myCommand)
        myAdapter.Fill(_DT)
        Try
            If _DT.Rows.Count > 0 Then
                If Convert.IsDBNull(_DT.Rows(0).Item("saltkey")) = False Then
                    result = _DT.Rows(0).Item("saltkey")
                End If
            End If
        Catch ex As Exception
            Dim newError As New logs(ex, "get ciper ")
            newError.Log()
            Dim er = ex.Message.ToString
        End Try
        If myConnection.State = ConnectionState.Open Then myConnection.Close()

        Return result
    End Function
    Public Function Get_Ciper_code_by_ENTITY_id(ByVal ID As String) As String
        Dim result As String = ""
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        'Dim QRY As String = "SELECT dbo.mb_st_log.entity_user_id,dbo.mb_st_log.login_id, dbo.mb_st_log.username, dbo.mb_st_log.password, dbo.mb_st_ciper.saltkey, dbo.mb_st_log.active "
        'QRY += " FROM  dbo.mb_st_log INNER JOIN "
        'QRY += "  dbo.mb_st_ciper ON dbo.mb_st_log.entity_user_id = dbo.mb_st_ciper.entity_user_id where dbo.mb_st_log.login_id=@id and dbo.mb_st_log.active=1"
        Dim QRY As String = "SELECT entity_user_id,saltkey from mb_st_ciper where entity_user_id=@id "
        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = QRY
        myCommand.Parameters.Add(New SqlParameter("@id", ID))
        myAdapter = New SqlDataAdapter(myCommand)
        myAdapter.Fill(_DT)
        Try
            If _DT.Rows.Count > 0 Then
                If Convert.IsDBNull(_DT.Rows(0).Item("saltkey")) = False Then
                    result = _DT.Rows(0).Item("saltkey")
                End If
            End If
        Catch ex As Exception
            Dim newError As New logs(ex, "get ciper ")
            newError.Log()
            Dim er = ex.Message.ToString
        End Try
        If myConnection.State = ConnectionState.Open Then myConnection.Close()

        Return result
    End Function
    Public Function InsertUser(ByVal objUser As mb_st_user, ByVal UserName As String) As Integer
        Dim LinkedID As Integer = 0
        Try
            'TO DO :- qualification_id, role_id, full_name, 
            'other_latitude, other_longitude, modified_by, modified_date
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim qry As String = "INSERT INTO mb_st_user (  "
            If String.IsNullOrWhiteSpace(objUser.role_id) = False Then qry += " role_id, "
            If String.IsNullOrWhiteSpace(objUser.title) = False Then qry += " title, "
            If String.IsNullOrWhiteSpace(objUser.first_name) = False Then qry += " first_name, "
            If String.IsNullOrWhiteSpace(objUser.middle_name) = False Then qry += " middle_name, "
            If String.IsNullOrWhiteSpace(objUser.last_name) = False Then qry += " last_name, "
            If objUser.dob > Date.MinValue Then qry += " dob, "
            If String.IsNullOrWhiteSpace(objUser.gender) = False Then qry += " gender, "
            If String.IsNullOrWhiteSpace(objUser.email_address) = False Then qry += " email_address, "
            If String.IsNullOrWhiteSpace(objUser.address_1) = False Then qry += " address_1, "
            If String.IsNullOrWhiteSpace(objUser.address_2) = False Then qry += " address_2, "
            If String.IsNullOrWhiteSpace(objUser.city) = False Then qry += " city, "
            If String.IsNullOrWhiteSpace(objUser.county) = False Then qry += " county, "
            If String.IsNullOrWhiteSpace(objUser.country) = False Then qry += " country, "
            If String.IsNullOrWhiteSpace(objUser.postcode) = False Then qry += " postcode, "
            If String.IsNullOrWhiteSpace(objUser.full_address) = False Then qry += " full_address, "
            If String.IsNullOrWhiteSpace(objUser.full_name) = False Then qry += " full_name, "
            If String.IsNullOrWhiteSpace(objUser.mobile_1) = False Then qry += " mobile_1, "
            'If String.IsNullOrWhiteSpace(objUser.mobile_1_primary.ToString IsNot Nothing Then qry += " mobile_1_primary, "
            If String.IsNullOrWhiteSpace(objUser.mobile_2) = False Then qry += " mobile_2, "
            'If String.IsNullOrWhiteSpace(objUser.mobile_2_primary.ToString IsNot Nothing Then qry += " mobile_2_primary, "
            'qry += " role_id,title, first_name, middle_name, last_name, dob, gender, email_address, address_1, address_2, city, county, postcode, country, full_address,  "
            'qry += " mobile_1, mobile_1_primary, mobile_2, mobile_2_primary,  "
            qry += " active, created_by, created_date) VALUES ("
            If String.IsNullOrWhiteSpace(objUser.role_id) = False Then qry += " @role_id, "
            If String.IsNullOrWhiteSpace(objUser.title) = False Then qry += " @title, "
            If String.IsNullOrWhiteSpace(objUser.first_name) = False Then qry += " @first_name, "
            If String.IsNullOrWhiteSpace(objUser.middle_name) = False Then qry += " @middle_name, "
            If String.IsNullOrWhiteSpace(objUser.last_name) = False Then qry += " @last_name, "
            If objUser.dob > Date.MinValue Then qry += " @dob, "
            If String.IsNullOrWhiteSpace(objUser.gender) = False Then qry += " @gender, "
            If String.IsNullOrWhiteSpace(objUser.email_address) = False Then qry += " @email_address, "
            If String.IsNullOrWhiteSpace(objUser.address_1) = False Then qry += " @address_1, "
            If String.IsNullOrWhiteSpace(objUser.address_2) = False Then qry += " @address_2, "
            If String.IsNullOrWhiteSpace(objUser.city) = False Then qry += " @city, "
            If String.IsNullOrWhiteSpace(objUser.county) = False Then qry += " @county, "
            If String.IsNullOrWhiteSpace(objUser.country) = False Then qry += " @country, "
            If String.IsNullOrWhiteSpace(objUser.postcode) = False Then qry += " @postcode, "
            If String.IsNullOrWhiteSpace(objUser.full_address) = False Then qry += " @full_address, "
            If String.IsNullOrWhiteSpace(objUser.full_name) = False Then qry += " @full_name, "
            If String.IsNullOrWhiteSpace(objUser.mobile_1) = False Then qry += " @mobile_1, "
            'If String.IsNullOrWhiteSpace(objUser.mobile_1_primary.ToString IsNot Nothing Then qry += " @mobile_1_primary, "
            If String.IsNullOrWhiteSpace(objUser.mobile_2) = False Then qry += " @mobile_2, "
            'If String.IsNullOrWhiteSpace(objUser.mobile_2_primary.ToString IsNot Nothing Then qry += " @mobile_2_primary, "
            qry += " @active, @created_by, @created_date); SELECT SCOPE_IDENTITY();"
            qry += "  "
            Dim command As New SqlCommand(qry, sqlCon)
            If String.IsNullOrWhiteSpace(objUser.role_id) = False Then command.Parameters.AddWithValue("@role_id", objUser.role_id)
            If String.IsNullOrWhiteSpace(objUser.title) = False Then command.Parameters.AddWithValue("@title", objUser.title)
            If String.IsNullOrWhiteSpace(objUser.first_name) = False Then command.Parameters.AddWithValue("@first_name", objUser.first_name)
            If String.IsNullOrWhiteSpace(objUser.middle_name) = False Then command.Parameters.AddWithValue("@middle_name", objUser.middle_name)
            If String.IsNullOrWhiteSpace(objUser.last_name) = False Then command.Parameters.AddWithValue("@last_name", objUser.last_name)
            If String.IsNullOrWhiteSpace(objUser.full_name) = False Then command.Parameters.AddWithValue("@full_name", objUser.full_name)
            If objUser.dob > Date.MinValue Then command.Parameters.AddWithValue("@dob", objUser.dob)

            If String.IsNullOrWhiteSpace(objUser.gender) = False Then command.Parameters.AddWithValue("@gender", objUser.gender)
            If String.IsNullOrWhiteSpace(objUser.email_address) = False Then command.Parameters.AddWithValue("@email_address", objUser.email_address)
            If String.IsNullOrWhiteSpace(objUser.address_1) = False Then command.Parameters.AddWithValue("@address_1", objUser.address_1)
            If String.IsNullOrWhiteSpace(objUser.address_2) = False Then command.Parameters.AddWithValue("@address_2", objUser.address_2)
            If String.IsNullOrWhiteSpace(objUser.city) = False Then command.Parameters.AddWithValue("@city", objUser.city)
            If String.IsNullOrWhiteSpace(objUser.county) = False Then command.Parameters.AddWithValue("@county", objUser.county)
            If String.IsNullOrWhiteSpace(objUser.postcode) = False Then command.Parameters.AddWithValue("@postcode", objUser.postcode)
            If String.IsNullOrWhiteSpace(objUser.country) = False Then command.Parameters.AddWithValue("@country", objUser.country)
            If String.IsNullOrWhiteSpace(objUser.full_address) = False Then command.Parameters.AddWithValue("@full_address", objUser.full_address)
            If String.IsNullOrWhiteSpace(objUser.mobile_1) = False Then command.Parameters.AddWithValue("@mobile_1", objUser.mobile_1)
            'If objUser.mobile_1_primary.ToString IsNot Nothing Then command.Parameters.AddWithValue("@mobile_1_primary", objUser.mobile_1_primary)
            If String.IsNullOrWhiteSpace(objUser.mobile_2) = False Then command.Parameters.AddWithValue("@mobile_2", objUser.mobile_2)
            'If objUser.mobile_2_primary.ToString IsNot Nothing Then command.Parameters.AddWithValue("@mobile_2_primary", objUser.mobile_2_primary)
            command.Parameters.AddWithValue("@active", 1)
            command.Parameters.AddWithValue("@created_by", objUser.created_by)
            command.Parameters.AddWithValue("@created_date", Now())
            LinkedID = Convert.ToInt32(command.ExecuteScalar())

            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtil InsertUser")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

        Return LinkedID

    End Function

    Public Function InsertCiper(ByVal objCiper As mb_st_ciper, ByVal UserName As String) As Integer
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim qry As String = "INSERT INTO mb_st_ciper ("
            qry += " entity_user_id,saltkey, created_by, created_date,active) VALUES "
            qry += " (@entity_user_id,@saltkey,  "
            qry += " @created_by, @created_date,@active); SELECT SCOPE_IDENTITY();"
            qry += "  "
            Dim command As New SqlCommand(qry, sqlCon)
            command.Parameters.AddWithValue("@entity_user_id", objCiper.entity_user_id)
            command.Parameters.AddWithValue("@saltkey", objCiper.saltkey)
            command.Parameters.AddWithValue("@active", 1)
            command.Parameters.AddWithValue("@created_by", objCiper.created_by)
            command.Parameters.AddWithValue("@created_date", Now())
            LinkedID = Convert.ToInt32(command.ExecuteScalar())
            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtil InsertCiper")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

        Return LinkedID

    End Function
    Public Function Insert_mb_st_log(ByVal objLogin As mb_st_log, ByVal UserName As String) As Integer
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim qry As String = "INSERT INTO mb_st_log ("
            qry += " entity_user_id,username,password, created_by, created_date,active) VALUES "
            qry += " (@entity_user_id,@username,@password,  "
            qry += " @created_by, @created_date,@active); SELECT SCOPE_IDENTITY();"
            qry += "  "
            Dim command As New SqlCommand(qry, sqlCon)
            command.Parameters.AddWithValue("@entity_user_id", objLogin.entity_user_id)
            command.Parameters.AddWithValue("@username", objLogin.username)
            command.Parameters.AddWithValue("@password", objLogin.password)
            command.Parameters.AddWithValue("@active", 1)
            command.Parameters.AddWithValue("@created_by", objLogin.created_by)
            command.Parameters.AddWithValue("@created_date", Now())
            LinkedID = Convert.ToInt32(command.ExecuteScalar())
            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtil InsertLogin")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

        Return LinkedID

    End Function


    Public Function InsertFilesOnRequest(ByVal objFiles As stu_req_uploaded_files) As Integer
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim qry As String = "INSERT INTO stu_req_uploaded_files ("
            qry += " profileno,req_id,filename,path,active,created_by,created_date) VALUES "
            qry += " (  @stu_id,@req_id,@filename,@path,@active,"
            qry += " @created_by, @created_date); SELECT SCOPE_IDENTITY();"
            qry += "  "
            Dim command As New SqlCommand(qry, sqlCon)
            command.Parameters.AddWithValue("@stu_id", objFiles.profileno)
            command.Parameters.AddWithValue("@req_id", objFiles.req_id)
            command.Parameters.AddWithValue("@filename", objFiles.filename)
            command.Parameters.AddWithValue("@path", objFiles.path)

            command.Parameters.AddWithValue("@active", 1)
            command.Parameters.AddWithValue("@created_by", objFiles.created_by)
            command.Parameters.AddWithValue("@created_date", Now())
            LinkedID = Convert.ToInt32(command.ExecuteScalar())
            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtil InsertFilesOnRequest")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

        Return LinkedID

    End Function

    Public Function Update_student_picture_path(ByVal profileno As Integer, ByVal path As String) As Integer
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim Qry As String = ""
            Qry = Qry & " update mb_st_details set profileimg=@param1"
            Qry = Qry & " where profile_no=@id and active=1"
            Dim command As New SqlCommand(Qry, sqlCon)
            command.Parameters.AddWithValue("@param1", path)
            command.Parameters.AddWithValue("@id", profileno)
            LinkedID = command.ExecuteNonQuery()
            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "update profile image")
            newError.Log()
            Dim er = ex.Message
        End Try
        Return LinkedID
    End Function




    Public Sub InsertError(errorDetails As logs)
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim qry = "INSERT INTO logs ("
            qry += " message, "
            qry += " stack_trace, "
            qry += " inner_exception, "
            qry += " date_by, "
            qry += " by_user, "
            qry += " location, "
            qry += " active "
            qry += " ) "
            qry += " VALUES ("
            qry += " @message, "
            qry += " @stack_trace, "
            qry += " @inner_exception, "
            qry += " @date_by, "
            qry += " @by_user, "
            qry += " @location, "
            qry += " @active "
            qry += " ) "

            Dim command As New SqlCommand(qry, sqlCon)

            command.Parameters.AddWithValue("@message", errorDetails.message)
            command.Parameters.AddWithValue("@stack_trace", errorDetails.stack_trace)
            command.Parameters.AddWithValue("@inner_exception", errorDetails.inner_exception)
            command.Parameters.AddWithValue("@date_by", errorDetails.date_by)
            command.Parameters.AddWithValue("@by_user", errorDetails.by_user)
            command.Parameters.AddWithValue("@location", errorDetails.location)
            command.Parameters.AddWithValue("@active", errorDetails.active)
            command.ExecuteNonQuery()

            sqlCon.Close()
            sqlCon.Dispose()

        Catch ex As Exception
            MsgBox("error -=>", ex.Message)
        End Try
    End Sub

    Public Function Get_UserInfo_Byemail(ByVal email As String) As mb_st_user
        Dim result As New mb_st_user
        Dim user_DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter

        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from mb_st_user where email_address=@email and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@email", SqlDbType.VarChar).Value = email
        myAdapter.Fill(user_DT)
        result = DataTableToList(Of mb_st_user)(user_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close()

        Return result
    End Function

    Public Function Confirm_User_Exit_Byemail(ByVal email As String) As Boolean
        Dim result As Boolean = False
        Dim user_DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myConnection.Open()
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from mb_st_user where email_address=@email and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@email", SqlDbType.VarChar).Value = email
        myAdapter.Fill(user_DT)
        Dim myDataReader As SqlDataReader = myCommand.ExecuteReader()
        If myDataReader.HasRows Then
            result = True
        Else
            result = False
        End If
        If myConnection.State = ConnectionState.Open Then
            myConnection.Close()
            myConnection.Dispose()
        End If
        Return result
    End Function
    Public Function Confirm_Student_at_reg(ByVal student As mb_st_details) As Boolean
        Dim result As Boolean = False
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myConnection.Open()
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from mb_st_details where profile_no=@profile_no and stu_national_number=@stu_national_number and stu_email_address=@email and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@profile_no", SqlDbType.VarChar).Value = student.profile_no
        myCommand.Parameters.Add("@stu_national_number", SqlDbType.VarChar).Value = student.stu_national_number
        myCommand.Parameters.Add("@email", SqlDbType.VarChar).Value = student.stu_email_address

        myAdapter.Fill(_DT)
        Dim myDataReader As SqlDataReader = myCommand.ExecuteReader()
        If myDataReader.HasRows Then
            result = True
        Else
            result = False
        End If
        If myConnection.State = ConnectionState.Open Then
            myConnection.Close()
            myConnection.Dispose()
        End If
        Return result
    End Function

    Public Function Confirm_Student_for_password(ByVal student As mb_st_details) As Integer
        Dim result As Integer = 0
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        Dim qry As String = ""
        qry += " SELECT m.stu_id, m.profile_no, e.entity_user_id, l.login_id, l.guid_ID, l.guidActive, l.username, "
        qry += " m.stu_national_number,m.stu_email_address FROM mb_st_details m INNER JOIN "
        qry += " entity_users e On m.stu_id = e.stu_id INNER JOIN "
        qry += " mb_st_log l ON e.entity_user_id = l.entity_user_id "
        qry += " where m.profile_no=@profile_no and m.stu_national_number=@stu_national_number and m.stu_email_address=@email and m.active=1 "

        myCommand = New SqlCommand
        myConnection.Open()
        myCommand.Connection = myConnection
        myCommand.CommandText = qry
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@profile_no", SqlDbType.VarChar).Value = student.profile_no
        myCommand.Parameters.Add("@stu_national_number", SqlDbType.VarChar).Value = student.stu_national_number
        myCommand.Parameters.Add("@email", SqlDbType.VarChar).Value = student.stu_email_address

        myAdapter.Fill(_DT)
        Dim myDataReader As SqlDataReader = myCommand.ExecuteReader()
        If myDataReader.HasRows Then
            If _DT.Rows.Count = 1 Then
                With _DT.Rows(0)
                    result = .Item("login_id")
                End With
            End If
        Else
            result = 0
        End If
        If myConnection.State = ConnectionState.Open Then
            myConnection.Close()
            myConnection.Dispose()
        End If
        Return result
    End Function


    Public Shared Function DataTableTo_Multi_List(Of T As {Class, New})(table As DataTable) As List(Of T)
        Try
            Dim list As New List(Of T)()

            For Each row In table.AsEnumerable()
                Dim obj As New T()

                For Each prop In obj.[GetType]().GetProperties()
                    Try
                        If table.Columns.Contains(prop.Name) AndAlso Not IsDBNull(row(prop.Name)) Then
                            Dim name As String = prop.Name
                            Dim propertyInfo As PropertyInfo = obj.[GetType]().GetProperty(prop.Name)
                            propertyInfo.SetValue(obj, Convert.ChangeType(row(prop.Name), propertyInfo.PropertyType), Nothing)
                        End If
                    Catch ex As Exception
                        Dim err = ex.Message
                        Continue For
                    End Try
                Next

                list.Add(obj)
            Next

            Return list
        Catch
            Return Nothing
        End Try
    End Function

    Public Shared Function DataTableToList(Of T As {Class, New})(table As DataTable) As T
        Try
            Dim list As New List(Of T)()
            Dim obj As New T()
            For Each row In table.AsEnumerable()
                For Each prop In obj.[GetType]().GetProperties()
                    Try
                        If table.Columns.Contains(prop.Name) AndAlso Not IsDBNull(row(prop.Name)) Then
                            Dim propertyInfo As PropertyInfo = obj.[GetType]().GetProperty(prop.Name)
                            propertyInfo.SetValue(obj, Convert.ChangeType(row(prop.Name), propertyInfo.PropertyType), Nothing)
                        End If
                    Catch ex As Exception
                        Dim err = ex.Message
                        Continue For
                    End Try
                Next

                list.Add(obj)
            Next

            Return obj
        Catch
            Return Nothing
        End Try
    End Function
    Public Function Get_roles_datatable_users() As DataTable
        Dim Roles_DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter

        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "SELECT role_id,type,permissions,active FROM mb_st_roles where active=1 and permissions<>4 and permissions<>0"
        myAdapter = New SqlDataAdapter(myCommand)
        myAdapter.Fill(Roles_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close()
        Return Roles_DT
    End Function
    Public Function Get_roles_datatable() As DataTable
        Dim Roles_DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter

        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "SELECT role_id,type,permissions,active FROM mb_st_roles where active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myAdapter.Fill(Roles_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close()
        Return Roles_DT
    End Function
    Public Function Get_qualification_datatable() As DataTable
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter

        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "SELECT qualification_id,qualification_name,active FROM mb_st_qualification where active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myAdapter.Fill(_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close()
        Return _DT
    End Function
    Public Function Get_institute_datatable() As DataTable
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter

        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "SELECT institute_id,name,active FROM mb_st_institute_details where active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myAdapter.Fill(_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close()
        Return _DT
    End Function
    Public Function Get_course_datatable() As DataTable
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter

        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "SELECT course_id,course_name,active FROM mb_st_courses where active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myAdapter.Fill(_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close()
        Return _DT
    End Function
    Public Function CompressSpaces(ByVal txt As String) As String
        Do While InStr(txt, "  ") > 0
            txt = Replace(txt, "  ", " ")
        Loop
        CompressSpaces = txt
    End Function


    Public Function GenerateSalt() As String
        Dim returnResult = CreateRandomPassword(16)
        Return returnResult
    End Function

    Public Function CreateRandomPassword(ByVal PasswordLength As Integer) As String
        Dim _allowedChars As String = "abcdefghijkmnopqrstuvwxyz!?#$+-*&?:ABCDEFGHJKLMNOPQRSTUVWXYZ0123456789"
        Dim randomNumber As New Random()
        Dim chars(PasswordLength - 1) As Char
        Dim allowedCharCount As Integer = _allowedChars.Length
        For i As Integer = 0 To PasswordLength - 1
            chars(i) = _allowedChars.Chars(CInt(Fix((_allowedChars.Length) * randomNumber.NextDouble())))
        Next i
        Return New String(chars)
    End Function

    Function MD5_Hash(ByVal SourceText As String) As String
        Try
            Dim MD5 As New System.Security.Cryptography.MD5CryptoServiceProvider
            Dim rawBytes As Byte() = System.Text.ASCIIEncoding.ASCII.GetBytes(SourceText)
            Dim myHash As Byte() = MD5.ComputeHash(rawBytes)
            Dim Capacity As Integer = (myHash.Length * 2 + (myHash.Length / 8))
            Dim result As New System.Text.StringBuilder(Capacity)
            Dim i As Integer
            For i = 0 To myHash.Length - 1
                result.Append(BitConverter.ToString(myHash, i, 1))
            Next i
            Return result.ToString().TrimEnd(New Char() {" "c}).ToLower
            Return "0"
        Catch ex As Exception
            Dim newError As New logs(ex, "")
            newError.Log()
            Return "0"
        End Try
    End Function

    Public Function Get_log_details_Byemail(ByVal email As String) As DataTable
        'Dim result As New mb_st_log_sys_view
        Dim user_login_DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from [dbo].[mb_st_login_sys_view] where username=@email and login_active=1"
        'myCommand.CommandText = "select * from mb_st_log where username=@email and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@email", SqlDbType.VarChar).Value = email
        myAdapter.Fill(user_login_DT)
        'result = DataTableToList(Of mb_st_log_sys_view)(user_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close() myConnection.Dispose()

        Return user_login_DT
    End Function
    Public Function Get_permissions_By_role_id(ByVal id As Integer) As mb_st_roles
        Dim Result As New mb_st_roles
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from mb_st_roles where role_id=@id and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@id", SqlDbType.VarChar).Value = id
        myAdapter.Fill(_DT)
        Result = DataTableToList(Of mb_st_roles)(_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close() myConnection.Dispose()
        Return Result
    End Function
    Public Function Get_UserInfo_ByID(ByVal Userid As Integer) As mb_st_user
        Dim result As New mb_st_user
        Dim user_DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter

        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from mb_st_user where user_id=@user_id and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@user_id", SqlDbType.VarChar).Value = Userid
        myAdapter.Fill(user_DT)
        result = DataTableToList(Of mb_st_user)(user_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close()
        Return result
    End Function
    Public Function Get_StudentInfo_ByID(ByVal Stuid As Integer) As mb_st_details
        Dim result As New mb_st_details
        Dim user_DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from mb_st_details where stu_id=@stu_id and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@stu_id", SqlDbType.VarChar).Value = Stuid
        myAdapter.Fill(user_DT)
        result = DataTableToList(Of mb_st_details)(user_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close()
        Return result
    End Function

    Public Function UpdateLastLogin(ByVal objLogin_id As Integer) As Integer
        Dim a As Integer
        Dim sqlCon As New SqlConnection(Get_NewConn())
        sqlCon.Open()
        Dim qry = ""
        Try
            'Update
            qry = " UPDATE mb_st_log SET "
            qry += " last_login_on=@last_login_on, "
            qry += " modified_by=@modified_by, "
            qry += " modified_date=@modified_date "
            qry += " where login_id=@login_id And active = 1 "
            Dim command As New SqlCommand(qry, sqlCon)
            command.Parameters.AddWithValue("@last_login_on", Now())
            command.Parameters.AddWithValue("@modified_by", "System")
            command.Parameters.AddWithValue("@modified_date", Now)
            command.Parameters.AddWithValue("@login_id", objLogin_id)
            a = command.ExecuteNonQuery()
        Catch ex As Exception
            Dim newError As New logs(ex, "updateLastLogin")
            newError.Log()
        Finally
            sqlCon.Close()
            sqlCon.Dispose()
        End Try
        Return a
    End Function


    Public Function Bind_All_Users(Optional ByVal userId As Integer = 0, Optional ByVal roleID As Integer = 0) As DataTable
        Dim List_DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        Dim qry As String = "SELECT mb_st_user.user_id,mb_st_roles.type, mb_st_roles.permissions, mb_st_user.full_name, mb_st_user.title, "
        qry += "mb_st_user.email_address, mb_st_user.full_address, mb_st_user.mobile_1, mb_st_user.active, "
        qry += " mb_st_roles.role_id FROM mb_st_user INNER JOIN mb_st_roles ON mb_st_user.role_id = mb_st_roles.role_id "
        qry += " where (mb_st_user.active = 1) "
        If userId > 0 Then qry += " and (mb_st_user.user_id = @user_id) "
        If roleID > 0 Then qry += " and (mb_st_roles.permissions = @role_id)"
        'qry += " WHERE  (mb_st_roles.role_id = @role_id) "

        myCommand.CommandText = qry
        If roleID > 0 Then myCommand.Parameters.Add("@role_id", SqlDbType.Int).Value = roleID
        If userId > 0 Then myCommand.Parameters.Add("@user_id", SqlDbType.Int).Value = userId
        myAdapter = New SqlDataAdapter(myCommand)
        myAdapter.Fill(List_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close() myConnection.Dispose()
        Return List_DT
    End Function

    Public Function StrBetween(ByVal value As String) As String
        Dim sSource As String = value
        Dim sDelimStart As String = "ID "
        Dim sDelimEnd As String = ":"
        Dim nIndexStart As Integer = sSource.IndexOf(sDelimStart)
        Dim nIndexEnd As Integer = sSource.IndexOf(sDelimEnd)
        Dim res As String = ""
        If nIndexStart > -1 AndAlso nIndexEnd > -1 Then
            res = Strings.Mid(sSource, nIndexStart + sDelimStart.Length + 1, nIndexEnd - nIndexStart - sDelimStart.Length) 'Crop the text between
        Else
        End If
        Return res
    End Function

    Public Function Insert_Qal(ByVal objQal As mb_st_qualification) As Integer
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim qry As String = "INSERT INTO mb_st_qualification ("
            qry += " qualification_name,created_by, created_date,active) VALUES "
            qry += " (@name,  "
            qry += " @created_by, @created_date,@active); SELECT SCOPE_IDENTITY();"
            qry += "  "
            Dim command As New SqlCommand(qry, sqlCon)
            command.Parameters.AddWithValue("@name", objQal.qualification_name)
            command.Parameters.AddWithValue("@active", 1)
            command.Parameters.AddWithValue("@created_by", objQal.created_by)
            command.Parameters.AddWithValue("@created_date", Now())
            LinkedID = Convert.ToInt32(command.ExecuteScalar())
            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtil InsertQal")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

        Return LinkedID

    End Function

    Public Function check_qal(ByVal var As String) As Boolean
        Dim result As Boolean
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter

        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from mb_st_qualification where qualification_name=@name and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@name", SqlDbType.VarChar).Value = var.ToString
        myAdapter.Fill(_DT)
        If _DT.Rows.Count > 0 Then
            result = True
        Else
            result = False
        End If
        If myConnection.State = ConnectionState.Open Then myConnection.Close()
        Return result
    End Function


    Public Function Insert_course(ByVal objcourse As mb_st_courses) As Integer
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim qry As String = "INSERT INTO mb_st_courses ("
            qry += " course_name,created_by, created_date,active) VALUES "
            qry += " (@course_name,  "
            qry += " @created_by, @created_date,@active); SELECT SCOPE_IDENTITY();"
            qry += "  "
            Dim command As New SqlCommand(qry, sqlCon)
            command.Parameters.AddWithValue("@course_name", objcourse.course_name)
            command.Parameters.AddWithValue("@active", 1)
            command.Parameters.AddWithValue("@created_by", objcourse.created_by)
            command.Parameters.AddWithValue("@created_date", Now())
            LinkedID = Convert.ToInt32(command.ExecuteScalar())
            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtil InsertCourse")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

        Return LinkedID

    End Function

    Public Function check_course(ByVal var As String) As Boolean
        Dim result As Boolean
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter

        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from mb_st_courses where course_name=@name and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@name", SqlDbType.VarChar).Value = var.ToString
        myAdapter.Fill(_DT)
        If _DT.Rows.Count > 0 Then
            result = True
        Else
            result = False
        End If
        If myConnection.State = ConnectionState.Open Then myConnection.Close()
        Return result
    End Function

    Public Function Insert_University(ByVal objUni As mb_st_institute) As Integer
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim qry As String = "INSERT INTO mb_st_institute_details ("
            qry += " name,created_by, created_date,active) VALUES "
            qry += " (@name,  "
            qry += " @created_by, @created_date,@active); SELECT SCOPE_IDENTITY();"
            qry += "  "
            Dim command As New SqlCommand(qry, sqlCon)
            command.Parameters.AddWithValue("@name", objUni.name)
            command.Parameters.AddWithValue("@active", 1)
            command.Parameters.AddWithValue("@created_by", objUni.created_by)
            command.Parameters.AddWithValue("@created_date", Now())
            LinkedID = Convert.ToInt32(command.ExecuteScalar())
            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtil InsertUniversity")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

        Return LinkedID

    End Function

    Public Function check_University(ByVal var As String) As Boolean
        Dim result As Boolean
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter

        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from mb_st_institute_details where name=@name and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@name", SqlDbType.VarChar).Value = var.ToString
        myAdapter.Fill(_DT)
        If _DT.Rows.Count > 0 Then
            result = True
        Else
            result = False
        End If
        If myConnection.State = ConnectionState.Open Then myConnection.Close()
        Return result
    End Function

    Public Function Confirm_Student_Exit_Byemail(ByVal email As String) As Boolean
        Dim result As Boolean = False
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myConnection.Open()
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from mb_st_details where stu_email_address=@email and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@email", SqlDbType.VarChar).Value = email
        myAdapter.Fill(_DT)
        Dim myDataReader As SqlDataReader = myCommand.ExecuteReader()
        If myDataReader.HasRows Then
            result = True
        Else
            result = False
        End If
        If myConnection.State = ConnectionState.Open Then
            myConnection.Close()
            myConnection.Dispose()
        End If
        Return result
    End Function

    Public Function Insert_Passport_info(ByVal objPassport As mb_st_passport) As Integer
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim qry As String = "INSERT INTO mb_st_passport_details ("
            qry += " passport_no,created_by, created_date,active) VALUES "
            qry += " (@no,  "
            qry += " @created_by, @created_date,@active); SELECT SCOPE_IDENTITY();"
            qry += "  "
            Dim command As New SqlCommand(qry, sqlCon)
            command.Parameters.AddWithValue("@no", objPassport.passport_no)
            command.Parameters.AddWithValue("@active", 1)
            command.Parameters.AddWithValue("@created_by", objPassport.created_by)
            command.Parameters.AddWithValue("@created_date", Now())
            LinkedID = Convert.ToInt32(command.ExecuteScalar())
            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtil Insertpassportinfo")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

        Return LinkedID

    End Function
    Public Function Insert_visa_info(ByVal objVisa As mb_st_visa) As Integer
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim qry As String = "INSERT INTO mb_st_visa_details (passport_id,"
            qry += " visa_issue_date,visa_expiry_date,created_by, created_date,active) VALUES "
            qry += " (@passport_id,@visa_issue_date,@visa_expiry_date,  "
            qry += " @created_by, @created_date,@active); SELECT SCOPE_IDENTITY();"
            qry += "  "
            Dim command As New SqlCommand(qry, sqlCon)
            command.Parameters.AddWithValue("@passport_id", objVisa.passport_id)
            command.Parameters.AddWithValue("@visa_issue_date", objVisa.visa_issue_date)
            command.Parameters.AddWithValue("@visa_expiry_date", objVisa.visa_expiry_date)
            command.Parameters.AddWithValue("@active", 1)
            command.Parameters.AddWithValue("@created_by", objVisa.created_by)
            command.Parameters.AddWithValue("@created_date", Now())
            LinkedID = Convert.ToInt32(command.ExecuteScalar())
            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtil Insertvisainfo")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

        Return LinkedID

    End Function

    Public Function Get_Student_details_Byemail(ByVal email As String) As mb_st_details
        Dim result As New mb_st_details
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from mb_st_details where stu_email_address=@email and active=1"
        'myCommand.CommandText = "select * from mb_st_log where username=@email and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@email", SqlDbType.VarChar).Value = email
        myAdapter.Fill(_DT)
        result = DataTableToList(Of mb_st_details)(_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close() myConnection.Dispose()
        Return result
    End Function
    Public Function Get_Entity_ID_For_Student_By_ID(ByVal ID As Integer) As entity_users
        Dim result As New entity_users
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from entity_users where stu_id=@id and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@id", SqlDbType.VarChar).Value = ID
        myAdapter.Fill(_DT)
        result = DataTableToList(Of entity_users)(_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close() myConnection.Dispose()
        Return result
    End Function
    Public Function Get_Entity_ID_By_User_ID(ByVal ID As Integer) As entity_users
        Dim result As New entity_users
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from entity_users where user_id=@id and stu_id=0 and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@id", SqlDbType.VarChar).Value = ID
        myAdapter.Fill(_DT)
        result = DataTableToList(Of entity_users)(_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close() myConnection.Dispose()
        Return result
    End Function
    Public Function Get_Entity_ID_By_User_ID_0(ByVal ID As Integer) As entity_users
        Dim result As New entity_users
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from entity_users where user_id=@id and stu_id=0 and active=0"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@id", SqlDbType.VarChar).Value = ID
        myAdapter.Fill(_DT)
        result = DataTableToList(Of entity_users)(_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close() myConnection.Dispose()
        Return result
    End Function
    Public Function Get_User_ID_By_Entity_ID(ByVal ID As Integer) As mb_st_user
        Dim result As New mb_st_user
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from entity_users where entity_user_id=@id and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@id", SqlDbType.VarChar).Value = ID
        myAdapter.Fill(_DT)
        result = DataTableToList(Of mb_st_user)(_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close() myConnection.Dispose()
        Return result
    End Function
    Public Function Get_Role_ID_By_ID(ByVal ID As Integer) As entity_users
        Dim result As New entity_users
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from entity_users where entity_user_id=@id and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@id", SqlDbType.VarChar).Value = ID
        myAdapter.Fill(_DT)
        result = DataTableToList(Of entity_users)(_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close() myConnection.Dispose()
        Return result
    End Function
    Public Function Get_login_id_By_Entity_ID(ByVal ID As Integer) As mb_st_log
        Dim result As New mb_st_log
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from mb_st_log where entity_user_id=@id and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@id", SqlDbType.VarChar).Value = ID
        myAdapter.Fill(_DT)
        result = DataTableToList(Of mb_st_log)(_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close() myConnection.Dispose()
        Return result
    End Function
    Public Function Get_login_id_By_Entity_ID_0(ByVal ID As Integer) As mb_st_log
        Dim result As New mb_st_log
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from mb_st_log where entity_user_id=@id and active=0"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@id", SqlDbType.VarChar).Value = ID
        myAdapter.Fill(_DT)
        result = DataTableToList(Of mb_st_log)(_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close() myConnection.Dispose()
        Return result
    End Function
    Public Function Confirm_User_Already_Registered(ByVal email As String) As Boolean
        Dim result As Boolean = False
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myConnection.Open()
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from mb_st_log where username=@email and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@email", SqlDbType.VarChar).Value = email
        myAdapter.Fill(_DT)
        Dim myDataReader As SqlDataReader = myCommand.ExecuteReader()
        If myDataReader.HasRows Then
            result = True
        Else
            result = False
        End If
        If myConnection.State = ConnectionState.Open Then
            myConnection.Close()
            myConnection.Dispose()
        End If
        Return result
    End Function


    Public Function Insert_Sh_Student(ByVal objUser As mb_st_details, ByVal UserName As String) As Integer
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim qry As String = "INSERT INTO mb_st_details (  "
            If String.IsNullOrWhiteSpace(objUser.role_id) = False Then qry += " role_id, "
            If String.IsNullOrWhiteSpace(objUser.stu_title) = False Then qry += " stu_title, "
            If String.IsNullOrWhiteSpace(objUser.stu_first_name) = False Then qry += " stu_first_name, "
            If String.IsNullOrWhiteSpace(objUser.stu_last_name) = False Then qry += " stu_last_name, "
            If String.IsNullOrWhiteSpace(objUser.stu_full_name) = False Then qry += " stu_full_name, "
            If String.IsNullOrWhiteSpace(objUser.stu_email_address) = False Then qry += " stu_email_address, "
            If String.IsNullOrWhiteSpace(objUser.profile_no) = False Then qry += " profile_no, "
            If String.IsNullOrWhiteSpace(objUser.stu_national_number) = False Then qry += " stu_national_number, "
            qry += " active, created_by, created_date) VALUES ("

            If String.IsNullOrWhiteSpace(objUser.role_id.ToString) = False Then qry += " @role_id, "
            If String.IsNullOrWhiteSpace(objUser.stu_title) = False Then qry += " @title, "
            If String.IsNullOrWhiteSpace(objUser.stu_first_name) = False Then qry += " @first_name, "
            If String.IsNullOrWhiteSpace(objUser.stu_last_name) = False Then qry += " @last_name, "
            If String.IsNullOrWhiteSpace(objUser.stu_full_name) = False Then qry += " @stu_full_name, "
            If String.IsNullOrWhiteSpace(objUser.stu_email_address) = False Then qry += " @email_address, "
            If String.IsNullOrWhiteSpace(objUser.profile_no) = False Then qry += " @profile_no, "
            If String.IsNullOrWhiteSpace(objUser.stu_national_number) = False Then qry += " @stu_national_number, "
            qry += " @active, @created_by, @created_date); SELECT SCOPE_IDENTITY();"
            qry += "  "

            Dim command As New SqlCommand(qry, sqlCon)
            If String.IsNullOrWhiteSpace(objUser.role_id) = False Then command.Parameters.AddWithValue("@role_id", 1) 'objUser.role_id)

            If String.IsNullOrWhiteSpace(objUser.stu_title) = False Then command.Parameters.AddWithValue("@title", objUser.stu_title)
            If String.IsNullOrWhiteSpace(objUser.stu_first_name) = False Then command.Parameters.AddWithValue("@first_name", objUser.stu_first_name)
            If String.IsNullOrWhiteSpace(objUser.stu_last_name) = False Then command.Parameters.AddWithValue("@last_name", objUser.stu_last_name)

            If String.IsNullOrWhiteSpace(objUser.stu_full_name) = False Then command.Parameters.AddWithValue("@stu_full_name", objUser.stu_full_name)

            If String.IsNullOrWhiteSpace(objUser.stu_email_address) = False Then command.Parameters.AddWithValue("@email_address", objUser.stu_email_address)

            If String.IsNullOrWhiteSpace(objUser.profile_no) = False Then command.Parameters.AddWithValue("@profile_no", objUser.profile_no)
            If String.IsNullOrWhiteSpace(objUser.stu_national_number) = False Then command.Parameters.AddWithValue("@stu_national_number", objUser.stu_national_number)

            command.Parameters.AddWithValue("@active", 1)
            command.Parameters.AddWithValue("@created_by", objUser.created_by)
            command.Parameters.AddWithValue("@created_date", Now())
            LinkedID = Convert.ToInt32(command.ExecuteScalar())

            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtil InsertStudent")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

        Return LinkedID

    End Function


    Public Function Insert_Req_Student(ByVal objReq As mb_req_form, ByVal UserName As String) As Integer
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim qry As String = "INSERT INTO mb_req_form (  "
            If objReq.stu_id > 0 Then qry += " stu_id, "
            If objReq.user_id > 0 Then qry += " user_id, "
            If objReq.entity_user_id > 0 Then qry += " entity_user_id, "
            If String.IsNullOrWhiteSpace(objReq.req_type) = False Then qry += " req_type, "
            If String.IsNullOrWhiteSpace(objReq.req_details_1) = False Then qry += " req_details_1, "
            If String.IsNullOrWhiteSpace(objReq.re_details_more) = False Then qry += " re_details_more, "
            qry += " status,active, created_by, created_date) VALUES ("

            If objReq.stu_id > 0 Then qry += " @stu_id, "
            If objReq.user_id > 0 Then qry += " @user_id, "
            If objReq.entity_user_id > 0 Then qry += " @entity_user_id, "
            If String.IsNullOrWhiteSpace(objReq.req_type) = False Then qry += " @req_type, "
            If String.IsNullOrWhiteSpace(objReq.req_details_1) = False Then qry += " @req_details_1, "
            If String.IsNullOrWhiteSpace(objReq.re_details_more) = False Then qry += " @re_details_more, "
            qry += " @status,@active, @created_by, @created_date); SELECT SCOPE_IDENTITY();"
            qry += "  "

            Dim command As New SqlCommand(qry, sqlCon)
            If objReq.stu_id > 0 Then command.Parameters.AddWithValue("@stu_id", objReq.stu_id)
            If objReq.user_id > 0 Then command.Parameters.AddWithValue("@user_id", objReq.user_id)
            If objReq.entity_user_id > 0 Then command.Parameters.AddWithValue("@entity_user_id", objReq.entity_user_id)

            If String.IsNullOrWhiteSpace(objReq.req_type) = False Then command.Parameters.AddWithValue("@req_type", objReq.req_type)
            If String.IsNullOrWhiteSpace(objReq.req_details_1) = False Then command.Parameters.AddWithValue("@req_details_1", objReq.req_details_1)
            If String.IsNullOrWhiteSpace(objReq.re_details_more) = False Then command.Parameters.AddWithValue("@re_details_more", objReq.re_details_more)
            command.Parameters.AddWithValue("@status", 0)
            command.Parameters.AddWithValue("@active", 1)
            command.Parameters.AddWithValue("@created_by", objReq.created_by)
            command.Parameters.AddWithValue("@created_date", Now())
            LinkedID = Convert.ToInt32(command.ExecuteScalar())

            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtil Req Form")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

        Return LinkedID

    End Function



    Public Function Update_Student_isRegestered(ByVal ID As Integer, ByVal reg As Integer) As Integer
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()

            Dim Qry As String = ""

            Qry = Qry & " update mb_st_details set isRegistered=@reg"
            Qry = Qry & " where stu_id=@id and active=1"
            Dim command As New SqlCommand(Qry, sqlCon)
            command.Parameters.AddWithValue("@reg", reg)
            command.Parameters.AddWithValue("@id", ID)
            LinkedID = command.ExecuteNonQuery()

            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtilExtended")
            newError.Log()
            Dim er = ex.Message
        End Try
        Return LinkedID
    End Function

    Function Create_User_Ciper(ByVal userid As Integer, ByVal code As String) As Integer
        Dim objciper As New mb_st_ciper
        'Create User Record
        Dim resultID As Integer = 0
        If Not String.IsNullOrWhiteSpace(userid) Then objciper.entity_user_id = userid
        If Not String.IsNullOrWhiteSpace(code) Then objciper.saltkey = code
        objciper.created_by = "Demo-system" 'Session("UserName")
        Try
            resultID = InsertCiper(objciper, "Demo-system")
        Catch ex As Exception
            Dim newError As New logs(ex, "createuser")
            newError.Log()
            Debug.Print(ex.Message)
        End Try
        Return resultID
    End Function
    Function Insert_Login(ByVal userid As Integer, ByVal username As String, ByVal password As String) As Integer
        Dim objlogin As New mb_st_log
        'Create User Record
        Dim resultID As Integer = 0
        If Not String.IsNullOrWhiteSpace(userid) Then objlogin.entity_user_id = userid
        If Not String.IsNullOrWhiteSpace(username) Then objlogin.username = LCase(username)
        If Not String.IsNullOrWhiteSpace(password) Then objlogin.password = password
        objlogin.created_by = "Demo-system" 'Session("UserName")
        Try
            resultID = Insert_mb_st_log(objlogin, "Demo-system")
        Catch ex As Exception
            Dim newError As New logs(ex, "createlogin")
            newError.Log()
            Debug.Print(ex.Message)
        End Try
        Return resultID
    End Function


    Public Function Bind_Request_form(
                                     Optional ByVal Profile_No As Integer = 0,
                                      Optional ByVal Stu_Id As Integer = 0,
                                     Optional ByVal User_ID As Integer = 0) As DataTable
        'Optional ByVal status As Integer = 0) As DataTable
        Dim List_DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        Dim qry As String = "SELECT  req_id ,req_type, req_details_1 ,re_details_more,status ,active "
        qry += ",profile_no ,stu_full_name ,stu_national_number,isRegistered ,student_active ,full_name,stu_id,user_id, created_date "
        qry += " FROM dbo.Request_form_queue "
        qry += " where (active=1) "
        If Profile_No > 0 Then qry += " and (profile_no = @prof_no) "
        If User_ID > 0 Then qry += " and (user_id = @user_id) "
        If Stu_Id > 0 Then qry += " and ( stu_id= @stu_id)"
        ' If status > 0 Then qry += " and ( status= @req_status)"
        'If Active > 0 Then qry += " and ( status= @req_status)"
        'qry += " WHERE  (mb_st_roles.role_id = @role_id) "

        myCommand.CommandText = qry
        'myCommand.Parameters.Add("@prof_no", SqlDbType.Int).Value = Profile_No
        If Profile_No > 0 Then myCommand.Parameters.Add("@prof_no", SqlDbType.Int).Value = Profile_No
        If User_ID > 0 Then myCommand.Parameters.Add("@user_id", SqlDbType.Int).Value = User_ID
        If Stu_Id > 0 Then myCommand.Parameters.Add("@stu_Id", SqlDbType.Int).Value = Stu_Id
        ' If status > 0 Then myCommand.Parameters.Add("@req_status", SqlDbType.Int).Value = status
        myAdapter = New SqlDataAdapter(myCommand)
        myAdapter.Fill(List_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close() myConnection.Dispose()
        Return List_DT
    End Function


    Public Function Get_Req_Queue_By_ID(ByVal ID As Integer) As Request_form_queue
        Dim result As New Request_form_queue
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from Request_form_queue where req_id=@id and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@id", SqlDbType.VarChar).Value = ID
        myAdapter.Fill(_DT)
        result = DataTableToList(Of Request_form_queue)(_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close() myConnection.Dispose()
        Return result
    End Function


    Public Function Get_Student_by_profile_no(ByVal profile_no As Integer) As mb_st_details
        Dim result As New mb_st_details
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myConnection.Open()
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from mb_st_details where profile_no=@profile_no and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@profile_no", SqlDbType.Int).Value = profile_no
        myAdapter.Fill(_DT)
        result = DataTableToList(Of mb_st_details)(_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close() myConnection.Dispose()
        Return result
    End Function

    Public Function Get_Request_Path_Queue_By_ID(ByVal ID As Integer) As stu_req_uploaded_files
        Dim result As New stu_req_uploaded_files
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        myCommand.CommandText = "select * from stu_req_uploaded_files where uploadID=@id and active=1"
        myAdapter = New SqlDataAdapter(myCommand)
        myCommand.Parameters.Add("@id", SqlDbType.VarChar).Value = ID
        myAdapter.Fill(_DT)
        result = DataTableToList(Of stu_req_uploaded_files)(_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close() myConnection.Dispose()
        Return result
    End Function


    Public Function UpdateAllocatesupervisorStudent(ByVal user_id As Integer, ByVal stud_id As Integer, ByVal name As String) As Integer
        Dim a As Integer
        Dim sqlCon As New SqlConnection(Get_NewConn())
        sqlCon.Open()
        Dim qry = ""
        Try
            'Update
            qry = " UPDATE entity_users set "
            qry += " user_id=@param1, "
            qry += " modified_by=@modified_by, "
            qry += " modified_date=@modified_date "
            qry += " where stu_id=@param2 And active = 1 "
            Dim command As New SqlCommand(qry, sqlCon)
            command.Parameters.AddWithValue("@param1", user_id)
            command.Parameters.AddWithValue("@modified_by", name)
            command.Parameters.AddWithValue("@modified_date", Now)
            command.Parameters.AddWithValue("@param2", stud_id)
            a = command.ExecuteNonQuery()
        Catch ex As Exception
            Dim newError As New logs(ex, "UpdateAllocatesupervisorStudent")
            newError.Log()
        Finally
            sqlCon.Close()
            sqlCon.Dispose()
        End Try
        Return a
    End Function


    Public Function Update_Student_byID_short(ByVal objStu As mb_st_details) As Integer
        ' Dim objStu As New mb_st_details
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim Qry As String = ""
            Qry = Qry & " update mb_st_details set stu_full_name=@param1"
            Qry = Qry & " where stu_id=@id and active=1"
            Dim command As New SqlCommand(Qry, sqlCon)
            command.Parameters.AddWithValue("@param1", objStu.stu_full_name)
            command.Parameters.AddWithValue("@id", objStu.stu_id)
            LinkedID = command.ExecuteNonQuery()

            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtilExtended")
            newError.Log()
            Dim er = ex.Message
        End Try
        Return LinkedID
    End Function
    Public Function Update_Student_Full(ByVal objStu As mb_st_details) As Integer
        ' Dim objStu As New mb_st_details
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim Qry As String = ""
            Qry = Qry & " UPDATE dbo.mb_st_details SET "

            If String.IsNullOrWhiteSpace(objStu.stu_full_name) = False Then Qry += " stu_full_name=@stu_full_name, "
            If String.IsNullOrWhiteSpace(objStu.stu_title) = False Then Qry += " stu_title=@stu_title, "
            If String.IsNullOrWhiteSpace(objStu.stu_first_name) = False Then Qry += " stu_first_name=@stu_first_name, "
            If String.IsNullOrWhiteSpace(objStu.stu_last_name) = False Then Qry += " stu_last_name=@stu_last_name, "
            If objStu.stu_dob > Date.MinValue Then Qry += " stu_dob=@stu_dob, "
            If String.IsNullOrWhiteSpace(objStu.stu_gender) = False Then Qry += " stu_gender=@stu_gender, "
            If String.IsNullOrWhiteSpace(objStu.stu_national_number) = False Then Qry += " stu_national_number=@stu_national_number, "
            If String.IsNullOrWhiteSpace(objStu.stu_passport_no) = False Then Qry += " stu_passport_no=@stu_passport_no, "
            If objStu.st_visa_expiry_date > Date.MinValue Then Qry += " st_visa_expiry_date=@st_visa_expiry_date, "
            If String.IsNullOrWhiteSpace(objStu.degree_name) = False Then Qry += " degree_name=@degree_name, "
            If String.IsNullOrWhiteSpace(objStu.university_name) = False Then Qry += " university_name=@university_name, "
            If String.IsNullOrWhiteSpace(objStu.course_name) = False Then Qry += " course_name=@course_name, "
            If String.IsNullOrWhiteSpace(objStu.stu_address_1) = False Then Qry += " stu_address_1=@stu_address_1, "
            If String.IsNullOrWhiteSpace(objStu.stu_address_2) = False Then Qry += " stu_address_2=@stu_address_2, "
            If String.IsNullOrWhiteSpace(objStu.stu_city) = False Then Qry += " stu_city=@stu_city, "
            If String.IsNullOrWhiteSpace(objStu.stu_county) = False Then Qry += " county=@county, "
            If String.IsNullOrWhiteSpace(objStu.stu_country) = False Then Qry += " stu_country=@stu_country, "
            If String.IsNullOrWhiteSpace(objStu.stu_postcode) = False Then Qry += " stu_postcode=@stu_postcode, "

            If String.IsNullOrWhiteSpace(objStu.stu_alt_email_address) = False Then Qry += " stu_alt_email_address=@stu_alt_email_address, "
            If String.IsNullOrWhiteSpace(objStu.stu_mobile_1) = False Then Qry += " stu_mobile_1=@stu_mobile_1, "
            If String.IsNullOrWhiteSpace(objStu.stu_mobile_2) = False Then Qry += " stu_mobile_2=@stu_mobile_2, "
            Qry += " modified_by = @modified_by, "
            Qry += " modified_date = @modified_date "
            Qry += "  where stu_id=@id and active=1"
            Dim command As New SqlCommand(Qry, sqlCon)
            If String.IsNullOrWhiteSpace(objStu.stu_full_name) = False Then command.Parameters.AddWithValue("@stu_full_name", objStu.stu_full_name)
            If String.IsNullOrWhiteSpace(objStu.stu_title) = False Then command.Parameters.AddWithValue("@stu_title", objStu.stu_title)
            If String.IsNullOrWhiteSpace(objStu.stu_first_name) = False Then command.Parameters.AddWithValue("@stu_first_name", objStu.stu_first_name)
            If String.IsNullOrWhiteSpace(objStu.stu_last_name) = False Then command.Parameters.AddWithValue("@stu_last_name", objStu.stu_last_name)
            If objStu.stu_dob > Date.MinValue Then command.Parameters.AddWithValue("@stu_dob", objStu.stu_dob)
            If String.IsNullOrWhiteSpace(objStu.stu_gender) = False Then command.Parameters.AddWithValue("@stu_gender", objStu.stu_gender)
            If String.IsNullOrWhiteSpace(objStu.stu_national_number) = False Then command.Parameters.AddWithValue("@stu_national_number", objStu.stu_national_number)
            If String.IsNullOrWhiteSpace(objStu.stu_passport_no) = False Then command.Parameters.AddWithValue("@stu_passport_no", objStu.stu_passport_no)
            If objStu.st_visa_expiry_date > Date.MinValue Then command.Parameters.AddWithValue("@st_visa_expiry_date", objStu.st_visa_expiry_date)
            If String.IsNullOrWhiteSpace(objStu.degree_name) = False Then command.Parameters.AddWithValue("@degree_name", objStu.degree_name)
            If String.IsNullOrWhiteSpace(objStu.university_name) = False Then command.Parameters.AddWithValue("@university_name", objStu.university_name)
            If String.IsNullOrWhiteSpace(objStu.course_name) = False Then command.Parameters.AddWithValue("@course_name", objStu.course_name)
            If String.IsNullOrWhiteSpace(objStu.stu_address_1) = False Then command.Parameters.AddWithValue("@stu_address_1", objStu.stu_address_1)
            If String.IsNullOrWhiteSpace(objStu.stu_address_2) = False Then command.Parameters.AddWithValue("@stu_address_2", objStu.stu_address_2)
            If String.IsNullOrWhiteSpace(objStu.stu_city) = False Then command.Parameters.AddWithValue("@stu_city", objStu.stu_city)
            If String.IsNullOrWhiteSpace(objStu.stu_county) = False Then command.Parameters.AddWithValue("@county", objStu.stu_county)
            If String.IsNullOrWhiteSpace(objStu.stu_country) = False Then command.Parameters.AddWithValue("@stu_country", objStu.stu_country)
            If String.IsNullOrWhiteSpace(objStu.stu_postcode) = False Then command.Parameters.AddWithValue("@stu_postcode", objStu.stu_postcode)

            If String.IsNullOrWhiteSpace(objStu.stu_alt_email_address) = False Then command.Parameters.AddWithValue("@stu_alt_email_address", objStu.stu_alt_email_address)
            If String.IsNullOrWhiteSpace(objStu.stu_mobile_1) = False Then command.Parameters.AddWithValue("@stu_mobile_1", objStu.stu_mobile_1)
            If String.IsNullOrWhiteSpace(objStu.stu_mobile_2) = False Then command.Parameters.AddWithValue("@stu_mobile_2", objStu.stu_mobile_2)
            command.Parameters.AddWithValue("@modified_by", objStu.modified_by)
            command.Parameters.AddWithValue("@modified_date", objStu.modified_date)
            command.Parameters.AddWithValue("@id", objStu.stu_id)
            LinkedID = command.ExecuteNonQuery()

            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtilExtended")
            newError.Log()
            Dim er = ex.Message
        End Try
        Return LinkedID
    End Function

    'insert family details short version- start from here 25/05/2018
    Public Function Insert_family_Sh_Student(ByVal _familyObj As mb_st_family_details, ByVal UserName As String) As Integer
        'stu_id error to handle 
        'Cannot insert the value NULL into column 'stu_id', table 'mb_st_portal.dbo.mb_st_family_details'; column does not allow nulls. INSERT fails.
        '  The statement has been terminated.
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim qry As String = "INSERT INTO mb_st_family_details (  "

            If String.IsNullOrWhiteSpace(_familyObj.family_relation_student) = False Then qry += " family_relation_student, "
            If _familyObj.stu_id > 0 Then qry += " stu_id, "
            If _familyObj.stu_profile_no > 0 Then qry += " stu_profile_no, "
            If _familyObj.family_profile_no > 0 Then qry += " family_profile_no, "
            'family_full_name_arabic
            If String.IsNullOrWhiteSpace(_familyObj.family_full_name_arabic) = False Then qry += " family_full_name_arabic, "
            If String.IsNullOrWhiteSpace(_familyObj.family_title) = False Then qry += " family_title, "
            If String.IsNullOrWhiteSpace(_familyObj.family_first_name) = False Then qry += " family_first_name, "
            If String.IsNullOrWhiteSpace(_familyObj.family_last_name) = False Then qry += " family_last_name, "
            If String.IsNullOrWhiteSpace(_familyObj.family_full_name) = False Then qry += " family_full_name, "
            If String.IsNullOrWhiteSpace(_familyObj.family_email_address) = False Then qry += " family_email_address, "
            If String.IsNullOrWhiteSpace(_familyObj.family_national_number) = False Then qry += " family_national_number, "
            If String.IsNullOrWhiteSpace(_familyObj.family_passport_number) = False Then qry += " family_passport_number, "
            If _familyObj.family_dob > Date.MinValue Then qry += " family_dob, "
            If String.IsNullOrWhiteSpace(_familyObj.family_gender) = False Then qry += " family_gender, "
            If String.IsNullOrWhiteSpace(_familyObj.family_degree_name) = False Then qry += " family_degree_name, "
            If String.IsNullOrWhiteSpace(_familyObj.family_course_name) = False Then qry += " family_course_name, "
            If String.IsNullOrWhiteSpace(_familyObj.family_college_uni_name) = False Then qry += " family_college_uni_name, "
            If _familyObj.visa_expiry_date > Date.MinValue Then qry += " visa_expiry_date, "
            If String.IsNullOrWhiteSpace(_familyObj.family_mobile_1) = False Then qry += " family_mobile_1, "
            If String.IsNullOrWhiteSpace(_familyObj.family_mobile_2) = False Then qry += " family_mobile_2, "
            qry += " active, created_by, created_date) VALUES ("
            If String.IsNullOrWhiteSpace(_familyObj.family_relation_student) = False Then qry += " @family_relation_student, "
            If _familyObj.stu_id > 0 Then qry += " @stu_id, "
            If _familyObj.stu_profile_no > 0 Then qry += " @stu_profile_no, "
            If _familyObj.family_profile_no > 0 Then qry += " @family_profile_no, "
            'family_full_name_arabic
            If String.IsNullOrWhiteSpace(_familyObj.family_full_name_arabic) = False Then qry += " @family_full_name_arabic, "
            If String.IsNullOrWhiteSpace(_familyObj.family_title) = False Then qry += " @family_title, "
            If String.IsNullOrWhiteSpace(_familyObj.family_first_name) = False Then qry += " @family_first_name, "
            If String.IsNullOrWhiteSpace(_familyObj.family_last_name) = False Then qry += " @family_last_name, "
            If String.IsNullOrWhiteSpace(_familyObj.family_full_name) = False Then qry += " @family_full_name, "
            If String.IsNullOrWhiteSpace(_familyObj.family_email_address) = False Then qry += " @family_email_address, "
            If String.IsNullOrWhiteSpace(_familyObj.family_national_number) = False Then qry += " @family_national_number, "
            If String.IsNullOrWhiteSpace(_familyObj.family_passport_number) = False Then qry += " @family_passport_number, "

            If _familyObj.family_dob > Date.MinValue Then qry += " @family_dob, "
            If String.IsNullOrWhiteSpace(_familyObj.family_gender) = False Then qry += " @family_gender, "
            If String.IsNullOrWhiteSpace(_familyObj.family_degree_name) = False Then qry += " @family_degree_name, "

            If String.IsNullOrWhiteSpace(_familyObj.family_course_name) = False Then qry += " @family_course_name, "
            If String.IsNullOrWhiteSpace(_familyObj.family_college_uni_name) = False Then qry += " @family_college_uni_name, "
            If _familyObj.visa_expiry_date > Date.MinValue Then qry += " @visa_expiry_date, "
            If String.IsNullOrWhiteSpace(_familyObj.family_mobile_1) = False Then qry += " @family_mobile_1, "
            If String.IsNullOrWhiteSpace(_familyObj.family_mobile_2) = False Then qry += " @family_mobile_2, "
            qry += " @active, @created_by, @created_date); SELECT SCOPE_IDENTITY();"
            qry += "  "

            Dim command As New SqlCommand(qry, sqlCon)

            If String.IsNullOrWhiteSpace(_familyObj.family_relation_student) = False Then command.Parameters.AddWithValue("@family_relation_student", _familyObj.family_relation_student)
            If _familyObj.stu_profile_no > 0 Then command.Parameters.AddWithValue("@stu_profile_no", _familyObj.stu_profile_no)
            If _familyObj.family_profile_no > 0 Then command.Parameters.AddWithValue("@family_profile_no", _familyObj.family_profile_no)
            If _familyObj.stu_id > 0 Then command.Parameters.AddWithValue("@stu_id", _familyObj.stu_id)
            'family_full_name_arabic
            If String.IsNullOrWhiteSpace(_familyObj.family_full_name_arabic) = False Then command.Parameters.AddWithValue("@family_full_name_arabic", _familyObj.family_full_name_arabic)
            If String.IsNullOrWhiteSpace(_familyObj.family_title) = False Then command.Parameters.AddWithValue("@family_title", _familyObj.family_title)
            If String.IsNullOrWhiteSpace(_familyObj.family_first_name) = False Then command.Parameters.AddWithValue("@family_first_name", _familyObj.family_first_name)
            If String.IsNullOrWhiteSpace(_familyObj.family_last_name) = False Then command.Parameters.AddWithValue("@family_last_name", _familyObj.family_last_name)
            If String.IsNullOrWhiteSpace(_familyObj.family_full_name) = False Then command.Parameters.AddWithValue("@family_full_name", _familyObj.family_full_name)
            If String.IsNullOrWhiteSpace(_familyObj.family_email_address) = False Then command.Parameters.AddWithValue("@family_email_address", _familyObj.family_email_address)
            If String.IsNullOrWhiteSpace(_familyObj.family_national_number) = False Then command.Parameters.AddWithValue("@family_national_number", _familyObj.family_national_number)
            If String.IsNullOrWhiteSpace(_familyObj.family_passport_number) = False Then command.Parameters.AddWithValue("@family_passport_number", _familyObj.family_passport_number)

            If _familyObj.family_dob > Date.MinValue Then command.Parameters.AddWithValue("@family_dob", _familyObj.family_dob)

            If String.IsNullOrWhiteSpace(_familyObj.family_gender) = False Then command.Parameters.AddWithValue("@family_gender", _familyObj.family_gender)

            If String.IsNullOrWhiteSpace(_familyObj.family_degree_name) = False Then command.Parameters.AddWithValue("@family_degree_name", _familyObj.family_degree_name)

            If String.IsNullOrWhiteSpace(_familyObj.family_course_name) = False Then command.Parameters.AddWithValue("@family_course_name", _familyObj.family_course_name)
            If String.IsNullOrWhiteSpace(_familyObj.family_college_uni_name) = False Then command.Parameters.AddWithValue("@family_college_uni_name", _familyObj.family_college_uni_name)
            If _familyObj.visa_expiry_date > Date.MinValue Then command.Parameters.AddWithValue("@visa_expiry_date", _familyObj.visa_expiry_date)
            If String.IsNullOrWhiteSpace(_familyObj.family_mobile_1) = False Then command.Parameters.AddWithValue("@family_mobile_1", _familyObj.family_mobile_1)
            If String.IsNullOrWhiteSpace(_familyObj.family_mobile_2) = False Then command.Parameters.AddWithValue("@family_mobile_2", _familyObj.family_mobile_2)

            command.Parameters.AddWithValue("@active", 1)
            command.Parameters.AddWithValue("@created_by", _familyObj.created_by)
            command.Parameters.AddWithValue("@created_date", Now())
            LinkedID = Convert.ToInt32(command.ExecuteScalar())

            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            'Dim newError As New logs(ex, "DBUtil Insertfamily")
            'newError.Log()
            Debug.Print(ex.Message)
        End Try

        Return LinkedID

    End Function


    Public Function Get_family_info_By_ID(ByVal _Id As Integer) As DataTable
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        Dim qry As String = "SELECT st_family_id,family_full_name_arabic,stu_id,family_profile_no,family_full_name,family_title,family_first_name,family_last_name,family_dob,family_gender,family_national_number,family_passport_number,family_relation_student "
        qry += " ,family_degree_name,family_course_name,family_college_uni_name,family_address_line_1,family_address_line_2,family_city,family_county,family_country,family_postcode,family_full_address "
        qry += " ,family_email_address,family_mobile_1,family_mobile_2,visa_expiry_date,other_latitude,other_longitude,active,created_by,created_date "
        qry += " ,modified_by,modified_date  FROM dbo.mb_st_family_details "
        qry += " where (mb_st_family_details.st_family_id = @id) "
        myCommand.CommandText = qry
        myCommand.Parameters.Add("@id", SqlDbType.Int).Value = _Id
        myAdapter = New SqlDataAdapter(myCommand)
        myAdapter.Fill(_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close() myConnection.Dispose()
        Return _DT
    End Function


    Public Function Insert_arabic_letter(ByVal objletter As arabicletter, ByVal UserName As String) As Integer
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim qry As String = "INSERT INTO arabiclettertable (  "
            qry += " profileno, letterto, letterdate, lettertext,lettersubject, "
            qry += " active, created_by, created_date) VALUES ("
            qry += " @profile_id, @letter_to, @letter_date, @letter_text, "
            qry += " @lettersubject,@active, @created_by, @created_date); SELECT SCOPE_IDENTITY();"
            qry += "  "

            Dim command As New SqlCommand(qry, sqlCon)
            command.Parameters.AddWithValue("@profile_id", objletter.profile_no)
            command.Parameters.AddWithValue("@letter_to", objletter.letterto)
            command.Parameters.AddWithValue("@letter_date", objletter.letterdate)
            command.Parameters.AddWithValue("@letter_text", objletter.lettertext)
            command.Parameters.AddWithValue("@lettersubject", objletter.lettersubject)
            command.Parameters.AddWithValue("@active", 1)
            command.Parameters.AddWithValue("@created_by", objletter.created_by)
            command.Parameters.AddWithValue("@created_date", Now())
            LinkedID = Convert.ToInt32(command.ExecuteScalar())
            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtil Req Form")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

        Return LinkedID

    End Function

    Public Function Update_arabic_letter(ByVal objletter As arabicletter) As Integer
        ' Dim objStu As New mb_st_details
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim Qry As String = ""
            Qry = Qry & " update arabiclettertable set  lettersubject=@lettersubject,letterdate=@letterdate,letterto=@letterto, lettertext=@lettertext,"
            'Qry = Qry &=" filename=@filename, path=@path,"
            Qry = Qry & "modified_by=@modified_by,modified_date=@modified_date where arabicletterid=@id and active=1"
            Dim command As New SqlCommand(Qry, sqlCon)
            command.Parameters.AddWithValue("@lettersubject", objletter.lettersubject)
            command.Parameters.AddWithValue("@letterdate", objletter.letterdate)
            command.Parameters.AddWithValue("@letterto", objletter.letterto)
            command.Parameters.AddWithValue("@lettertext", objletter.lettertext)
            'command.Parameters.AddWithValue("@filename", objletter.filename)
            'command.Parameters.AddWithValue("@path", objletter.path)

            command.Parameters.AddWithValue("@modified_by", objletter.modified_by)
            command.Parameters.AddWithValue("@modified_date", Date.Now())
            command.Parameters.AddWithValue("@id", objletter.arabicid)
            LinkedID = command.ExecuteNonQuery()
            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtilExtended")
            newError.Log()
            Dim er = ex.Message
        End Try
        Return LinkedID
    End Function

    Public Function delete_arabic_letter(ByVal objletter As arabicletter) As Integer
        ' Dim objStu As New mb_st_details
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim Qry As String = ""
            Qry = Qry & " update arabiclettertable set active=@param1,"
            Qry = Qry & "modified_by=@modified_by,modified_date=@modified_date where arabicletterid=@id and active=1"
            Dim command As New SqlCommand(Qry, sqlCon)
            command.Parameters.AddWithValue("@param1", 0)
            command.Parameters.AddWithValue("@modified_by", objletter.modified_by)
            command.Parameters.AddWithValue("@modified_date", Date.Now())
            command.Parameters.AddWithValue("@id", objletter.arabicid)
            LinkedID = command.ExecuteNonQuery()
            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtilExtended")
            newError.Log()
            Dim er = ex.Message
        End Try
        Return LinkedID
    End Function

    Public Function Update_arabic_pdf_path(ByVal path As String, ByVal filename As String, ByVal id As Integer) As Integer
        ' Dim objStu As New mb_st_details
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim Qry As String = ""
            Qry = Qry & " update arabiclettertable set path=@param1, filename=@param2"
            Qry = Qry & " where arabicletterid=@id and active=1"
            Dim command As New SqlCommand(Qry, sqlCon)
            command.Parameters.AddWithValue("@param1", path)
            command.Parameters.AddWithValue("@param2", filename)
            command.Parameters.AddWithValue("@id", id)
            LinkedID = command.ExecuteNonQuery()

            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtilExtended")
            newError.Log()
            Dim er = ex.Message
        End Try
        Return LinkedID
    End Function



    Public Function Insert_english_letter(ByVal objletter As englishletter, ByVal UserName As String) As Integer
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim qry As String = "INSERT INTO englishlettertable (  "
            qry += " profileno, letterto, letterdate, lettertext, lettersubject,"
            qry += " active, created_by, created_date) VALUES ("
            qry += " @profile_id, @letter_to, @letter_date, @letter_text, @lettersubject,"
            qry += " @active, @created_by, @created_date); SELECT SCOPE_IDENTITY();"
            qry += "  "

            Dim command As New SqlCommand(qry, sqlCon)
            command.Parameters.AddWithValue("@profile_id", objletter.profile_no)
            command.Parameters.AddWithValue("@letter_to", objletter.letterto)
            command.Parameters.AddWithValue("@lettersubject", objletter.lettersubject)
            command.Parameters.AddWithValue("@letter_date", objletter.letterdate)
            command.Parameters.AddWithValue("@letter_text", objletter.lettertext)
            command.Parameters.AddWithValue("@active", 1)
            command.Parameters.AddWithValue("@created_by", objletter.created_by)
            command.Parameters.AddWithValue("@created_date", Now())
            LinkedID = Convert.ToInt32(command.ExecuteScalar())
            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtil Req Form")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

        Return LinkedID

    End Function


    Public Function Update_english_letter(ByVal objletter As englishletter) As Integer
        ' Dim objStu As New mb_st_details
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim Qry As String = ""
            Qry = Qry & " update englishlettertable set  lettersubject=@lettersubject,letterdate=@letterdate,letterto=@letterto, lettertext=@lettertext,"
            Qry = Qry & "modified_by=@modified_by,modified_date=@modified_date where englishletterid=@id and active=1"
            Dim command As New SqlCommand(Qry, sqlCon)
            command.Parameters.AddWithValue("@lettersubject", objletter.lettersubject)
            command.Parameters.AddWithValue("@letterdate", objletter.letterdate)
            command.Parameters.AddWithValue("@letterto", objletter.letterto)
            command.Parameters.AddWithValue("@lettertext", objletter.lettertext)
            command.Parameters.AddWithValue("@modified_by", objletter.modified_by)
            command.Parameters.AddWithValue("@modified_date", Date.Now())
            command.Parameters.AddWithValue("@id", objletter.englishid)
            LinkedID = command.ExecuteNonQuery()
            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtilExtended")
            newError.Log()
            Dim er = ex.Message
        End Try
        Return LinkedID
    End Function

    Public Function delete_english_letter(ByVal objletter As arabicletter) As Integer
        ' Dim objStu As New mb_st_details
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim Qry As String = ""
            Qry = Qry & " update englishlettertable set active=@param1,"
            Qry = Qry & "modified_by=@modified_by,modified_date=@modified_date where englishletterid=@id and active=1"
            Dim command As New SqlCommand(Qry, sqlCon)
            command.Parameters.AddWithValue("@param1", 0)
            command.Parameters.AddWithValue("@modified_by", objletter.modified_by)
            command.Parameters.AddWithValue("@modified_date", Date.Now())
            command.Parameters.AddWithValue("@id", objletter.arabicid)
            LinkedID = command.ExecuteNonQuery()
            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtilExtended")
            newError.Log()
            Dim er = ex.Message
        End Try
        Return LinkedID
    End Function

    Public Function Update_english_pdf_path(ByVal path As String, ByVal filename As String, ByVal id As Integer) As Integer
        ' Dim objStu As New mb_st_details
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim Qry As String = ""
            Qry = Qry & " update englishlettertable set path=@param1, filename=@param2"
            Qry = Qry & " where englishletterid=@id and active=1"
            Dim command As New SqlCommand(Qry, sqlCon)
            command.Parameters.AddWithValue("@param1", path)
            command.Parameters.AddWithValue("@param2", filename)
            command.Parameters.AddWithValue("@id", id)
            LinkedID = command.ExecuteNonQuery()

            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtilExtended")
            newError.Log()
            Dim er = ex.Message
        End Try
        Return LinkedID
    End Function



    Public Function Insert_Sponsor_letter(ByVal objletter As sponsorletter, ByVal UserName As String) As Integer
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim qry As String = "INSERT INTO sponsorlettertable (  "
            qry += " profileno,lettersubject,letterdate,lettername,study_year,"
            qry += " study_start_date,"
            qry += " academic_year,"
            qry += " noofweeks,academic_year_end_date,course_amount, "
            qry += " lettertext,"
            qry += " active, created_by, created_date) VALUES ("
            qry += " @profileno,@lettersubject,@letterdate,@lettername,@study_year,"
            qry += " @study_start_date,"
            qry += " @academic_year,"
            qry += " @noofweeks,@academic_year_end_date,@course_amount, "
            qry += " @lettertext,"
            qry += " @active, @created_by, @created_date); SELECT SCOPE_IDENTITY();"
            qry += "  "

            Dim command As New SqlCommand(qry, sqlCon)
            command.Parameters.AddWithValue("@profileno", objletter.profile_no)
            command.Parameters.AddWithValue("@lettersubject", objletter.lettersubject)
            command.Parameters.AddWithValue("@letterdate", objletter.letterdate)
            command.Parameters.AddWithValue("@lettername", objletter.lettername)
            command.Parameters.AddWithValue("@study_year", objletter.study_year)
            command.Parameters.AddWithValue("@study_start_date", objletter.study_start_date)
            command.Parameters.AddWithValue("@academic_year", objletter.academic_year)
            command.Parameters.AddWithValue("@academic_year_end_date", objletter.academic_year_end_date)
            command.Parameters.AddWithValue("@noofweeks", objletter.noofweeks)
            command.Parameters.AddWithValue("@course_amount", objletter.course_amount)
            command.Parameters.AddWithValue("@lettertext", objletter.lettertext)
            command.Parameters.AddWithValue("@active", 1)
            command.Parameters.AddWithValue("@created_by", objletter.created_by)
            command.Parameters.AddWithValue("@created_date", Now())
            LinkedID = Convert.ToInt32(command.ExecuteScalar())
            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtil Sponsor Form")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

        Return LinkedID

    End Function


    Public Function Update_sponsor_letter(ByVal objletter As sponsorletter) As Integer

        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim Qry As String = ""
            Qry = Qry & " update sponsorlettertable   SET letterdate = @letterdate,lettersubject = @lettersubject "
            Qry = Qry & " ,lettername = @lettername, study_year = @study_year,study_start_date = @study_start_date ,academic_year = @academic_year,"
            Qry = Qry & " noofweeks = @noofweeks ,academic_year_end_date = @academic_year_end_date  ,course_amount = @course_amount  ,"
            Qry = Qry & "lettertext = @lettertext, "
            Qry = Qry & "modified_by=@modified_by,modified_date=@modified_date where sponsorletterid=@id and active=1"
            Dim command As New SqlCommand(Qry, sqlCon)
            command.Parameters.AddWithValue("@letterdate", objletter.letterdate)
            command.Parameters.AddWithValue("@lettersubject", objletter.lettersubject)
            command.Parameters.AddWithValue("@lettername", objletter.lettername)
            command.Parameters.AddWithValue("@study_year", objletter.study_year)
            command.Parameters.AddWithValue("@study_start_date", objletter.study_start_date)
            command.Parameters.AddWithValue("@academic_year", objletter.academic_year)
            command.Parameters.AddWithValue("@academic_year_end_date", objletter.academic_year_end_date)
            command.Parameters.AddWithValue("@noofweeks", objletter.noofweeks)
            command.Parameters.AddWithValue("@course_amount", objletter.course_amount)
            command.Parameters.AddWithValue("@lettertext", objletter.lettertext)
            command.Parameters.AddWithValue("@modified_by", objletter.modified_by)
            command.Parameters.AddWithValue("@modified_date", Date.Now())
            command.Parameters.AddWithValue("@id", objletter.sponsorid)
            LinkedID = command.ExecuteNonQuery()
            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtilExtended")
            newError.Log()
            Dim er = ex.Message
        End Try
        Return LinkedID
    End Function

    Public Function delete_sponsor_letter(ByVal objletter As arabicletter) As Integer
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim Qry As String = ""
            Qry = Qry & " update sponsorlettertable set active=@param1,"
            Qry = Qry & "modified_by=@modified_by,modified_date=@modified_date where sponsorletterid=@id and active=1"
            Dim command As New SqlCommand(Qry, sqlCon)
            command.Parameters.AddWithValue("@param1", 0)
            command.Parameters.AddWithValue("@modified_by", objletter.modified_by)
            command.Parameters.AddWithValue("@modified_date", Date.Now())
            command.Parameters.AddWithValue("@id", objletter.arabicid)
            LinkedID = command.ExecuteNonQuery()
            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtilExtended")
            newError.Log()
            Dim er = ex.Message
        End Try
        Return LinkedID
    End Function

    Public Function Update_sponsor_pdf_path(ByVal path As String, ByVal filename As String, ByVal id As Integer) As Integer
        ' Dim objStu As New mb_st_details
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim Qry As String = ""
            Qry = Qry & " update sponsorlettertable set path=@param1, filename=@param2"
            Qry = Qry & " where sponsorletterid=@id and active=1"
            Dim command As New SqlCommand(Qry, sqlCon)
            command.Parameters.AddWithValue("@param1", path)
            command.Parameters.AddWithValue("@param2", filename)
            command.Parameters.AddWithValue("@id", id)
            LinkedID = command.ExecuteNonQuery()

            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtilExtended")
            newError.Log()
            Dim er = ex.Message
        End Try
        Return LinkedID
    End Function



    Public Function Update_family_Sh_Student(ByVal _familyObj As mb_st_family_details, ByVal UserName As String) As Integer
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim qry As String = "update mb_st_family_details set  "
            If String.IsNullOrWhiteSpace(_familyObj.family_full_name_arabic) = False Then qry += " family_full_name_arabic=@family_full_name_arabic, "
            If _familyObj.stu_id > 0 Then qry += " stu_id=@stu_id, "
            ' If _familyObj.stu_profile_no > 0 Then qry += " stu_profile_no=@stu_profile_no, "
            If _familyObj.family_profile_no > 0 Then qry += " family_profile_no=@family_profile_no, "
            If String.IsNullOrWhiteSpace(_familyObj.family_title) = False Then qry += " family_title=@family_title, "
            If String.IsNullOrWhiteSpace(_familyObj.family_first_name) = False Then qry += " family_first_name=@family_first_name, "
            If String.IsNullOrWhiteSpace(_familyObj.family_last_name) = False Then qry += " family_last_name=@family_last_name, "
            If String.IsNullOrWhiteSpace(_familyObj.family_full_name) = False Then qry += " family_full_name=@family_full_name, "
            If String.IsNullOrWhiteSpace(_familyObj.family_email_address) = False Then qry += " family_email_address=@family_email_address, "
            If String.IsNullOrWhiteSpace(_familyObj.family_national_number) = False Then qry += " family_national_number=@family_national_number, "
                                If String.IsNullOrWhiteSpace(_familyObj.family_passport_number) = False Then qry += " family_passport_number=@family_passport_number, "

            If _familyObj.family_dob > Date.MinValue Then qry += " family_dob=@family_dob, "
            If String.IsNullOrWhiteSpace(_familyObj.family_gender) = False Then qry += " family_gender=@family_gender, "

            If String.IsNullOrWhiteSpace(_familyObj.family_degree_name) = False Then qry += " family_degree_name=@family_degree_name, "
                                If String.IsNullOrWhiteSpace(_familyObj.family_course_name) = False Then qry += " family_course_name=@family_course_name, "
                                If String.IsNullOrWhiteSpace(_familyObj.family_college_uni_name) = False Then qry += " family_college_uni_name=@family_college_uni_name, "
            If _familyObj.visa_expiry_date > Date.MinValue Then qry += " visa_expiry_date=@visa_expiry_date, "
            If String.IsNullOrWhiteSpace(_familyObj.family_mobile_1) = False Then qry += " family_mobile_1=@family_mobile_1, "
                                If String.IsNullOrWhiteSpace(_familyObj.family_mobile_2) = False Then qry += " family_mobile_2=@family_mobile_2, "
                                qry += " modified_by=@modified_by, modified_date=@modified_date where stu_profile_no=@id and active=1;"
            Dim command As New SqlCommand(qry, sqlCon)

            '  If String.IsNullOrWhiteSpace(_familyObj.family_relation_student) = False Then command.Parameters.AddWithValue("@family_relation_student", _familyObj.family_relation_student)
            If String.IsNullOrWhiteSpace(_familyObj.family_full_name_arabic) = False Then command.Parameters.AddWithValue("@family_full_name_arabic", _familyObj.family_full_name_arabic)
            If _familyObj.stu_id > 0 Then command.Parameters.AddWithValue("@stu_id", _familyObj.stu_id)
            If _familyObj.family_profile_no > 0 Then command.Parameters.AddWithValue("@family_profile_no", _familyObj.family_profile_no)
                If String.IsNullOrWhiteSpace(_familyObj.family_title) = False Then command.Parameters.AddWithValue("@family_title", _familyObj.family_title)
                If String.IsNullOrWhiteSpace(_familyObj.family_first_name) = False Then command.Parameters.AddWithValue("@family_first_name", _familyObj.family_first_name)
                If String.IsNullOrWhiteSpace(_familyObj.family_last_name) = False Then command.Parameters.AddWithValue("@family_last_name", _familyObj.family_last_name)
            If String.IsNullOrWhiteSpace(_familyObj.family_full_name) = False Then command.Parameters.AddWithValue("@family_full_name", _familyObj.family_full_name)
            If String.IsNullOrWhiteSpace(_familyObj.family_email_address) = False Then command.Parameters.AddWithValue("@family_email_address", _familyObj.family_email_address)
            If String.IsNullOrWhiteSpace(_familyObj.family_national_number) = False Then command.Parameters.AddWithValue("@family_national_number", _familyObj.family_national_number)
            If String.IsNullOrWhiteSpace(_familyObj.family_passport_number) = False Then command.Parameters.AddWithValue("@family_passport_number", _familyObj.family_passport_number)
            If _familyObj.family_dob > Date.MinValue Then command.Parameters.AddWithValue("@family_dob", _familyObj.family_dob)
            If String.IsNullOrWhiteSpace(_familyObj.family_gender) = False Then command.Parameters.AddWithValue("@family_gender", _familyObj.family_gender)

            If String.IsNullOrWhiteSpace(_familyObj.family_degree_name) = False Then command.Parameters.AddWithValue("@family_degree_name", _familyObj.family_degree_name)

            If String.IsNullOrWhiteSpace(_familyObj.family_course_name) = False Then command.Parameters.AddWithValue("@family_course_name", _familyObj.family_course_name)
            If String.IsNullOrWhiteSpace(_familyObj.family_college_uni_name) = False Then command.Parameters.AddWithValue("@family_college_uni_name", _familyObj.family_college_uni_name)
            If _familyObj.visa_expiry_date > Date.MinValue Then command.Parameters.AddWithValue("@visa_expiry_date", _familyObj.visa_expiry_date)
                            If String.IsNullOrWhiteSpace(_familyObj.family_mobile_1) = False Then command.Parameters.AddWithValue("@family_mobile_1", _familyObj.family_mobile_1)
                            If String.IsNullOrWhiteSpace(_familyObj.family_mobile_2) = False Then command.Parameters.AddWithValue("@family_mobile_2", _familyObj.family_mobile_2)

                            command.Parameters.AddWithValue("@active", 1)
            command.Parameters.AddWithValue("@modified_by", _familyObj.created_by)
            command.Parameters.AddWithValue("@modified_date", Now())
            command.Parameters.AddWithValue("@id", _familyObj.stu_profile_no)
            LinkedID = Convert.ToInt32(command.ExecuteScalar())
            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtil Update family")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

        Return LinkedID

    End Function

    Public Function Get_letter_info_By_ID(ByVal _Id As Integer, ByVal lettertype As String) As DataTable
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        Dim qry As String = "select " & lettertype & "id ,filename,lettersubject,profileno,letterdate,letterto,lettertext,path,created_by,created_date,modified_by,modified_date,active  "
        qry = qry & "FROM " & lettertype & "table where "
        qry = qry & "" & lettertype & "id=@id "

        ' qry += "   arabiclettertable  where arabicletterid=@id "
        myCommand.CommandText = qry
        myCommand.Parameters.Add("@id", SqlDbType.Int).Value = _Id
        myAdapter = New SqlDataAdapter(myCommand)
        myAdapter.Fill(_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close() myConnection.Dispose()
        Return _DT
    End Function

    Public Function Get_Spon_letter_info_By_ID(ByVal _Id As Integer) As DataTable
        Dim _DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        Dim qry As String = ""
        qry = qry & "SELECT mb_st_details.stu_full_name, mb_st_details.university_name, mb_st_details.course_name, sponsorlettertable.sponsorletterid, sponsorlettertable.profileno, sponsorlettertable.letterdate,
           sponsorlettertable.lettersubject, sponsorlettertable.lettername, sponsorlettertable.study_year,
           sponsorlettertable.study_start_date, sponsorlettertable.academic_year, sponsorlettertable.noofweeks,
           sponsorlettertable.academic_year_end_date, sponsorlettertable.course_amount, sponsorlettertable.filename,
            sponsorlettertable.letterto, sponsorlettertable.lettertext, sponsorlettertable.path,
           sponsorlettertable.active FROM mb_st_details INNER JOIN sponsorlettertable ON mb_st_details.profile_no = sponsorlettertable.profileno WHERE
           (sponsorlettertable.active = 1) AND (sponsorlettertable.sponsorletterid = @id) "

        myCommand.CommandText = qry
        myCommand.Parameters.Add("@id", SqlDbType.Int).Value = _Id
        myAdapter = New SqlDataAdapter(myCommand)
        myAdapter.Fill(_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close() myConnection.Dispose()
        Return _DT
    End Function
    Public Function Update_Req_status(ByVal id As String) As Boolean
        Dim result As Boolean = False
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim Qry As String = ""
            Qry = Qry & " update mb_req_form set status=@status "
            Qry = Qry & " where req_id=@id and active=1"
            Dim command As New SqlCommand(Qry, sqlCon)
            command.Parameters.AddWithValue("@status", 1)
            command.Parameters.AddWithValue("@id", id)
            Dim i As Integer = command.ExecuteNonQuery()
            If i > 0 Then result = True
            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "status guid")
            newError.Log()
            Dim er = ex.Message
            result = False
        End Try
        Return result
    End Function

    Public Function Get_List_of_student_By_Supervisor_ID(Optional ByVal User_ID As Integer = 0,
                                     Optional ByVal entity_user_id As Integer = 0,
                                      Optional ByVal Stu_Id As Integer = 0
                                     ) As DataTable
        Dim List_DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        Dim qry As String = "select * from vw_supervisor_student_table"
        qry += " where (active=1) "
        If entity_user_id > 0 Then qry += " and (profile_no = @prof_no) "
        If User_ID > 0 Then qry += " and (user_id = @user_id) "
        If Stu_Id > 0 Then qry += " and ( stu_id= @stu_id)"
        myCommand.CommandText = qry
        If entity_user_id > 0 Then myCommand.Parameters.Add("@prof_no", SqlDbType.Int).Value = entity_user_id
        If User_ID > 0 Then myCommand.Parameters.Add("@user_id", SqlDbType.Int).Value = User_ID
        If Stu_Id > 0 Then myCommand.Parameters.Add("@stu_Id", SqlDbType.Int).Value = Stu_Id

        myAdapter = New SqlDataAdapter(myCommand)
        myAdapter.Fill(List_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close() myConnection.Dispose()
        Return List_DT
    End Function


    Public Function Bind_Student_List(Optional ByVal User_ID As Integer = 0) As DataTable
        Dim List_DT As New DataTable
        Dim myConnection As New SqlConnection(Get_NewConn())
        Dim myCommand As SqlCommand
        Dim myAdapter As SqlDataAdapter
        myCommand = New SqlCommand
        myCommand.Connection = myConnection
        Dim qry As String = ""
        qry += " SELECT mb_st_details.stu_id, mb_st_details.profile_no, mb_st_details.stu_full_name, mb_st_details.stu_title, mb_st_details.stu_first_name, "
        qry += "       mb_st_details.stu_last_name, mb_st_details.stu_dob, mb_st_details.stu_gender, "
        qry += "       mb_st_details.stu_national_number, mb_st_details.stu_passport_no, mb_st_details.st_visa_expiry_date, "
        qry += "       mb_st_details.degree_name, mb_st_details.university_name, mb_st_details.course_name, mb_st_details.stu_address_1, "
        qry += "        mb_st_details.stu_address_2, mb_st_details.stu_city, mb_st_details.county, mb_st_details.stu_postcode, mb_st_details.stu_country, "
        qry += "        mb_st_details.stu_full_address, mb_st_details.stu_email_address, mb_st_details.isRegistered, "
        qry += "        mb_st_details.active AS student_active, entity_users.user_id AS Supervisor_id, mb_st_user.full_name FROM entity_users "
        qry += "        LEFT OUTER JOIN mb_st_user On entity_users.user_id = mb_st_user.user_id "
        qry += "            RIGHT OUTER JOIN mb_st_details ON entity_users.stu_id = mb_st_details.stu_id "
        If User_ID > 0 Then qry += " where (mb_st_user.user_id = @user_id) "
        myCommand.CommandText = qry
        If User_ID > 0 Then myCommand.Parameters.Add("@user_id", SqlDbType.Int).Value = User_ID
        myAdapter = New SqlDataAdapter(myCommand)
        myAdapter.Fill(List_DT)
        If myConnection.State = ConnectionState.Open Then myConnection.Close() myConnection.Dispose()
        Return List_DT
    End Function


    Public Function Update_User(ByVal _objUser As mb_st_user) As Integer
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim qry As String = "update mb_st_user set  "
            If String.IsNullOrWhiteSpace(_objUser.title) = False Then qry += " title=@title, "
            If String.IsNullOrWhiteSpace(_objUser.first_name) = False Then qry += " first_name=@first_name, "
            If String.IsNullOrWhiteSpace(_objUser.middle_name) = False Then qry += " middle_name=@middle_name, "
            If String.IsNullOrWhiteSpace(_objUser.last_name) = False Then qry += " last_name=@last_name, "
            If String.IsNullOrWhiteSpace(_objUser.full_name) = False Then qry += " full_name=@full_name, "

            If String.IsNullOrWhiteSpace(_objUser.address_1) = False Then qry += " address_1=@address_1, "
            If String.IsNullOrWhiteSpace(_objUser.address_2) = False Then qry += " address_2=@address_2, "
            If String.IsNullOrWhiteSpace(_objUser.city) = False Then qry += " city=@city, "
            If String.IsNullOrWhiteSpace(_objUser.county) = False Then qry += " county=@county, "
            If String.IsNullOrWhiteSpace(_objUser.country) = False Then qry += " country=@country, "
            If (_objUser.dob) > Date.MinValue Then qry += " dob=@dob, "
            If String.IsNullOrWhiteSpace(_objUser.gender) = False Then qry += " gender=@gender, "
            If String.IsNullOrWhiteSpace(_objUser.mobile_1) = False Then qry += " mobile_1=@mobile_1, "
            If String.IsNullOrWhiteSpace(_objUser.mobile_2) = False Then qry += " mobile_2=@mobile_2, "
            If (_objUser.active) = 0 Then qry += " active=@active, "
            qry += " modified_by=@modified_by, modified_date=@modified_date where user_id=@id and active=1;"
            Dim command As New SqlCommand(qry, sqlCon)

            If String.IsNullOrWhiteSpace(_objUser.title) = False Then command.Parameters.AddWithValue("@title", _objUser.title)
            If String.IsNullOrWhiteSpace(_objUser.first_name) = False Then command.Parameters.AddWithValue("@first_name", _objUser.first_name)
            If String.IsNullOrWhiteSpace(_objUser.middle_name) = False Then command.Parameters.AddWithValue("@middle_name", _objUser.middle_name)
            If String.IsNullOrWhiteSpace(_objUser.last_name) = False Then command.Parameters.AddWithValue("@last_name", _objUser.last_name)
            If String.IsNullOrWhiteSpace(_objUser.full_name) = False Then command.Parameters.AddWithValue("@full_name", _objUser.full_name)

            If String.IsNullOrWhiteSpace(_objUser.address_1) = False Then command.Parameters.AddWithValue("@address_1", _objUser.address_1)
            If String.IsNullOrWhiteSpace(_objUser.address_2) = False Then command.Parameters.AddWithValue("@address_2", _objUser.address_2)
            If String.IsNullOrWhiteSpace(_objUser.city) = False Then command.Parameters.AddWithValue("@city", _objUser.city)
            If String.IsNullOrWhiteSpace(_objUser.county) = False Then command.Parameters.AddWithValue("@county", _objUser.county)
            If String.IsNullOrWhiteSpace(_objUser.country) = False Then command.Parameters.AddWithValue("@country", _objUser.country)
            If (_objUser.dob) > Date.MinValue Then command.Parameters.AddWithValue("@dob", _objUser.dob)
            If String.IsNullOrWhiteSpace(_objUser.gender) = False Then command.Parameters.AddWithValue("@gender", _objUser.gender)
            If String.IsNullOrWhiteSpace(_objUser.mobile_1) = False Then command.Parameters.AddWithValue("@mobile_1", _objUser.mobile_1)
            If String.IsNullOrWhiteSpace(_objUser.mobile_2) = False Then command.Parameters.AddWithValue("@mobile_2", _objUser.mobile_2)
            If (_objUser.active) = 0 Then command.Parameters.AddWithValue("@active", _objUser.active)
            command.Parameters.AddWithValue("@modified_by", _objUser.modified_by)
            command.Parameters.AddWithValue("@modified_date", Now())
            command.Parameters.AddWithValue("@id", _objUser.user_id)
            LinkedID = Convert.ToInt32(command.ExecuteScalar())
            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtil Update family")
            newError.Log()
            Debug.Print(ex.Message)
        End Try

        Return LinkedID

    End Function

    Public Function make_user_deactive(ByVal login_id As Integer,
                                              ByVal entity_user_id As Integer,
                                              ByVal user_id As Integer, ByVal active As Integer) As Integer
        ' Dim objStu As New mb_st_details
        Dim LinkedID As Integer = 0
        Try
            Dim sqlCon As New SqlConnection(Get_NewConn())
            sqlCon.Open()
            Dim Qry As String = ""
            Qry = Qry & " update mb_st_log set active=@active where login_id=@login_id;"
            Qry = Qry & "update entity_users set active=@active where entity_user_id=@entity_user_id;"
            Qry = Qry & "update mb_st_user set active=@active where user_id=@user_id;"

            Dim command As New SqlCommand(Qry, sqlCon)
            command.Parameters.AddWithValue("@login_id", login_id)

            command.Parameters.AddWithValue("@entity_user_id", entity_user_id)

            command.Parameters.AddWithValue("@user_id", user_id)
            command.Parameters.AddWithValue("@active", active)

            LinkedID = command.ExecuteNonQuery()

            sqlCon.Close()
            sqlCon.Dispose()
        Catch ex As Exception
            Dim newError As New logs(ex, "DBUtilExtended")
            newError.Log()
            Dim er = ex.Message
        End Try
        Return LinkedID
    End Function
End Class
