﻿Public Class mb_st_user

    Public Property user_id As Integer
    Public Property passport_id As Integer
    Public Property qualification_id As Integer
    Public Property role_id As Integer
    Public Property full_name As String
    Public Property title As String
    Public Property first_name As String
    Public Property middle_name As String
    Public Property last_name As String
    Public Property dob As Date
    Public Property gender As String
    Public Property address_1 As String
    Public Property address_2 As String
    Public Property city As String
    Public Property county As String
    Public Property postcode As String
    Public Property country As String
    Public Property full_address As String
    Public Property email_address As String
    Public Property mobile_1 As String
    Public Property mobile_2 As String
    Public Property mobile_1_primary As Byte
    Public Property mobile_2_primary As Byte
    Public Property created_by As String
    Public Property other_latitude As Decimal
    Public Property other_longitude As Decimal
    Public Property created_date As DateTime
    Public Property modified_by As String
    Public Property modified_date As DateTime
    Public Property active As Byte
End Class