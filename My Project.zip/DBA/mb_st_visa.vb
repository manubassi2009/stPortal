﻿Public Class mb_st_visa

    Public Property visa_id As Integer
    Public Property passport_id As Integer
    Public Property visa_issue_date As Date
    Public Property visa_expiry_date As Date
    Public Property created_by As String
    Public Property created_date As DateTime
    Public Property modified_by As String
    Public Property modified_date As DateTime
    Public Property active As Byte
End Class
