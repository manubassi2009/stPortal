﻿Public Class mb_st_log_sys_view

    Public Property login_id As Integer
    Public Property entity_user_id As Integer
    Public Property username As String
    Public Property password As String
    Public Property saltkey As String
    Public Property stu_id As Integer
    Public Property user_id As Integer
    Public Property role_id As Integer
    Public Property entity_user_active As Byte
    Public Property login_active As Byte
    Public Property isRegistered As Byte
    Public Property active As Byte
End Class
