﻿Public Class mb_req_form
    Public Property req_id As Integer
    Public Property stu_id As Integer
    Public Property user_id As Integer
    Public Property entity_user_id As Integer
    Public Property req_type As String
    Public Property req_details_1 As String
    Public Property re_details_more As String
    Public Property status As Integer
    Public Property active As Boolean
    Public Property created_by As String
    Public Property created_date As DateTime
    Public Property modified_by As String
    Public Property modified_date As DateTime

End Class
