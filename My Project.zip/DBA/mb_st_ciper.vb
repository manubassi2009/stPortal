﻿Public Class mb_st_ciper
    Public Property ciper_id As Integer
    Public Property entity_user_id As Integer
    Public Property saltkey As String
    Public Property created_by As String
    Public Property created_date As DateTime
    Public Property modified_by As String
    Public Property modified_date As DateTime
    Public Property active As Byte

End Class