﻿Public Class vw_supervisor_student
    Public Property user_id As Integer
    Public Property fullname As String
    Public Property role_id As Integer
    Public Property entity_user_id As Integer
    Public Property stu_id As Integer
    Public Property profile_no As Integer
    Public Property stu_full_name As String
    Public Property active As Byte



End Class
