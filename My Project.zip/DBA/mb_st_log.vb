﻿Public Class mb_st_log
    Public Property login_id As Integer
    Public Property entity_user_id As Integer
    Public Property guid_ID As String
    Public Property guidActive As Byte
    Public Property username As String
    Public Property password As String
    Public Property created_by As String
    Public Property created_date As DateTime
    Public Property modified_by As String
    Public Property modified_date As DateTime
    Public Property last_login_on As DateTime
    Public Property active As Byte
    Public Property isLockedOutDate As DateTime
    Public Property isLockedOut As Byte


End Class
