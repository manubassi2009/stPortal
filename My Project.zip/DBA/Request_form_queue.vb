﻿Public Class Request_form_queue
    Public Property req_id As Integer
    Public Property req_type As String
    Public Property req_details_1 As String
    Public Property re_details_more As String
    Public Property status As Integer
    Public Property active As Boolean
    Public Property profile_no As Integer
    Public Property stu_full_name As String
    Public Property stu_national_number As Integer
    Public Property isRegistered As Boolean
    Public Property student_active As Boolean
    Public Property full_name As String
    Public Property user_id As Integer
    Public Property stu_id As Integer
    Public Property created_date As DateTime
End Class
