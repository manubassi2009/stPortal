﻿Public Class arabicletter
    Public Property arabicid As Integer
    Public Property profile_no As Integer
    Public Property lettersubject As String
    Public Property letterto As String
    Public Property letterdate As DateTime
    Public Property lettertext As String
    Public Property filename As String
    Public Property path As String
    Public Property created_by As String
    Public Property created_date As DateTime
    Public Property modified_by As String
    Public Property modified_date As DateTime
    Public Property active As Boolean

End Class
