﻿Public Class mb_st_qualification

    Public Property qualification_id As Integer
    Public Property qualification_name As String
    Public Property created_by As String
    Public Property created_date As DateTime
    Public Property modified_by As String
    Public Property modified_date As DateTime
    Public Property active As Byte
End Class
